# 🌐 EcoCampus — Live Website Deployment Guide

This guide explains how to take your **EcoCampus** platform live on the internet in **under 2 minutes**.

---

## ⚡ Option 1: Instant Full-Stack on Render (FREE & Recommended)
This runs both the React Frontend and FastAPI Backend on a single live URL with SQLite persistence.

1. Create a free account at [render.com](https://render.com).
2. Click **New +** $\rightarrow$ **Web Service**.
3. Connect your GitHub repository (or upload this project folder).
4. Fill in the settings:
   - **Environment:** `Python 3`
   - **Build Command:** `pip install -r backend/requirements.txt`
   - **Start Command:** `cd backend && uvicorn main:app --host 0.0.0.0 --port $PORT`
5. Click **Deploy Web Service**!
   > Your website is now live at `https://<your-service-name>.onrender.com`!

---

## ⚡ Option 2: 10-Second Drag & Drop on Netlify Drop (FREE)
If you want to host the frontend static website immediately with 0 code or commands:

1. Open [app.netlify.com/drop](https://app.netlify.com/drop).
2. Drag and drop the provided `ecocampus-frontend-live.zip` (or the `frontend/dist` folder).
3. Netlify will instantly provide a live public URL (e.g. `https://peaceful-campus-1234.netlify.app`).

---

## ⚡ Option 3: Deploy on Vercel (FREE)
1. Push your repository to GitHub or install Vercel CLI (`npm i -g vercel`).
2. Run `vercel` in the project root folder.
3. The included `vercel.json` automatically configures Vite build and SPA routing redirects.

---

## ⚡ Option 4: Deploy with Docker on Any Cloud / VPS (Railway, Fly.io, DigitalOcean, AWS)
The project includes a multi-stage production `Dockerfile`:

```bash
# Build & Run Locally or on Any Server
docker build -t ecocampus .
docker run -p 8000:8000 -e PORT=8000 ecocampus
```
Visit `http://localhost:8000` or your VPS IP/domain.

---

## 📁 Pre-packaged Zip Files Created For You
1. **`ecocampus-live-ready.zip`**: Complete full-stack package ready for Render, Railway, Vercel, or Docker.
2. **`ecocampus-frontend-live.zip`**: Pre-built frontend bundle ready for instant Drag & Drop on Netlify Drop.
