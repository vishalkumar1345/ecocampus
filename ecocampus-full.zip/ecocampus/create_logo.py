import math
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

def create_3d_ecocampus_logo(output_path):
    W, H = 1024, 1024
    # Create high-res supersampled canvas (2048x2048 for supersampled antialiasing)
    SW, SH = 2048, 2048
    canvas = Image.new("RGBA", (SW, SH), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)
    
    cx, cy = SW // 2, SH // 2 - 40
    
    # 1. Ambient Occlusion Floor Shadow
    shadow_layer = Image.new("RGBA", (SW, SH), (0, 0, 0, 0))
    s_draw = ImageDraw.Draw(shadow_layer)
    s_draw.ellipse([cx - 580, cy + 540, cx + 580, cy + 760], fill=(6, 32, 28, 120))
    s_draw.ellipse([cx - 420, cy + 580, cx + 420, cy + 720], fill=(0, 240, 160, 45))
    shadow_layer = shadow_layer.filter(ImageFilter.GaussianBlur(55))
    canvas.alpha_composite(shadow_layer)

    # 2. Outer Glow Aurora
    glow_layer = Image.new("RGBA", (SW, SH), (0, 0, 0, 0))
    g_draw = ImageDraw.Draw(glow_layer)
    g_draw.ellipse([cx - 620, cy - 620, cx + 620, cy + 620], fill=(0, 229, 153, 30))
    g_draw.ellipse([cx - 450, cy - 450, cx + 450, cy + 450], fill=(6, 182, 212, 40))
    glow_layer = glow_layer.filter(ImageFilter.GaussianBlur(90))
    canvas.alpha_composite(glow_layer)

    # 3. Parametric 3D Interlocking Eco-Möbius Loop
    # We will generate 3 interconnected, overlapping leaves/ribbons arranged symmetrically at 120 deg (0, 120, 240)
    # Each leaf forms an aerodynamic, approaching rounded loop with 3D depth, isometric bevels, and glossy gradients.
    
    # Pre-render ribbons into separate layers to handle accurate z-indexing and overlap
    angles = [-90, 30, 150] # Top-center, Bottom-right, Bottom-left
    
    # Colors for each ribbon:
    # Ribbon 1 (Top): Vibrant Emerald & Mint (Eco Growth & Recycling)
    # Ribbon 2 (Bottom Right): Electric Cyan & Aquamarine (Water, Clean Air & Data Telemetry)
    # Ribbon 3 (Bottom Left): Lush Jade & Golden Emerald (Bio-composting, Campus Architecture)
    
    ribbon_configs = [
        {
            "angle": -90,
            "c_base": (12, 74, 56),
            "c_mid": (0, 220, 140),
            "c_light": (120, 255, 205),
            "c_rim": (180, 255, 235),
            "core_col": (0, 245, 160)
        },
        {
            "angle": 30,
            "c_base": (8, 60, 80),
            "c_mid": (6, 182, 212),
            "c_light": (103, 232, 249),
            "c_rim": (207, 250, 254),
            "core_col": (34, 211, 238)
        },
        {
            "angle": 150,
            "c_base": (16, 68, 42),
            "c_mid": (16, 185, 129),
            "c_light": (110, 245, 175),
            "c_rim": (209, 250, 229),
            "core_col": (52, 211, 153)
        }
    ]

    # Create 3D extruded volume for each lobe
    # For each lobe, we draw extruded slices from back to front with isometric offset
    for r_idx, cfg in enumerate(ribbon_configs):
        lobe_layer = Image.new("RGBA", (SW, SH), (0, 0, 0, 0))
        l_draw = ImageDraw.Draw(lobe_layer)
        
        deg = cfg["angle"]
        rad = math.radians(deg)
        dist = 280 # distance from center to loop center
        lx = cx + dist * math.cos(rad)
        ly = cy + dist * math.sin(rad)
        
        # Draw 3D Extrusion slices (giving depth / 3D thickness)
        depth_steps = 45
        for d in range(depth_steps, -1, -1):
            t = d / depth_steps
            # Isometric extrusion vector: downwards and slight right
            ox = (1 - t) * 18
            oy = (1 - t) * 48
            
            # Interpolate extrusion shade from dark base to vibrant surface
            c_ext = tuple(int(cfg["c_base"][k] * 0.7 + cfg["c_mid"][k] * 0.3 * t) for k in range(3))
            
            # Lobe shape: an organic curved teardrop / infinity loop
            # We sample points around an asymmetric parametric curve
            pts = []
            steps = 100
            for i in range(steps):
                th = 2 * math.pi * i / steps
                # Leaf/Petal radius function with friendly rounded contours
                r = 290 * (1 - 0.25 * math.cos(th)) * (1 + 0.15 * math.sin(2 * th))
                # Rotate local coords to match lobe orientation
                px = r * math.cos(th)
                py = r * 0.72 * math.sin(th)
                
                # Global orientation rotation
                rot_th = rad + math.pi / 2
                rx = px * math.cos(rot_th) - py * math.sin(rot_th)
                ry = px * math.sin(rot_th) + py * math.cos(rot_th)
                
                pts.append((lx + rx + ox, ly + ry + oy))
                
            l_draw.polygon(pts, fill=c_ext + (255,))
            
        # Draw inner cutout hole (making it a Möbius ribbon / toroidal ring)
        inner_pts = []
        for i in range(steps):
            th = 2 * math.pi * i / steps
            r = 135 * (1 - 0.2 * math.cos(th)) * (1 + 0.15 * math.sin(2 * th))
            px = r * math.cos(th)
            py = r * 0.72 * math.sin(th)
            rot_th = rad + math.pi / 2
            rx = px * math.cos(rot_th) - py * math.sin(rot_th)
            ry = px * math.sin(rot_th) + py * math.cos(rot_th)
            inner_pts.append((lx + rx, ly + ry))
            
        # Clear inner cutout with soft inner bevel
        mask_cutout = Image.new("L", (SW, SH), 0)
        m_draw = ImageDraw.Draw(mask_cutout)
        m_draw.polygon(inner_pts, fill=255)
        # Apply mask
        lobe_layer.paste((0, 0, 0, 0), (0, 0), mask_cutout)
        
        # Now render the top face with lush gradient and specular bevel
        face_layer = Image.new("RGBA", (SW, SH), (0, 0, 0, 0))
        f_draw = ImageDraw.Draw(face_layer)
        
        top_pts = []
        for i in range(steps):
            th = 2 * math.pi * i / steps
            r = 290 * (1 - 0.25 * math.cos(th)) * (1 + 0.15 * math.sin(2 * th))
            px = r * math.cos(th)
            py = r * 0.72 * math.sin(th)
            rot_th = rad + math.pi / 2
            rx = px * math.cos(rot_th) - py * math.sin(rot_th)
            ry = px * math.sin(rot_th) + py * math.cos(rot_th)
            top_pts.append((lx + rx, ly + ry))
            
        # Fill face with vibrant gradient
        f_draw.polygon(top_pts, fill=cfg["c_mid"] + (255,))
        # Punch inner cutout out of face
        f_draw.polygon(inner_pts, fill=(0, 0, 0, 0))
        
        # Specular outer bevel edge highlight
        f_draw.line(top_pts + [top_pts[0]], fill=cfg["c_rim"] + (230,), width=7)
        # Inner rim highlight
        f_draw.line(inner_pts + [inner_pts[0]], fill=cfg["c_light"] + (180,), width=5)
        
        # Add organic eco vein lines (smart campus sensor streams)
        for v in range(3):
            v_offset = (v - 1) * 35
            vein_pts = []
            for i in range(steps // 2):
                th = 2 * math.pi * i / steps
                r = (210 + v_offset) * (1 - 0.22 * math.cos(th))
                px = r * math.cos(th)
                py = r * 0.72 * math.sin(th)
                rot_th = rad + math.pi / 2
                rx = px * math.cos(rot_th) - py * math.sin(rot_th)
                ry = px * math.sin(rot_th) + py * math.cos(rot_th)
                vein_pts.append((lx + rx, ly + ry))
            f_draw.line(vein_pts, fill=cfg["c_rim"] + (140,), width=3)
            
        lobe_layer.alpha_composite(face_layer)
        
        # Composite lobe into canvas
        canvas.alpha_composite(lobe_layer)

    # 4. Central Prismatic Core (The Institutional Eco-Campus Crystal)
    # An isometric faceted diamond/cube that unites the three Möbius ribbons
    core_layer = Image.new("RGBA", (SW, SH), (0, 0, 0, 0))
    c_draw = ImageDraw.Draw(core_layer)
    
    # Center crystal dimensions
    cw = 170
    ch = 190
    
    # Top diamond facet (luminous white-cyan)
    top_facet = [
        (cx, cy - ch),
        (cx + cw, cy - ch * 0.45),
        (cx, cy + 10),
        (cx - cw, cy - ch * 0.45)
    ]
    c_draw.polygon(top_facet, fill=(240, 255, 250, 250))
    
    # Left facet (emerald shadow)
    left_facet = [
        (cx - cw, cy - ch * 0.45),
        (cx, cy + 10),
        (cx, cy + ch * 0.9),
        (cx - cw, cy + ch * 0.4)
    ]
    c_draw.polygon(left_facet, fill=(16, 140, 95, 240))
    
    # Right facet (electric cyan brilliance)
    right_facet = [
        (cx, cy + 10),
        (cx + cw, cy - ch * 0.45),
        (cx + cw, cy + ch * 0.4),
        (cx, cy + ch * 0.9)
    ]
    c_draw.polygon(right_facet, fill=(6, 182, 212, 240))
    
    # Core highlights and bevels
    c_draw.line(top_facet + [top_facet[0]], fill=(255, 255, 255, 255), width=6)
    c_draw.line(left_facet + [left_facet[0]], fill=(140, 255, 215, 220), width=4)
    c_draw.line(right_facet + [right_facet[0]], fill=(180, 250, 255, 220), width=4)
    c_draw.line([(cx, cy + 10), (cx, cy + ch * 0.9)], fill=(255, 255, 255, 255), width=6)
    
    # Inner energy emblem (Leaf silhouette in crystal center)
    leaf_cx = cx
    leaf_cy = cy - ch * 0.45 + 15
    leaf_pts = [
        (leaf_cx, leaf_cy - 45),
        (leaf_cx + 28, leaf_cy - 10),
        (leaf_cx + 24, leaf_cy + 30),
        (leaf_cx, leaf_cy + 52),
        (leaf_cx - 24, leaf_cy + 30),
        (leaf_cx - 28, leaf_cy - 10)
    ]
    c_draw.polygon(leaf_pts, fill=(0, 229, 153, 240))
    c_draw.line([(leaf_cx, leaf_cy - 40), (leaf_cx, leaf_cy + 45)], fill=(255, 255, 255, 230), width=4)
    
    # Crystal glow flare
    flare_layer = Image.new("RGBA", (SW, SH), (0, 0, 0, 0))
    fl_draw = ImageDraw.Draw(flare_layer)
    fl_draw.ellipse([cx - 160, cy - 80, cx + 160, cy + 100], fill=(255, 255, 255, 90))
    fl_draw.ellipse([cx - 240, cy - 140, cx + 240, cy + 160], fill=(0, 245, 160, 60))
    flare_layer = flare_layer.filter(ImageFilter.GaussianBlur(30))
    
    core_layer.alpha_composite(flare_layer)
    canvas.alpha_composite(core_layer)

    # 5. Glossy Diagonal Glass Glare Sweep (High-tech approaching finish)
    glare_layer = Image.new("RGBA", (SW, SH), (0, 0, 0, 0))
    gl_draw = ImageDraw.Draw(glare_layer)
    # A soft diagonal beam
    beam_pts = [
        (cx - 380, cy - 700),
        (cx + 80, cy - 700),
        (cx - 80, cy + 650),
        (cx - 540, cy + 650)
    ]
    gl_draw.polygon(beam_pts, fill=(255, 255, 255, 32))
    glare_layer = glare_layer.filter(ImageFilter.GaussianBlur(25))
    canvas.alpha_composite(glare_layer)

    # Resize down with Lanczos anti-aliasing to target size (1024x1024)
    final_img = canvas.resize((W, H), Image.Resampling.LANCZOS)
    final_img.save(output_path, "PNG", optimize=True)
    print(f"Successfully rendered 3D EcoCampus logo to {output_path}")

if __name__ == "__main__":
    import os
    out = os.path.join(os.path.dirname(__file__), "frontend/public/ecocampus-logo-3d.png")
    create_3d_ecocampus_logo(out)
