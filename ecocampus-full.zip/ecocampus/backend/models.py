from pydantic import BaseModel, Field
from typing import Optional, List

class WasteRecordBase(BaseModel):
    date: str = Field(..., description="Date in YYYY-MM-DD format")
    campus_location: str = Field(..., min_length=1)
    waste_category: str = Field(..., min_length=1)
    weight_kg: float = Field(..., gt=0, description="Weight in kg must be greater than zero")
    remarks: Optional[str] = ""

class WasteRecordCreate(WasteRecordBase):
    pass

class BatchRecordCreate(BaseModel):
    records: List[WasteRecordCreate]

class WasteRecordUpdate(BaseModel):
    date: Optional[str] = None
    campus_location: Optional[str] = None
    waste_category: Optional[str] = None
    weight_kg: Optional[float] = Field(None, gt=0)
    remarks: Optional[str] = None

class WasteRecordOut(WasteRecordBase):
    id: int
    record_id: str
    is_demo: bool
    created_at: str

class RecordFilterParams(BaseModel):
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    location: Optional[str] = None
    category: Optional[str] = None
    search: Optional[str] = None
    page: int = 1
    page_size: int = 15
    sort_by: str = "date"  # date, weight_kg, record_id
    sort_order: str = "desc"  # asc, desc

class ConfirmImportRequest(BaseModel):
    temp_file_id: str
    column_mapping: dict
    skip_duplicates: bool = True
