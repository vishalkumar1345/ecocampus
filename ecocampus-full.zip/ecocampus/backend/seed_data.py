import random
from datetime import datetime, timedelta
from database import get_db, init_db

LOCATIONS = [
    "Canteen",
    "Hostel",
    "Classrooms",
    "Library",
    "Playground",
    "Labs",
    "Admin Block",
    "Auditorium"
]

CATEGORIES = [
    "Organic / Food Waste",
    "Plastic Waste",
    "Paper Waste",
    "Metal Waste",
    "Glass Waste",
    "Other Waste"
]

LOCATION_PROFILE = {
    "Canteen": {
        "weights": {"Organic / Food Waste": 0.65, "Plastic Waste": 0.20, "Other Waste": 0.10, "Paper Waste": 0.05},
        "range": (12.0, 48.0),
        "remarks": ["Post-lunch mess collection", "Breakfast leftovers & vegetable peels", "Disposable cutlery & beverage cups", "Dinner buffet cleared"]
    },
    "Hostel": {
        "weights": {"Plastic Waste": 0.40, "Organic / Food Waste": 0.30, "Paper Waste": 0.15, "Metal Waste": 0.10, "Other Waste": 0.05},
        "range": (8.0, 28.0),
        "remarks": ["Snack packaging & water bottles", "Hostel common room bin clearance", "Late-night delivery containers", "Weekend dorm cleanup"]
    },
    "Classrooms": {
        "weights": {"Paper Waste": 0.55, "Plastic Waste": 0.30, "Other Waste": 0.15},
        "range": (4.0, 16.0),
        "remarks": ["Lecture notes & discarded printouts", "Empty beverage bottles", "Stationery & wrappers", "Exam hall waste clearance"]
    },
    "Library": {
        "weights": {"Paper Waste": 0.70, "Plastic Waste": 0.15, "Other Waste": 0.15},
        "range": (3.0, 14.0),
        "remarks": ["Old newspapers & damaged photocopies", "Reading room waste receptacles", "Catalog papers & packaging", "Study cubicle bins"]
    },
    "Playground": {
        "weights": {"Plastic Waste": 0.50, "Metal Waste": 0.25, "Other Waste": 0.25},
        "range": (5.0, 20.0),
        "remarks": ["Sports event sports drink bottles", "Discarded beverage cans", "Damaged sports equipment wrappers", "Bleacher perimeter sweep"]
    },
    "Labs": {
        "weights": {"Glass Waste": 0.40, "Metal Waste": 0.25, "Plastic Waste": 0.25, "Other Waste": 0.10},
        "range": (3.0, 15.0),
        "remarks": ["Broken borosilicate glass apparatus", "Chemical packaging containers", "Consumables & pipette tip boxes", "Component spare scraps"]
    },
    "Admin Block": {
        "weights": {"Paper Waste": 0.65, "Plastic Waste": 0.20, "Other Waste": 0.10, "Metal Waste": 0.05},
        "range": (5.0, 18.0),
        "remarks": ["Archival document shredding", "Office stationary & envelopes", "Staff room plastic disposables", "Courier packaging"]
    },
    "Auditorium": {
        "weights": {"Paper Waste": 0.40, "Plastic Waste": 0.35, "Organic / Food Waste": 0.15, "Other Waste": 0.10},
        "range": (6.0, 24.0),
        "remarks": ["Post-seminar brochure cleanup", "Auditorium aisle beverage containers", "Event refreshment snacks waste", "Guest reception cleanup"]
    }
}

def generate_demo_records(count=160):
    records = []
    # Reference date: Nov 20, 2026
    end_date = datetime(2026, 11, 20)
    
    rec_counter = 1001
    for i in range(count):
        # Pick date within past 60 days with weighted recency
        days_ago = int(random.triangular(0, 60, 10))
        record_date = end_date - timedelta(days=days_ago)
        date_str = record_date.strftime("%Y-%m-%d")
        
        # Pick location
        location = random.choice(LOCATIONS)
        profile = LOCATION_PROFILE[location]
        
        # Pick category based on profile weights
        cat_choices = list(profile["weights"].keys())
        cat_weights = list(profile["weights"].values())
        category = random.choices(cat_choices, weights=cat_weights, k=1)[0]
        
        # Calculate realistic weight
        min_w, max_w = profile["range"]
        # Multipliers based on category
        cat_multiplier = 1.2 if "Organic" in category else (0.8 if "Glass" in category else 1.0)
        weight = round(random.uniform(min_w, max_w) * cat_multiplier, 1)
        
        remark = random.choice(profile["remarks"])
        
        record_id = f"ECO-DEMO-{rec_counter}"
        rec_counter += 1
        
        created_at = (record_date + timedelta(hours=random.randint(9, 18), minutes=random.randint(0, 59))).strftime("%Y-%m-%d %H:%M:%S")
        
        records.append({
            "record_id": record_id,
            "date": date_str,
            "campus_location": location,
            "waste_category": category,
            "weight_kg": weight,
            "remarks": f"[DEMO DATA] {remark}",
            "is_demo": 1,
            "created_at": created_at
        })
    
    # Sort chronologically
    records.sort(key=lambda r: (r["date"], r["record_id"]))
    return records

def seed_database(reset=False):
    init_db()
    with get_db() as conn:
        cursor = conn.cursor()
        if reset:
            cursor.execute("DELETE FROM waste_records WHERE is_demo = 1;")
        
        # Check existing count
        cursor.execute("SELECT COUNT(*) FROM waste_records WHERE is_demo = 1;")
        count = cursor.fetchone()[0]
        if count == 0 or reset:
            demo_records = generate_demo_records(180)
            cursor.executemany("""
                INSERT OR REPLACE INTO waste_records 
                (record_id, date, campus_location, waste_category, weight_kg, remarks, is_demo, created_at)
                VALUES (:record_id, :date, :campus_location, :waste_category, :weight_kg, :remarks, :is_demo, :created_at)
            """, demo_records)
            print(f"Seeded {len(demo_records)} demo records into database.")
        else:
            print(f"Database already contains {count} demo records.")

if __name__ == "__main__":
    seed_database(reset=True)
