import sqlite3
import os
from contextlib import contextmanager

DB_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(DB_DIR, "waste_records.db")

@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def init_db():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS waste_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_id TEXT UNIQUE NOT NULL,
                date TEXT NOT NULL,
                campus_location TEXT NOT NULL,
                waste_category TEXT NOT NULL,
                weight_kg REAL NOT NULL,
                remarks TEXT,
                is_demo INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            );
        """)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_date ON waste_records(date);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_location ON waste_records(campus_location);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_category ON waste_records(waste_category);")
