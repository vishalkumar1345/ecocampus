import pandas as pd
from datetime import datetime, timedelta
from analytics import load_dataframe

def generate_report_data(period_type="monthly", start_date=None, end_date=None):
    df_all = load_dataframe("all")
    if df_all.empty:
        ref_date = pd.to_datetime("2026-11-20")
    else:
        ref_date = df_all["date"].max()

    if period_type == "daily":
        p_start = ref_date
        p_end = ref_date
        period_label = f"Daily Audit ({ref_date.strftime('%d %B %Y')})"
    elif period_type == "weekly":
        p_start = ref_date - pd.Timedelta(days=7)
        p_end = ref_date
        period_label = f"Weekly Audit ({p_start.strftime('%d %b %Y')} – {p_end.strftime('%d %b %Y')})"
    elif period_type == "monthly":
        p_start = ref_date - pd.Timedelta(days=30)
        p_end = ref_date
        period_label = f"Monthly Audit ({p_start.strftime('%d %b %Y')} – {p_end.strftime('%d %b %Y')})"
    elif period_type == "custom":
        p_start = pd.to_datetime(start_date) if start_date else (ref_date - pd.Timedelta(days=30))
        p_end = pd.to_datetime(end_date) if end_date else ref_date
        period_label = f"Custom Audit ({p_start.strftime('%d %b %Y')} – {p_end.strftime('%d %b %Y')})"
    else:
        p_start = ref_date - pd.Timedelta(days=30)
        p_end = ref_date
        period_label = f"Campus Audit ({p_start.strftime('%d %b %Y')} – {p_end.strftime('%d %b %Y')})"

    df = df_all[(df_all["date"] >= p_start) & (df_all["date"] <= p_end)]

    total_weight = float(df["weight_kg"].sum()) if not df.empty else 0.0
    records_count = int(len(df))
    locations_count = int(df["campus_location"].nunique()) if not df.empty else 0
    days_count = max(1, (p_end - p_start).days + 1)
    daily_avg = round(total_weight / days_count, 1)

    # Location Breakdown using pandas groupby
    location_summary = []
    if not df.empty:
        for loc, grp in df.groupby("campus_location"):
            w = float(grp["weight_kg"].sum())
            pct = round((w / total_weight * 100), 1) if total_weight > 0 else 0
            location_summary.append({
                "location": loc,
                "weight_kg": round(w, 1),
                "percentage": pct,
                "records_count": len(grp),
                "avg_per_day": round(w / days_count, 1)
            })
        location_summary.sort(key=lambda x: x["weight_kg"], reverse=True)

    # Category Breakdown using pandas groupby
    category_summary = []
    if not df.empty:
        for cat, grp in df.groupby("waste_category"):
            w = float(grp["weight_kg"].sum())
            pct = round((w / total_weight * 100), 1) if total_weight > 0 else 0
            category_summary.append({
                "category": cat,
                "weight_kg": round(w, 1),
                "percentage": pct,
                "records_count": len(grp)
            })
        category_summary.sort(key=lambda x: x["weight_kg"], reverse=True)

    top_loc = location_summary[0] if location_summary else {"location": "N/A", "weight_kg": 0.0, "percentage": 0.0}
    top_cat = category_summary[0] if category_summary else {"category": "N/A", "weight_kg": 0.0, "percentage": 0.0}

    # Data Science Commentary on visuals
    commentary = []
    if len(location_summary) >= 2:
        loc_gap = round(((location_summary[0]["weight_kg"] - location_summary[1]["weight_kg"]) / location_summary[1]["weight_kg"]) * 100, 1) if location_summary[1]["weight_kg"] > 0 else 0
        commentary.append(
            f"The {top_loc['location']} emerged as the highest waste-producing facility with {top_loc['weight_kg']} kg ({top_loc['percentage']}% of campus waste), generating {loc_gap}% more volume than {location_summary[1]['location']} ({location_summary[1]['weight_kg']} kg)."
        )
    if len(category_summary) >= 2:
        commentary.append(
            f"{top_cat['category']} represents the dominant waste type at {top_cat['percentage']}% ({top_cat['weight_kg']} kg), exceeding {category_summary[1]['category']} at {category_summary[1]['percentage']}% ({category_summary[1]['weight_kg']} kg)."
        )

    # Actionable Recommendations
    recommendations = []
    if top_loc["location"] == "Canteen":
        recommendations.append({
            "target": "Canteen & Dining Facilities",
            "priority": "High",
            "action": "Deploy on-site bio-digester or aerobic composting unit to treat food waste at source, preventing organic degradation in general landfill bins."
        })
    elif top_loc["location"] == "Hostel":
        recommendations.append({
            "target": "Hostels & Residential Halls",
            "priority": "High",
            "action": "Introduce dual-bin source segregation in common rooms and install automated reverse-vending machines for plastic bottle buy-backs."
        })

    if any(c["category"] == "Plastic Waste" and c["percentage"] > 20 for c in category_summary):
        recommendations.append({
            "target": "Plastic Waste Reduction",
            "priority": "High",
            "action": "Enforce campus-wide ban on single-use plastics, install chilled water refill stations, and partner with certified local plastic upcycling vendors."
        })

    if any(c["category"] == "Paper Waste" and c["percentage"] > 15 for c in category_summary):
        recommendations.append({
            "target": "Academic & Admin Paper Reduction",
            "priority": "Medium",
            "action": "Mandate digital-first submission for lab manuals and assignments; institute centralized shredding and recycling pickups for administrative files."
        })

    recommendations.append({
        "target": "Smart Monitoring & Student Engagement",
        "priority": "Continuous",
        "action": "Conduct monthly inter-hostel waste reduction hackathons and display real-time EcoCampus analytics screens at main college entrances."
    })

    # Methodological Limitations & Analytical Challenges
    limitations = [
        {
            "title": "Data Accuracy & Human Recording Error",
            "description": "Manual log entry introduces potential transposition errors, handwriting ambiguities, or slight weight miscalibrations on physical analog scales."
        },
        {
            "title": "Incomplete Data & Empty Collection Days",
            "description": "Unrecorded bins or unmeasured collection cycles during weekends and public holidays lead to conservative aggregate estimates."
        },
        {
            "title": "Time Horizon & Seasonal Variability",
            "description": "A short time frame may not capture exam periods, college fests, or monsoon holidays when campus occupancy fluctuates significantly."
        },
        {
            "title": "Sampling Point Bias",
            "description": "Audits conducted predominantly at primary exterior bins may miss micro-waste streams within individual research laboratories or department offices."
        },
        {
            "title": "Category Ambiguity & Mixed Waste",
            "description": "Contaminated recyclables (e.g., greasy pizza boxes or unrinsed plastic beverage bottles) blur strict boundary definitions between compostable and recyclable streams."
        },
        {
            "title": "Single-Factor Metric (Weight Focus)",
            "description": "Measuring solely by mass (kg) does not account for spatial volume (e.g., lightweight uncompacted styrofoam), hazardous toxicity, or municipal tipping fees."
        }
    ]

    return {
        "project_title": "EcoCampus – Campus Waste Generation Analysis",
        "organization": "Campus Sustainability & Waste Management Office",
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "period_type": period_type,
        "reporting_period": period_label,
        "date_start": p_start.strftime("%Y-%m-%d"),
        "date_end": p_end.strftime("%Y-%m-%d"),
        "summary": {
            "total_waste_kg": round(total_weight, 1),
            "records_count": records_count,
            "locations_count": locations_count,
            "daily_average_kg": daily_avg,
            "highest_waste_location": top_loc,
            "dominant_waste_category": top_cat
        },
        "location_analysis": location_summary,
        "category_analysis": category_summary,
        "commentary": commentary,
        "recommendations": recommendations,
        "limitations": limitations
    }
