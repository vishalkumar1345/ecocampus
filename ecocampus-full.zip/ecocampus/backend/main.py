import io
import os
from datetime import datetime
from typing import Optional

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Query, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles
import pandas as pd

from database import get_db, init_db
from models import WasteRecordCreate, WasteRecordUpdate, ConfirmImportRequest, BatchRecordCreate
from seed_data import seed_database
import analytics
import importer
import reports

app = FastAPI(
    title="EcoCampus API",
    description="Campus Waste Generation Analysis Backend",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def startup_event():
    init_db()
    # Clean start from fresh state; no demo records auto-seeded

@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "app": "EcoCampus – Campus Waste Generation Analysis",
        "platform": "Campus Sustainability Analytics",
        "tagline": "Measure Waste Today. Create a Greener Tomorrow."
    }

# Records CRUD
@app.get("/api/records")
def list_records(
    page: int = Query(1, ge=1),
    page_size: int = Query(15, ge=1, le=100),
    search: Optional[str] = None,
    location: Optional[str] = None,
    category: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    sort_by: str = Query("date", pattern="^(date|weight_kg|record_id|campus_location|waste_category)$"),
    sort_order: str = Query("desc", pattern="^(asc|desc)$")
):
    with get_db() as conn:
        cursor = conn.cursor()
        conditions = ["1=1"]
        params = []

        if search:
            s = f"%{search.strip()}%"
            conditions.append("(record_id LIKE ? OR campus_location LIKE ? OR waste_category LIKE ? OR remarks LIKE ?)")
            params.extend([s, s, s, s])

        if location and location != "All Locations":
            conditions.append("campus_location = ?")
            params.append(location)

        if category and category != "All Categories":
            conditions.append("waste_category = ?")
            params.append(category)

        if start_date:
            conditions.append("date >= ?")
            params.append(start_date)

        if end_date:
            conditions.append("date <= ?")
            params.append(end_date)

        where_clause = " AND ".join(conditions)

        # Count total
        cursor.execute(f"SELECT COUNT(*) FROM waste_records WHERE {where_clause}", params)
        total_count = cursor.fetchone()[0]

        order_dir = "ASC" if sort_order.lower() == "asc" else "DESC"
        offset = (page - 1) * page_size
        
        cursor.execute(f"""
            SELECT id, record_id, date, campus_location, waste_category, weight_kg, remarks, is_demo, created_at
            FROM waste_records
            WHERE {where_clause}
            ORDER BY {sort_by} {order_dir}, id DESC
            LIMIT ? OFFSET ?
        """, params + [page_size, offset])
        
        rows = [dict(r) for r in cursor.fetchall()]
        for r in rows:
            r["is_demo"] = bool(r["is_demo"])

        cursor.execute("SELECT DISTINCT campus_location FROM waste_records ORDER BY campus_location ASC")
        all_locations = [r[0] for r in cursor.fetchall() if r[0]]

        cursor.execute("SELECT DISTINCT waste_category FROM waste_records ORDER BY waste_category ASC")
        all_categories = [r[0] for r in cursor.fetchall() if r[0]]

        return {
            "records": rows,
            "total": total_count,
            "page": page,
            "page_size": page_size,
            "total_pages": max(1, (total_count + page_size - 1) // page_size),
            "available_locations": all_locations,
            "available_categories": all_categories
        }

@app.post("/api/records")
def create_record(item: WasteRecordCreate):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT MAX(id) FROM waste_records")
        max_id = cursor.fetchone()[0] or 1000
        rec_id = f"ECO-REC-{max_id + 1}"
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        loc_clean = analytics.standardize_location(item.campus_location)
        cat_clean = analytics.standardize_category(item.waste_category)

        cursor.execute("""
            INSERT INTO waste_records 
            (record_id, date, campus_location, waste_category, weight_kg, remarks, is_demo, created_at)
            VALUES (?, ?, ?, ?, ?, ?, 0, ?)
        """, (rec_id, item.date, loc_clean, cat_clean, round(float(item.weight_kg), 2), item.remarks or "", now_str))
        new_id = cursor.lastrowid
        
        cursor.execute("SELECT * FROM waste_records WHERE id = ?", (new_id,))
        created = dict(cursor.fetchone())
        created["is_demo"] = bool(created["is_demo"])
        return created

@app.post("/api/records/batch")
def create_records_batch(batch: BatchRecordCreate):
    if not batch.records:
        raise HTTPException(status_code=400, detail="No records provided in batch")
    
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT MAX(id) FROM waste_records")
        current_max = cursor.fetchone()[0] or 1000
        
        insert_rows = []
        for item in batch.records:
            current_max += 1
            rec_id = f"ECO-REC-{current_max}"
            loc_clean = analytics.standardize_location(item.campus_location)
            cat_clean = analytics.standardize_category(item.waste_category)
            w = round(float(item.weight_kg), 2)
            if w <= 0:
                continue
            insert_rows.append((
                rec_id, item.date, loc_clean, cat_clean, w, item.remarks or "", 0, now_str
            ))
            
        if not insert_rows:
            raise HTTPException(status_code=400, detail="No valid records to save (weights must be > 0)")
            
        cursor.executemany("""
            INSERT INTO waste_records
            (record_id, date, campus_location, waste_category, weight_kg, remarks, is_demo, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, insert_rows)
        created_count = len(insert_rows)
        
    return {
        "success": True,
        "inserted_count": created_count,
        "message": f"Successfully created {created_count} manual waste records in the database."
    }

@app.put("/api/records/{record_id}")
def update_record(record_id: int, item: WasteRecordUpdate):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM waste_records WHERE id = ?", (record_id,))
        row = cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Waste record not found")

        updates = []
        params = []
        if item.date is not None:
            updates.append("date = ?")
            params.append(item.date)
        if item.campus_location is not None:
            updates.append("campus_location = ?")
            params.append(analytics.standardize_location(item.campus_location))
        if item.waste_category is not None:
            updates.append("waste_category = ?")
            params.append(analytics.standardize_category(item.waste_category))
        if item.weight_kg is not None:
            updates.append("weight_kg = ?")
            params.append(round(float(item.weight_kg), 2))
        if item.remarks is not None:
            updates.append("remarks = ?")
            params.append(item.remarks)

        if updates:
            params.append(record_id)
            cursor.execute(f"UPDATE waste_records SET {', '.join(updates)} WHERE id = ?", params)

        cursor.execute("SELECT * FROM waste_records WHERE id = ?", (record_id,))
        updated = dict(cursor.fetchone())
        updated["is_demo"] = bool(updated["is_demo"])
        return updated

@app.delete("/api/records/{record_id}")
def delete_record(record_id: int):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM waste_records WHERE id = ?", (record_id,))
        row = cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Waste record not found")
        cursor.execute("DELETE FROM waste_records WHERE id = ?", (record_id,))
        return {"success": True, "message": f"Record {row['record_id']} deleted successfully"}

@app.post("/api/records/clear-all")
def clear_all_records():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM waste_records;")
    return {"success": True, "message": "All records cleared. Database is empty and ready for fresh data."}

@app.post("/api/records/load-benchmark-sample")
def load_benchmark_sample():
    """
    Loads the exact 5 illustrative records from the problem brief:
    Canteen (Food: 15kg), Classroom (Paper: 8kg), Hostel (Plastic: 12kg),
    Library (Paper: 5kg), Playground (Plastic: 6kg).
    """
    benchmark_records = [
        {"record_id": "ECO-BENCH-01", "date": "2026-11-20", "campus_location": "Canteen", "waste_category": "Organic / Food Waste", "weight_kg": 15.0, "remarks": "[BENCHMARK BRIEF] Illustrative 15 kg canteen food waste record from project brief", "is_demo": 1},
        {"record_id": "ECO-BENCH-02", "date": "2026-11-20", "campus_location": "Classrooms", "waste_category": "Paper Waste", "weight_kg": 8.0, "remarks": "[BENCHMARK BRIEF] Illustrative 8 kg classroom paper waste record from project brief", "is_demo": 1},
        {"record_id": "ECO-BENCH-03", "date": "2026-11-20", "campus_location": "Hostel", "waste_category": "Plastic Waste", "weight_kg": 12.0, "remarks": "[BENCHMARK BRIEF] Illustrative 12 kg hostel plastic waste record from project brief", "is_demo": 1},
        {"record_id": "ECO-BENCH-04", "date": "2026-11-20", "campus_location": "Library", "waste_category": "Paper Waste", "weight_kg": 5.0, "remarks": "[BENCHMARK BRIEF] Illustrative 5 kg library paper waste record from project brief", "is_demo": 1},
        {"record_id": "ECO-BENCH-05", "date": "2026-11-20", "campus_location": "Playground", "waste_category": "Plastic Waste", "weight_kg": 6.0, "remarks": "[BENCHMARK BRIEF] Illustrative 6 kg playground plastic waste record from project brief", "is_demo": 1},
    ]

    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for r in benchmark_records:
        r["created_at"] = now_str

    with get_db() as conn:
        cursor = conn.cursor()
        # Clear existing and replace with pure benchmark dataset
        cursor.execute("DELETE FROM waste_records;")
        cursor.executemany("""
            INSERT INTO waste_records 
            (record_id, date, campus_location, waste_category, weight_kg, remarks, is_demo, created_at)
            VALUES (:record_id, :date, :campus_location, :waste_category, :weight_kg, :remarks, :is_demo, :created_at)
        """, benchmark_records)

    return {
        "success": True,
        "message": "Loaded exact 5 benchmark rows from project brief (Canteen: 15kg, Classroom: 8kg, Hostel: 12kg, Library: 5kg, Playground: 6kg).",
        "records_loaded": len(benchmark_records)
    }

# Analytics Routes
@app.get("/api/analytics/dashboard")
def dashboard_analytics(
    filter: str = Query("last_30_days", pattern="^(today|last_7_days|last_30_days|this_month|all|custom)$"),
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    location: Optional[str] = None,
    category: Optional[str] = None
):
    return analytics.get_dashboard_analytics(filter, start_date, end_date, location, category)

@app.get("/api/analytics/locations")
def location_analytics():
    return analytics.get_location_analysis()

@app.get("/api/analytics/categories")
def category_analytics():
    return analytics.get_category_analysis()

# Upload Routes
@app.post("/api/upload/preview")
async def upload_preview(file: UploadFile = File(...)):
    filename = file.filename or "upload.csv"
    ext = os.path.splitext(filename)[1].lower()
    if ext not in [".csv", ".xlsx", ".xls", ".ods", ".odf"]:
        raise HTTPException(status_code=400, detail="Only CSV, Excel (.xlsx, .xls), or ODF (.ods, .odf) files are supported")

    content = await file.read()
    file_id, temp_path, ext = importer.save_temp_file(content, filename)
    
    try:
        preview_data = importer.preview_upload_file(file_id, ext)
        preview_data["filename"] = filename
        preview_data["file_size_kb"] = round(len(content) / 1024, 2)
        preview_data["extension"] = ext
        return preview_data
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to parse file: {str(e)}")

@app.post("/api/upload/confirm")
def upload_confirm(req: ConfirmImportRequest):
    matching = [f for f in os.listdir(importer.UPLOAD_DIR) if f.startswith(req.temp_file_id)]
    if not matching:
        raise HTTPException(status_code=404, detail="File session expired or already imported.")
    
    ext = os.path.splitext(matching[0])[1].lower()
    try:
        res = importer.process_and_import(req.temp_file_id, ext, req.column_mapping, req.skip_duplicates)
        return res
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Reports & Exports
@app.get("/api/reports/summary")
def get_report_summary(
    period_type: str = Query("monthly", pattern="^(daily|weekly|monthly|custom)$"),
    start_date: Optional[str] = None,
    end_date: Optional[str] = None
):
    return reports.generate_report_data(period_type, start_date, end_date)

@app.get("/api/export/csv")
def export_csv():
    with get_db() as conn:
        df = pd.read_sql_query("SELECT record_id, date, campus_location, waste_category, weight_kg, remarks, is_demo, created_at FROM waste_records ORDER BY date DESC", conn)
    
    output = io.StringIO()
    df.to_csv(output, index=False)
    output.seek(0)
    
    filename = f"ecocampus_waste_records_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

@app.get("/api/export/excel")
def export_excel():
    with get_db() as conn:
        df = pd.read_sql_query("SELECT record_id, date, campus_location, waste_category, weight_kg, remarks, is_demo, created_at FROM waste_records ORDER BY date DESC", conn)
    
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="WasteRecords")
    output.seek(0)
    
    filename = f"ecocampus_waste_records_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

@app.get("/api/sample-csv")
def download_sample_csv():
    # Includes exact benchmark records from project brief at top!
    sample_rows = [
        {"Date": "2026-11-20", "Location": "Canteen", "Waste type": "Food", "Weight (kg)": 15.0, "Remarks": "Project brief benchmark sample"},
        {"Date": "2026-11-20", "Location": "Classroom", "Waste type": "Paper", "Weight (kg)": 8.0, "Remarks": "Project brief benchmark sample"},
        {"Date": "2026-11-20", "Location": "Hostel", "Waste type": "Plastic", "Weight (kg)": 12.0, "Remarks": "Project brief benchmark sample"},
        {"Date": "2026-11-20", "Location": "Library", "Waste type": "Paper", "Weight (kg)": 5.0, "Remarks": "Project brief benchmark sample"},
        {"Date": "2026-11-20", "Location": "Playground", "Waste type": "Plastic", "Weight (kg)": 6.0, "Remarks": "Project brief benchmark sample"},
        {"Date": "2026-11-19", "Location": "Labs", "Waste type": "Glass", "Weight (kg)": 7.5, "Remarks": "Test vials & slide scraps"},
        {"Date": "2026-11-19", "Location": "Admin Block", "Waste type": "Paper", "Weight (kg)": 11.2, "Remarks": "Archival document recycling"}
    ]
    df = pd.DataFrame(sample_rows)
    output = io.StringIO()
    df.to_csv(output, index=False)
    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=ecocampus_sample_template.csv"}
    )

# Static Frontend SPA Serving (For Single-Port Live Production Deployment)
FRONTEND_DIST = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend", "dist"))
if os.path.exists(FRONTEND_DIST):
    # Mount assets folder
    assets_dir = os.path.join(FRONTEND_DIST, "assets")
    if os.path.exists(assets_dir):
        app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

    # SPA catch-all route for production hosting
    @app.get("/{full_path:path}")
    def serve_frontend_spa(full_path: str):
        if full_path.startswith("api/"):
            raise HTTPException(status_code=404, detail="API endpoint not found")
        file_path = os.path.join(FRONTEND_DIST, full_path)
        if os.path.isfile(file_path):
            return FileResponse(file_path)
        index_file = os.path.join(FRONTEND_DIST, "index.html")
        if os.path.isfile(index_file):
            return FileResponse(index_file)
        raise HTTPException(status_code=404, detail="Frontend build index.html not found")
