import os
import uuid
import pandas as pd
import numpy as np
from datetime import datetime
from database import get_db
from analytics import standardize_location, standardize_category

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads_temp")
os.makedirs(UPLOAD_DIR, exist_ok=True)

EXPECTED_FIELDS = {
    "date": ["date", "timestamp", "recorded_date", "day", "time"],
    "campus_location": ["campus_location", "location", "building", "area", "campus_area", "place", "site", "department"],
    "waste_category": ["waste_category", "waste_type", "category", "type", "material", "waste type"],
    "weight_kg": ["weight_kg", "weight", "waste_generated (kg)", "waste_generated(kg)", "weight(kg)", "weight_(kg)", "kg", "amount_kg", "quantity_kg", "mass"],
    "remarks": ["remarks", "remark", "notes", "note", "comment", "description"]
}

def guess_column_mapping(columns):
    mapping = {}
    cols_lower = {str(col).strip().lower(): col for col in columns}
    
    for field, candidates in EXPECTED_FIELDS.items():
        found = None
        for cand in candidates:
            if cand in cols_lower:
                found = cols_lower[cand]
                break
        if not found:
            for c_clean, orig in cols_lower.items():
                if field in c_clean or any(cand in c_clean for cand in candidates):
                    found = orig
                    break
        mapping[field] = found
    return mapping

def save_temp_file(file_bytes, filename):
    file_id = str(uuid.uuid4())
    ext = os.path.splitext(filename)[1].lower()
    temp_path = os.path.join(UPLOAD_DIR, f"{file_id}{ext}")
    with open(temp_path, "wb") as f:
        f.write(file_bytes)
    return file_id, temp_path, ext

def read_uploaded_dataframe(file_path, ext):
    if ext in [".xlsx", ".xls"]:
        df = pd.read_excel(file_path, engine="openpyxl")
    elif ext in [".ods", ".odf"]:
        df = pd.read_excel(file_path, engine="odf")
    else:
        # CSV with robust delimiter detection
        try:
            df = pd.read_csv(file_path)
        except Exception:
            df = pd.read_csv(file_path, sep=";")
    return df

def preview_upload_file(file_id, ext):
    temp_path = os.path.join(UPLOAD_DIR, f"{file_id}{ext}")
    if not os.path.exists(temp_path):
        raise FileNotFoundError("Uploaded temporary file not found.")

    df = read_uploaded_dataframe(temp_path, ext)
    total_rows = len(df)
    columns = [str(c) for c in df.columns]
    mapping = guess_column_mapping(columns)

    # Detect duplicate rows in file using pandas duplicated()
    file_duplicates = int(df.duplicated().sum())

    # Sample preview rows (up to 10)
    preview_rows = df.head(10).replace({np.nan: None}).to_dict(orient="records")

    # Missing value count per column using pandas isna().sum()
    missing_summary = {str(c): int(df[c].isna().sum()) for c in df.columns}

    return {
        "file_id": file_id,
        "total_rows": total_rows,
        "columns": columns,
        "suggested_mapping": mapping,
        "file_duplicates": file_duplicates,
        "missing_summary": missing_summary,
        "preview_rows": preview_rows
    }

def process_and_import(file_id, ext, column_mapping, skip_duplicates=True):
    temp_path = os.path.join(UPLOAD_DIR, f"{file_id}{ext}")
    if not os.path.exists(temp_path):
        raise FileNotFoundError("Temporary file expired or not found.")

    df = read_uploaded_dataframe(temp_path, ext)
    
    # Existing DB records to avoid duplicate insertion
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT date, campus_location, waste_category, weight_kg FROM waste_records")
        existing_keys = set((r[0], r[1].lower(), r[2].lower(), round(float(r[3]), 2)) for r in cursor.fetchall())
        
        cursor.execute("SELECT MAX(id) FROM waste_records")
        max_id_row = cursor.fetchone()
        next_seq = (max_id_row[0] or 1000) + 1

    valid_records = []
    invalid_records = []
    duplicate_records = []

    date_col = column_mapping.get("date")
    loc_col = column_mapping.get("campus_location")
    cat_col = column_mapping.get("waste_category")
    weight_col = column_mapping.get("weight_kg")
    remarks_col = column_mapping.get("remarks")

    if not all([date_col, loc_col, cat_col, weight_col]):
        raise ValueError("Missing required column mappings for Date, Location, Waste Category, or Weight.")

    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    for idx, row in df.iterrows():
        row_num = idx + 1
        errors = []

        # 1. Validate & Parse Date (Handles mixed formats like '2026-11-20', '20 Nov 2026', '11/20/2026')
        raw_date = row.get(date_col)
        parsed_date = None
        if pd.isna(raw_date) or not str(raw_date).strip():
            errors.append("Missing date entry")
        else:
            try:
                parsed_date = pd.to_datetime(raw_date).strftime("%Y-%m-%d")
            except Exception:
                errors.append(f"Invalid date format: '{raw_date}'")

        # 2. Validate & Standardize Location
        raw_loc = row.get(loc_col)
        if pd.isna(raw_loc) or not str(raw_loc).strip():
            errors.append("Missing campus location")
            loc_standard = ""
        else:
            loc_standard = standardize_location(raw_loc)

        # 3. Validate & Standardize Category (e.g. 'food' -> 'Organic / Food Waste')
        raw_cat = row.get(cat_col)
        if pd.isna(raw_cat) or not str(raw_cat).strip():
            errors.append("Missing waste category")
            cat_standard = ""
        else:
            cat_standard = standardize_category(raw_cat)

        # 4. Validate Numerical Weight (Sanity check: weight > 0, float coercion)
        raw_weight = row.get(weight_col)
        parsed_weight = None
        try:
            val = float(str(raw_weight).replace("kg", "").replace("KG", "").replace("Kg", "").strip())
            if val <= 0:
                errors.append(f"Sanity check failed: Weight must be > 0 kg (got {val})")
            else:
                parsed_weight = round(val, 2)
        except Exception:
            errors.append(f"Non-numeric weight value: '{raw_weight}'")

        # 5. Remarks
        raw_remarks = row.get(remarks_col) if remarks_col else ""
        remarks_str = str(raw_remarks).strip() if not pd.isna(raw_remarks) and str(raw_remarks).lower() != "nan" else ""

        if errors:
            invalid_records.append({
                "row_number": row_num,
                "data": row.replace({np.nan: None}).to_dict(),
                "errors": errors
            })
            continue

        # 6. Duplicate detection (checking date + location + category + weight)
        key = (parsed_date, loc_standard.lower(), cat_standard.lower(), parsed_weight)
        if key in existing_keys:
            if skip_duplicates:
                duplicate_records.append({
                    "row_number": row_num,
                    "reason": f"Duplicate matching existing database entry on {parsed_date} at {loc_standard}"
                })
                continue

        rec_id = f"ECO-IMP-{next_seq}"
        next_seq += 1

        record = {
            "record_id": rec_id,
            "date": parsed_date,
            "campus_location": loc_standard,
            "waste_category": cat_standard,
            "weight_kg": parsed_weight,
            "remarks": remarks_str or "Imported via dataset file",
            "is_demo": 0,
            "created_at": now_str
        }
        valid_records.append(record)
        existing_keys.add(key)

    # Insert valid records
    if valid_records:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.executemany("""
                INSERT INTO waste_records 
                (record_id, date, campus_location, waste_category, weight_kg, remarks, is_demo, created_at)
                VALUES (:record_id, :date, :campus_location, :waste_category, :weight_kg, :remarks, :is_demo, :created_at)
            """, valid_records)

    # Cleanup temp file
    try:
        os.remove(temp_path)
    except Exception:
        pass

    return {
        "success": True,
        "imported_count": len(valid_records),
        "invalid_count": len(invalid_records),
        "duplicate_count": len(duplicate_records),
        "invalid_records": invalid_records[:30],
        "duplicate_records": duplicate_records[:30]
    }
