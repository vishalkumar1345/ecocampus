/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Modern Oceanic Cyber Slate & Electric Emerald
        forest: {
          50: '#F0FDF8',  // Crisp mint frost
          100: '#E1FAF0', // Soft mint highlight
          200: '#C3F4DE', // Clean energetic mint
          300: '#8FE7C3', // Vivid mint
          400: '#34D399', // Bright emerald mint
          500: '#00D084', // Electric Emerald (Vibrant, high-tech)
          600: '#059669', // Deep Emerald
          700: '#047857', // Forest Jade
          800: '#0D272C', // Deep Oceanic Slate / Cyber Forest
          850: '#091F24', // Card dark background
          900: '#06161A', // Primary dark background
          950: '#030C0E', // Deepest void
        },
        cyan: {
          50: '#ECFEFF',
          100: '#CFFAFE',
          200: '#A5F3FC',
          300: '#67E8F9',
          400: '#22D3EE',
          500: '#06B6D4',
          600: '#0891B2',
          700: '#0E7490',
          800: '#155E75',
          900: '#164E63',
          950: '#083344',
        },
        aurora: {
          emerald: '#00F59B',
          cyan: '#00E5FF',
          blue: '#3B82F6',
          purple: '#8B5CF6',
        },
        mint: {
          DEFAULT: '#E6F8F0',
          light: '#F4FCF8',
          dark: '#B8EDD7'
        },
        surface: {
          light: '#F4FAF7',
          card: '#FFFFFF',
          dark: '#06161A',
          darkcard: '#0B2329',
          darkborder: '#143C45'
        },
        ink: {
          DEFAULT: '#0B221F',
          muted: '#3D5E57',
          light: '#729890'
        }
      },
      fontFamily: {
        sans: ['Plus Jakarta Sans', 'Inter', 'system-ui', '-apple-system', 'sans-serif'],
        display: ['Outfit', 'Plus Jakarta Sans', 'sans-serif']
      },
      boxShadow: {
        'glow': '0 0 30px -4px rgba(0, 245, 155, 0.40)',
        'glow-cyan': '0 0 35px -5px rgba(0, 229, 255, 0.45)',
        'glow-lg': '0 0 65px -8px rgba(0, 245, 155, 0.55)',
        'glow-ambient': '0 15px 45px -10px rgba(6, 22, 26, 0.35), 0 0 40px 4px rgba(0, 245, 155, 0.20)',
        'lighting-card': '0 1px 3px 0 rgba(0, 0, 0, 0.04), 0 16px 32px -6px rgba(12, 39, 44, 0.08), inset 0 1px 0 0 rgba(255, 255, 255, 0.9)',
        'lighting-card-dark': '0 18px 40px -6px rgba(0, 0, 0, 0.6), inset 0 1px 0 0 rgba(0, 229, 255, 0.15)',
        'premium': '0 10px 30px -10px rgba(12, 39, 44, 0.08), 0 4px 6px -2px rgba(12, 39, 44, 0.03)',
        'premium-hover': '0 25px 50px -12px rgba(12, 39, 44, 0.18), 0 10px 15px -4px rgba(0, 245, 155, 0.18)',
        '3d-depth': '0 20px 40px -15px rgba(0, 0, 0, 0.25), 0 0 25px 2px rgba(0, 245, 155, 0.15)'
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'pulse-subtle': 'pulseSubtle 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'shimmer': 'shimmer 2.5s linear infinite',
        'light-sweep': 'lightSweep 8s ease-in-out infinite',
        'spin-slow': 'spin 20s linear infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px) rotate(0deg)' },
          '50%': { transform: 'translateY(-10px) rotate(2deg)' },
        },
        pulseSubtle: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.7' },
        },
        shimmer: {
          '100%': { transform: 'translateX(100%)' }
        },
        lightSweep: {
          '0%, 100%': { opacity: '0.3', transform: 'translateX(-20%) translateY(-10%)' },
          '50%': { opacity: '0.7', transform: 'translateX(20%) translateY(10%)' }
        }
      }
    },
  },
  plugins: [],
}
