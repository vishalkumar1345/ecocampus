// Hybrid API Client & In-Browser Data Science Engine for EcoCampus
// Seamlessly connects to live FastAPI backend when available, and automatically
// falls back to the client-side In-Browser Engine when running on static hosts
// (Vercel, Netlify, GitHub Pages, or offline) with ZERO "Unexpected token <" errors!

const API_BASE = import.meta.env.VITE_API_BASE_URL || (
  typeof window !== 'undefined' && (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')
    ? 'http://127.0.0.1:8000/api'
    : '/api'
);

// Standard categories and distinct colors
export const STANDARD_CATEGORIES = [
  'Organic / Food Waste',
  'Plastic Waste',
  'Paper Waste',
  'Glass Waste',
  'Metal Waste',
  'Other Waste'
];

export const CATEGORY_COLORS = {
  "Organic / Food Waste": "#10B981",
  "Plastic Waste": "#0284C7",
  "Paper Waste": "#F59E0B",
  "Metal Waste": "#9333EA",
  "Glass Waste": "#6366F1",
  "Other Waste": "#64748B"
};

export const STANDARD_LOCATIONS = [
  'Canteen',
  'Hostel',
  'Classrooms',
  'Library',
  'Playground',
  'Labs',
  'Admin Block',
  'Auditorium'
];

// Helper: Standardize location name
export function standardizeLocation(raw = '') {
  const s = String(raw).trim().toLowerCase();
  if (s.includes('canteen') || s.includes('mess') || s.includes('cafeteria') || s.includes('dining')) return 'Canteen';
  if (s.includes('hostel') || s.includes('dorm') || s.includes('residence')) return 'Hostel';
  if (s.includes('class') || s.includes('academic') || s.includes('lecture')) return 'Classrooms';
  if (s.includes('lib')) return 'Library';
  if (s.includes('ground') || s.includes('sport') || s.includes('athletic')) return 'Playground';
  if (s.includes('lab')) return 'Labs';
  if (s.includes('admin') || s.includes('office')) return 'Admin Block';
  if (s.includes('audit') || s.includes('hall')) return 'Auditorium';
  return raw.trim() || 'General Campus';
}

// Helper: Standardize category name
export function standardizeCategory(raw = '') {
  const s = String(raw).trim().toLowerCase();
  if (s.includes('food') || s.includes('org') || s.includes('wet') || s.includes('compost')) return 'Organic / Food Waste';
  if (s.includes('plas') || s.includes('pet') || s.includes('bottle')) return 'Plastic Waste';
  if (s.includes('pap') || s.includes('card') || s.includes('book')) return 'Paper Waste';
  if (s.includes('glass') || s.includes('vial')) return 'Glass Waste';
  if (s.includes('metal') || s.includes('can') || s.includes('tin') || s.includes('alum')) return 'Metal Waste';
  return 'Other Waste';
}

// Local Storage Keys
const STORAGE_KEY = 'ecocampus_records_data_v2';
const TEMPLATE_CACHE_KEY = 'ecocampus_temp_file_cache';

// Load raw records from localStorage
function getLocalRecords() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    return [];
  }
}

// Save records to localStorage
function saveLocalRecords(records) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  } catch (e) {
    console.error('LocalStorage write error:', e);
  }
}

// Benchmark sample rows from academic brief
const BENCHMARK_BRIEF_ROWS = [
  { record_id: "ECO-BENCH-01", date: "2026-11-20", campus_location: "Canteen", waste_category: "Organic / Food Waste", weight_kg: 15.0, remarks: "[BENCHMARK BRIEF] Illustrative 15 kg canteen food waste record from project brief", is_demo: true, id: 1001 },
  { record_id: "ECO-BENCH-02", date: "2026-11-20", campus_location: "Classrooms", waste_category: "Paper Waste", weight_kg: 8.0, remarks: "[BENCHMARK BRIEF] Illustrative 8 kg classroom paper waste record from project brief", is_demo: true, id: 1002 },
  { record_id: "ECO-BENCH-03", date: "2026-11-20", campus_location: "Hostel", waste_category: "Plastic Waste", weight_kg: 12.0, remarks: "[BENCHMARK BRIEF] Illustrative 12 kg hostel plastic waste record from project brief", is_demo: true, id: 1003 },
  { record_id: "ECO-BENCH-04", date: "2026-11-20", campus_location: "Library", waste_category: "Paper Waste", weight_kg: 5.0, remarks: "[BENCHMARK BRIEF] Illustrative 5 kg library paper waste record from project brief", is_demo: true, id: 1004 },
  { record_id: "ECO-BENCH-05", date: "2026-11-20", campus_location: "Playground", waste_category: "Plastic Waste", weight_kg: 6.0, remarks: "[BENCHMARK BRIEF] Illustrative 6 kg playground plastic waste record from project brief", is_demo: true, id: 1005 }
];

/**
 * Safe fetch wrapper:
 * If the response is HTML (e.g. <!doctype from a static SPA host) or non-JSON,
 * it safely throws an error so our client-side In-Browser Engine takes over immediately
 * WITHOUT throwing SyntaxError "Unexpected token <"!
 */
async function safeFetchJson(url, options = {}) {
  const res = await fetch(url, options);
  
  // Guard against HTML responses from static hosting redirects (e.g. Netlify/Vercel SPA catch-alls)
  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('text/html')) {
    throw new Error('BACKEND_HTML_REDIRECT');
  }

  const text = await res.text();
  const trimmed = text.trim();
  if (
    trimmed.startsWith('<') || 
    trimmed.toLowerCase().startsWith('<!doctype') ||
    trimmed.includes('<html') ||
    trimmed.includes('<head') ||
    trimmed.includes('<body')
  ) {
    throw new Error('BACKEND_HTML_REDIRECT');
  }

  if (!res.ok) {
    let errMsg = `HTTP ${res.status}`;
    try {
      const errObj = JSON.parse(text);
      errMsg = errObj.detail || errObj.message || errMsg;
    } catch (_) {}
    throw new Error(errMsg);
  }

  try {
    return JSON.parse(text);
  } catch (parseErr) {
    // If response was not valid JSON, treat as static host fallback instead of crashing
    throw new Error('BACKEND_HTML_REDIRECT');
  }
}

// ----------------------------------------------------------------------
// 1. Health Check
// ----------------------------------------------------------------------
export async function fetchHealth() {
  try {
    return await safeFetchJson(`${API_BASE}/health`);
  } catch (e) {
    // Client-side local engine is online
    return {
      status: "healthy",
      mode: "in-browser-hybrid",
      app: "EcoCampus – Campus Waste Generation Analysis",
      platform: "Campus Sustainability Analytics",
      tagline: "Measure Waste Today. Create a Greener Tomorrow."
    };
  }
}

// ----------------------------------------------------------------------
// 2. Fetch Records (CRUD List)
// ----------------------------------------------------------------------
export async function fetchRecords({
  page = 1,
  pageSize = 15,
  search = '',
  location = '',
  category = '',
  startDate = '',
  endDate = '',
  sortBy = 'date',
  sortOrder = 'desc'
}) {
  try {
    const params = new URLSearchParams({
      page: String(page),
      page_size: String(pageSize),
      sort_by: sortBy,
      sort_order: sortOrder
    });
    if (search) params.append('search', search);
    if (location && location !== 'All Locations') params.append('location', location);
    if (category && category !== 'All Categories') params.append('category', category);
    if (startDate) params.append('start_date', startDate);
    if (endDate) params.append('end_date', endDate);

    return await safeFetchJson(`${API_BASE}/records?${params.toString()}`);
  } catch (err) {
    // In-Browser Engine Fallback
    let items = getLocalRecords();

    // Filtering
    if (search) {
      const q = search.toLowerCase();
      items = items.filter(r => 
        (r.record_id || '').toLowerCase().includes(q) ||
        (r.campus_location || '').toLowerCase().includes(q) ||
        (r.waste_category || '').toLowerCase().includes(q) ||
        (r.remarks || '').toLowerCase().includes(q)
      );
    }
    if (location && location !== 'All Locations') {
      items = items.filter(r => r.campus_location === location);
    }
    if (category && category !== 'All Categories') {
      items = items.filter(r => r.waste_category === category);
    }
    if (startDate) {
      items = items.filter(r => r.date >= startDate);
    }
    if (endDate) {
      items = items.filter(r => r.date <= endDate);
    }

    // Sorting
    items.sort((a, b) => {
      let valA = a[sortBy] ?? '';
      let valB = b[sortBy] ?? '';
      if (sortBy === 'weight_kg') {
        valA = Number(valA) || 0;
        valB = Number(valB) || 0;
      }
      if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
      if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });

    const totalCount = items.length;
    const startIndex = (page - 1) * pageSize;
    const paginated = items.slice(startIndex, startIndex + pageSize);

    // Extract available filter values
    const allRecs = getLocalRecords();
    const availableLocations = Array.from(new Set(allRecs.map(r => r.campus_location).filter(Boolean))).sort();
    const availableCategories = Array.from(new Set(allRecs.map(r => r.waste_category).filter(Boolean))).sort();

    return {
      records: paginated,
      total: totalCount,
      page: page,
      page_size: pageSize,
      total_pages: Math.max(1, Math.ceil(totalCount / pageSize)),
      available_locations: availableLocations.length > 0 ? availableLocations : STANDARD_LOCATIONS,
      available_categories: availableCategories.length > 0 ? availableCategories : STANDARD_CATEGORIES
    };
  }
}

// ----------------------------------------------------------------------
// 3. Create Record
// ----------------------------------------------------------------------
export async function createRecord(record) {
  try {
    return await safeFetchJson(`${API_BASE}/records`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(record)
    });
  } catch (err) {
    const records = getLocalRecords();
    const maxId = records.reduce((max, r) => Math.max(max, Number(r.id) || 1000), 1000);
    const newId = maxId + 1;
    const newRecord = {
      id: newId,
      record_id: `ECO-REC-${newId}`,
      date: record.date || new Date().toISOString().split('T')[0],
      campus_location: standardizeLocation(record.campus_location),
      waste_category: standardizeCategory(record.waste_category),
      weight_kg: Math.round(Number(record.weight_kg || 0) * 100) / 100,
      remarks: record.remarks || '',
      is_demo: false,
      created_at: new Date().toISOString().replace('T', ' ').slice(0, 19)
    };
    records.unshift(newRecord);
    saveLocalRecords(records);
    return newRecord;
  }
}

// ----------------------------------------------------------------------
// 4. Batch Create Records
// ----------------------------------------------------------------------
export async function createBatchRecords(batchRecords) {
  try {
    return await safeFetchJson(`${API_BASE}/records/batch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ records: batchRecords })
    });
  } catch (err) {
    const existing = getLocalRecords();
    let maxId = existing.reduce((max, r) => Math.max(max, Number(r.id) || 1000), 1000);
    const nowStr = new Date().toISOString().replace('T', ' ').slice(0, 19);

    const inserted = batchRecords.map(item => {
      maxId += 1;
      return {
        id: maxId,
        record_id: `ECO-REC-${maxId}`,
        date: item.date || new Date().toISOString().split('T')[0],
        campus_location: standardizeLocation(item.campus_location),
        waste_category: standardizeCategory(item.waste_category),
        weight_kg: Math.round(Number(item.weight_kg || 0) * 100) / 100,
        remarks: item.remarks || '',
        is_demo: false,
        created_at: nowStr
      };
    });

    const combined = [...inserted, ...existing];
    saveLocalRecords(combined);
    return { success: true, count: inserted.length };
  }
}

// ----------------------------------------------------------------------
// 5. Update Record
// ----------------------------------------------------------------------
export async function updateRecord(id, record) {
  try {
    return await safeFetchJson(`${API_BASE}/records/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(record)
    });
  } catch (err) {
    const records = getLocalRecords();
    const idx = records.findIndex(r => String(r.id) === String(id));
    if (idx === -1) throw new Error('Record not found');

    const updated = {
      ...records[idx],
      ...(record.date && { date: record.date }),
      ...(record.campus_location && { campus_location: standardizeLocation(record.campus_location) }),
      ...(record.waste_category && { waste_category: standardizeCategory(record.waste_category) }),
      ...(record.weight_kg !== undefined && { weight_kg: Math.round(Number(record.weight_kg) * 100) / 100 }),
      ...(record.remarks !== undefined && { remarks: record.remarks })
    };
    records[idx] = updated;
    saveLocalRecords(records);
    return updated;
  }
}

// ----------------------------------------------------------------------
// 6. Delete Record
// ----------------------------------------------------------------------
export async function deleteRecord(id) {
  try {
    return await safeFetchJson(`${API_BASE}/records/${id}`, {
      method: 'DELETE'
    });
  } catch (err) {
    const records = getLocalRecords();
    const filtered = records.filter(r => String(r.id) !== String(id));
    saveLocalRecords(filtered);
    return { success: true, message: "Record deleted successfully" };
  }
}

// ----------------------------------------------------------------------
// 7. Clear All Records
// ----------------------------------------------------------------------
export async function clearAllRecords() {
  try {
    return await safeFetchJson(`${API_BASE}/records/clear-all`, {
      method: 'POST'
    });
  } catch (err) {
    saveLocalRecords([]);
    return { success: true, message: "All records cleared" };
  }
}

// ----------------------------------------------------------------------
// 8. Load Benchmark Sample (5 Brief Rows)
// ----------------------------------------------------------------------
export async function loadBenchmarkSample() {
  try {
    return await safeFetchJson(`${API_BASE}/records/load-benchmark-sample`, {
      method: 'POST'
    });
  } catch (err) {
    saveLocalRecords(BENCHMARK_BRIEF_ROWS);
    return {
      success: true,
      message: "Loaded exact 5 benchmark rows from project brief (Canteen: 15kg, Classroom: 8kg, Hostel: 12kg, Library: 5kg, Playground: 6kg).",
      records_loaded: BENCHMARK_BRIEF_ROWS.length
    };
  }
}

// ----------------------------------------------------------------------
// 9. Dashboard Analytics (Full Analytical Calculations)
// ----------------------------------------------------------------------
export async function fetchDashboardAnalytics(filter = 'last_30_days', startDate = null, endDate = null, location = null, category = null) {
  try {
    const params = new URLSearchParams({ filter });
    if (startDate) params.append('start_date', startDate);
    if (endDate) params.append('end_date', endDate);
    if (location && location !== 'All Locations') params.append('location', location);
    if (category && category !== 'All Categories') params.append('category', category);

    return await safeFetchJson(`${API_BASE}/analytics/dashboard?${params.toString()}`);
  } catch (err) {
    let records = getLocalRecords();

    // Date filtering
    const now = new Date();
    if (filter === 'today') {
      const todayStr = now.toISOString().split('T')[0];
      records = records.filter(r => r.date === todayStr);
    } else if (filter === 'last_7_days') {
      const cut = new Date(now.getTime() - 7 * 86400000).toISOString().split('T')[0];
      records = records.filter(r => r.date >= cut);
    } else if (filter === 'last_30_days') {
      const cut = new Date(now.getTime() - 30 * 86400000).toISOString().split('T')[0];
      records = records.filter(r => r.date >= cut);
    } else if (filter === 'this_month') {
      const ym = now.toISOString().slice(0, 7);
      records = records.filter(r => r.date.startsWith(ym));
    } else if (filter === 'custom') {
      if (startDate) records = records.filter(r => r.date >= startDate);
      if (endDate) records = records.filter(r => r.date <= endDate);
    }

    if (location && location !== 'All Locations') {
      records = records.filter(r => r.campus_location === location);
    }
    if (category && category !== 'All Categories') {
      records = records.filter(r => r.waste_category === category);
    }

    if (records.length === 0) {
      return {
        total_weight_kg: 0.0,
        locations_count: 0,
        records_count: 0,
        average_record_weight_kg: 0.0,
        average_daily_weight_kg: 0.0,
        top_location: { name: "None", weight_kg: 0.0, percentage: 0.0 },
        top_category: { name: "None", weight_kg: 0.0, percentage: 0.0 },
        location_distribution: [],
        category_distribution: [],
        daily_trend: [],
        monthly_trend: [],
        location_category_matrix: [],
        insights: ["No waste records in active scope. Add or upload campus records to generate insights."],
        data_quality: {
          total_rows_inspected: 0,
          missing_values_count: 0,
          duplicates_found: 0,
          valid_records_pct: 100.0,
          negative_weights_dropped: 0
        }
      };
    }

    const totalWeight = Math.round(records.reduce((sum, r) => sum + (Number(r.weight_kg) || 0), 0) * 10) / 10;
    const recordsCount = records.length;
    const uniqueLocations = Array.from(new Set(records.map(r => r.campus_location)));
    const avgRecordWeight = Math.round((totalWeight / recordsCount) * 10) / 10;

    // Location distribution
    const locMap = {};
    records.forEach(r => {
      const loc = r.campus_location;
      if (!locMap[loc]) locMap[loc] = { weight: 0, count: 0 };
      locMap[loc].weight += Number(r.weight_kg) || 0;
      locMap[loc].count += 1;
    });

    const location_distribution = Object.entries(locMap).map(([loc, data]) => {
      const w = Math.round(data.weight * 10) / 10;
      return {
        location: loc,
        weight_kg: w,
        average_kg: Math.round((w / data.count) * 10) / 10,
        records_count: data.count,
        percentage: totalWeight > 0 ? Math.round((w / totalWeight) * 1000) / 10 : 0
      };
    }).sort((a, b) => b.weight_kg - a.weight_kg);

    // Category distribution
    const catMap = {};
    records.forEach(r => {
      const cat = r.waste_category;
      if (!catMap[cat]) catMap[cat] = { weight: 0, count: 0 };
      catMap[cat].weight += Number(r.weight_kg) || 0;
      catMap[cat].count += 1;
    });

    const category_distribution = Object.entries(catMap).map(([cat, data]) => {
      const w = Math.round(data.weight * 10) / 10;
      return {
        category: cat,
        weight_kg: w,
        records_count: data.count,
        percentage: totalWeight > 0 ? Math.round((w / totalWeight) * 1000) / 10 : 0,
        color: CATEGORY_COLORS[cat] || "#10B981"
      };
    }).sort((a, b) => b.weight_kg - a.weight_kg);

    const topLocation = location_distribution[0] 
      ? { name: location_distribution[0].location, weight_kg: location_distribution[0].weight_kg, percentage: location_distribution[0].percentage }
      : { name: "None", weight_kg: 0.0, percentage: 0.0 };

    const topCategory = category_distribution[0]
      ? { name: category_distribution[0].category, weight_kg: category_distribution[0].weight_kg, percentage: category_distribution[0].percentage }
      : { name: "None", weight_kg: 0.0, percentage: 0.0 };

    // Daily trend
    const dateMap = {};
    records.forEach(r => {
      const d = r.date;
      if (!dateMap[d]) dateMap[d] = { weight: 0, count: 0 };
      dateMap[d].weight += Number(r.weight_kg) || 0;
      dateMap[d].count += 1;
    });

    const sortedDates = Object.keys(dateMap).sort();
    const daily_trend = sortedDates.map((d, i) => {
      const w = Math.round(dateMap[d].weight * 10) / 10;
      // Rolling average calculation
      const windowStart = Math.max(0, i - 6);
      const sub = sortedDates.slice(windowStart, i + 1);
      const sum = sub.reduce((acc, curr) => acc + dateMap[curr].weight, 0);
      const movingAvg = Math.round((sum / sub.length) * 10) / 10;

      return {
        date: d,
        weight_kg: w,
        records_count: dateMap[d].count,
        moving_avg_7d: movingAvg
      };
    });

    // Monthly trend
    const monthMap = {};
    records.forEach(r => {
      const m = r.date.slice(0, 7);
      if (!monthMap[m]) monthMap[m] = { weight: 0, count: 0 };
      monthMap[m].weight += Number(r.weight_kg) || 0;
      monthMap[m].count += 1;
    });
    const monthly_trend = Object.keys(monthMap).sort().map(m => {
      const w = Math.round(monthMap[m].weight * 10) / 10;
      return {
        month: m,
        weight_kg: w,
        average_kg: Math.round((w / monthMap[m].count) * 10) / 10
      };
    });

    // Cross-tab Matrix
    const matrix_list = location_distribution.map(loc => {
      const row = { location: loc.location, total: loc.weight_kg };
      STANDARD_CATEGORIES.forEach(cat => {
        const catSum = records
          .filter(r => r.campus_location === loc.location && r.waste_category === cat)
          .reduce((acc, curr) => acc + Number(curr.weight_kg || 0), 0);
        row[cat] = Math.round(catSum * 10) / 10;
      });
      return row;
    });

    // Generate analytical insights
    const insights = [];
    if (location_distribution.length >= 2) {
      const top = location_distribution[0];
      const second = location_distribution[1];
      const diffPct = second.weight_kg > 0 ? Math.round(((top.weight_kg - second.weight_kg) / second.weight_kg) * 100) : 0;
      insights.push(`The ${top.location} generated the highest waste volume at ${top.weight_kg} kg (${top.percentage}% of total), producing ${diffPct}% more waste than ${second.location} (${second.weight_kg} kg).`);
    } else if (location_distribution.length === 1) {
      insights.push(`${location_distribution[0].location} generated all ${location_distribution[0].weight_kg} kg of audited waste in this scope.`);
    }

    if (category_distribution.length >= 2) {
      const topC = category_distribution[0];
      const secC = category_distribution[1];
      insights.push(`${topC.category} represents the dominant material stream (${topC.percentage}%, ${topC.weight_kg} kg), exceeding ${secC.category} (${secC.percentage}%, ${secC.weight_kg} kg).`);
    }

    const organicTotal = records
      .filter(r => r.waste_category.toLowerCase().includes('food') || r.waste_category.toLowerCase().includes('organic'))
      .reduce((acc, curr) => acc + Number(curr.weight_kg || 0), 0);
    if (organicTotal > 0) {
      const compost = Math.round(organicTotal * 0.45 * 10) / 10;
      insights.push(`Food & organic waste accounts for ${Math.round((organicTotal / totalWeight) * 100)}% (${Math.round(organicTotal * 10) / 10} kg), representing a circular bio-composting potential of ~${compost} kg enriched fertilizer.`);
    }

    return {
      total_weight_kg: totalWeight,
      locations_count: uniqueLocations.length,
      records_count: recordsCount,
      average_record_weight_kg: avgRecordWeight,
      average_daily_weight_kg: Math.round((totalWeight / Math.max(1, sortedDates.length)) * 10) / 10,
      top_location: topLocation,
      top_category: topCategory,
      location_distribution,
      category_distribution,
      daily_trend,
      monthly_trend,
      location_category_matrix: matrix_list,
      insights,
      data_quality: {
        total_rows_inspected: recordsCount,
        missing_values_count: 0,
        duplicates_found: 0,
        valid_records_pct: 100.0,
        negative_weights_dropped: 0
      }
    };
  }
}

// ----------------------------------------------------------------------
// 10. Location Analytics
// ----------------------------------------------------------------------
export async function fetchLocationAnalytics() {
  try {
    return await safeFetchJson(`${API_BASE}/analytics/locations`);
  } catch (err) {
    const records = getLocalRecords();
    if (records.length === 0) return [];

    const totalWeight = records.reduce((acc, r) => acc + (Number(r.weight_kg) || 0), 0);
    const locMap = {};

    records.forEach(r => {
      const loc = r.campus_location;
      if (!locMap[loc]) locMap[loc] = { total: 0, count: 0, categories: {} };
      const w = Number(r.weight_kg) || 0;
      locMap[loc].total += w;
      locMap[loc].count += 1;
      const cat = r.waste_category;
      locMap[loc].categories[cat] = (locMap[loc].categories[cat] || 0) + w;
    });

    const list = Object.entries(locMap).map(([loc, data]) => {
      const topCat = Object.entries(data.categories).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';
      const tot = Math.round(data.total * 10) / 10;
      return {
        location: loc,
        total_weight_kg: tot,
        records_count: data.count,
        average_weight_kg: Math.round((tot / data.count) * 10) / 10,
        campus_share_pct: totalWeight > 0 ? Math.round((tot / totalWeight) * 1000) / 10 : 0,
        top_category: topCat,
        category_breakdown: data.categories,
        weekly_trend_pct: 0,
        last_7_days_kg: tot
      };
    }).sort((a, b) => b.total_weight_kg - a.total_weight_kg);

    list.forEach((item, idx) => {
      item.rank = idx + 1;
    });

    return list;
  }
}

// ----------------------------------------------------------------------
// 11. Category Analytics (Array with Circularity & GHG Metrics)
// ----------------------------------------------------------------------
const RECYCLABILITY_INFO = {
  "Organic / Food Waste": { type: "Compostable", potential_pct: 95, co2e_factor: 0.5, badge: "High Composting Potential" },
  "Plastic Waste": { type: "Recyclable", potential_pct: 80, co2e_factor: 1.5, badge: "Critical Segregation Priority" },
  "Paper Waste": { type: "Recyclable", potential_pct: 90, co2e_factor: 1.0, badge: "High Recyclability" },
  "Metal Waste": { type: "Recyclable", potential_pct: 98, co2e_factor: 2.5, badge: "High Value Scrap" },
  "Glass Waste": { type: "Recyclable", potential_pct: 95, co2e_factor: 0.3, badge: "100% Circular" },
  "Other Waste": { type: "Residual / Landfill", potential_pct: 20, co2e_factor: 0.1, badge: "Minimize at Source" }
};

export async function fetchCategoryAnalytics() {
  try {
    const data = await safeFetchJson(`${API_BASE}/analytics/categories`);
    const list = Array.isArray(data) ? data : (Array.isArray(data?.categories) ? data.categories : []);
    list.categories = list;
    return list;
  } catch (err) {
    const records = getLocalRecords();
    const totalWeight = records.reduce((acc, r) => acc + (Number(r.weight_kg) || 0), 0);

    const catMap = {};
    records.forEach(r => {
      const cat = r.waste_category || 'Other Waste';
      if (!catMap[cat]) catMap[cat] = { total: 0, count: 0, locations: {} };
      const w = Number(r.weight_kg) || 0;
      catMap[cat].total += w;
      catMap[cat].count += 1;
      const loc = r.campus_location || 'Campus';
      catMap[cat].locations[loc] = (catMap[cat].locations[loc] || 0) + w;
    });

    const list = Object.entries(catMap).map(([cat, data]) => {
      const tot = Math.round(data.total * 10) / 10;
      const topLoc = Object.entries(data.locations).sort((a, b) => b[1] - a[1])[0]?.[0] || 'Campus';
      const info = RECYCLABILITY_INFO[cat] || { type: "Residual", potential_pct: 50, co2e_factor: 0.5, badge: "General" };
      const share = totalWeight > 0 ? Math.round((tot / totalWeight) * 1000) / 10 : 0;
      const co2 = Math.round(tot * (info.potential_pct / 100.0) * info.co2e_factor * 10) / 10;

      return {
        category: cat,
        total_weight_kg: tot,
        records_count: data.count,
        campus_share_pct: share,
        recyclability_type: info.type,
        diversion_potential_pct: info.potential_pct,
        co2e_saved_kg: co2,
        badge: info.badge,
        color: CATEGORY_COLORS[cat] || "#10B981",
        top_location: topLoc,
        location_breakdown: data.locations
      };
    }).sort((a, b) => b.total_weight_kg - a.total_weight_kg);

    list.categories = list;
    return list;
  }
}

// ----------------------------------------------------------------------
// 12. Reports Summary
// ----------------------------------------------------------------------
export async function fetchReportSummary(periodType = 'monthly', startDate = null, endDate = null) {
  try {
    const params = new URLSearchParams({ period_type: periodType });
    if (startDate) params.append('start_date', startDate);
    if (endDate) params.append('end_date', endDate);

    return await safeFetchJson(`${API_BASE}/reports/summary?${params.toString()}`);
  } catch (err) {
    const records = getLocalRecords();
    const totalWeight = Math.round(records.reduce((acc, r) => acc + (Number(r.weight_kg) || 0), 0) * 10) / 10;

    const locAnalysis = await fetchLocationAnalytics();
    const catRaw = await fetchCategoryAnalytics();
    const catAnalysis = Array.isArray(catRaw) ? catRaw : (catRaw?.categories || []);

    const topLoc = locAnalysis[0] 
      ? { location: locAnalysis[0].location, weight_kg: locAnalysis[0].total_weight_kg, percentage: locAnalysis[0].campus_share_pct }
      : { location: "N/A", weight_kg: 0, percentage: 0 };

    const topCat = catAnalysis[0]
      ? { category: catAnalysis[0].category, weight_kg: catAnalysis[0].total_weight_kg, percentage: catAnalysis[0].campus_share_pct }
      : { category: "N/A", weight_kg: 0, percentage: 0 };

    const periodLabels = {
      daily: `Daily Audit (${new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })})`,
      weekly: `Weekly Audit (Last 7 Days)`,
      monthly: `Monthly Audit (${new Date().toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })})`
    };

    return {
      project_title: "EcoCampus – Campus Waste Generation Analysis",
      organization: "Campus Sustainability Division",
      generated_at: new Date().toISOString().replace('T', ' ').slice(0, 19),
      period_type: periodType,
      reporting_period: periodLabels[periodType] || 'Campus Audit',
      summary: {
        total_waste_kg: totalWeight,
        records_count: records.length,
        locations_count: locAnalysis.length,
        daily_average_kg: records.length > 0 ? Math.round((totalWeight / 30) * 10) / 10 : 0,
        highest_waste_location: topLoc,
        dominant_waste_category: topCat
      },
      location_analysis: locAnalysis.map(l => ({
        location: l.location,
        weight_kg: l.total_weight_kg,
        percentage: l.campus_share_pct,
        records_count: l.records_count,
        avg_per_day: Math.round((l.total_weight_kg / 30) * 10) / 10
      })),
      category_analysis: catAnalysis.map(c => ({
        category: c.category,
        weight_kg: c.total_weight_kg,
        percentage: c.campus_share_pct,
        records_count: c.records_count
      })),
      recommendations: [
        {
          target: topLoc.location !== 'N/A' ? `${topLoc.location} Priority Intervention` : 'Primary Facility Segregation',
          priority: 'High',
          action: `Deploy dedicated sorting bins and source-reduction protocols at ${topLoc.location} which currently contributes ${topLoc.percentage}% of all campus waste.`
        },
        {
          target: 'Organic Bio-Composting',
          priority: 'High',
          action: 'Establish a campus-wide composting station to divert food leftovers directly into landscaping compost.'
        },
        {
          target: 'Weekly Monitoring Cycle',
          priority: 'Medium',
          action: 'Continue periodic weighing schedules across all campus zones to maintain institutional audit integrity.'
        }
      ]
    };
  }
}

// ----------------------------------------------------------------------
// 13. File Upload Preview & Confirmation (Client-side In-Browser Engine)
// ----------------------------------------------------------------------
export async function uploadPreviewFile(file) {
  try {
    const formData = new FormData();
    formData.append('file', file);
    return await safeFetchJson(`${API_BASE}/upload/preview`, {
      method: 'POST',
      body: formData
    });
  } catch (err) {
    // In-browser CSV parse fallback
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const text = e.target.result;
          const lines = text.split(/\r?\n/).filter(line => line.trim().length > 0);
          if (lines.length < 2) {
            throw new Error('The uploaded file contains insufficient rows.');
          }

          const delimiter = lines[0].includes('\t') ? '\t' : (lines[0].includes(';') ? ';' : ',');
          const headers = lines[0].split(delimiter).map(h => h.trim().replace(/^["']|["']$/g, ''));

          const rows = [];
          for (let i = 1; i < lines.length; i++) {
            const cols = lines[i].split(delimiter).map(c => c.trim().replace(/^["']|["']$/g, ''));
            if (cols.length === headers.length) {
              const rowObj = {};
              headers.forEach((h, idx) => {
                rowObj[h] = cols[idx];
              });
              rows.push(rowObj);
            }
          }

          const tempId = `temp_${Date.now()}`;
          // Store in sessionStorage for confirmImport
          sessionStorage.setItem(`${TEMPLATE_CACHE_KEY}_${tempId}`, JSON.stringify(rows));

          // Heuristic column auto-mapping
          const suggestedMapping = {};
          headers.forEach(h => {
            const lower = h.toLowerCase();
            if (lower.includes('date') || lower.includes('time')) suggestedMapping[h] = 'date';
            else if (lower.includes('loc') || lower.includes('build') || lower.includes('zone')) suggestedMapping[h] = 'campus_location';
            else if (lower.includes('cat') || lower.includes('type') || lower.includes('waste')) suggestedMapping[h] = 'waste_category';
            else if (lower.includes('weight') || lower.includes('kg') || lower.includes('mass')) suggestedMapping[h] = 'weight_kg';
            else if (lower.includes('remark') || lower.includes('note') || lower.includes('desc')) suggestedMapping[h] = 'remarks';
          });

          resolve({
            temp_file_id: tempId,
            filename: file.name,
            total_rows: rows.length,
            detected_columns: headers,
            sample_rows: rows.slice(0, 5),
            suggested_mapping: suggestedMapping
          });
        } catch (parseErr) {
          reject(new Error(parseErr.message || 'Failed to parse file.'));
        }
      };
      reader.onerror = () => reject(new Error('Failed to read file.'));
      reader.readAsText(file);
    });
  }
}

export async function confirmImport(tempFileId, columnMapping, skipDuplicates = true) {
  try {
    return await safeFetchJson(`${API_BASE}/upload/confirm`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        temp_file_id: tempFileId,
        column_mapping: columnMapping,
        skip_duplicates: skipDuplicates
      })
    });
  } catch (err) {
    // In-browser import execution
    const cached = sessionStorage.getItem(`${TEMPLATE_CACHE_KEY}_${tempFileId}`);
    if (!cached) throw new Error('Uploaded file cache expired. Please upload the file again.');

    const rows = JSON.parse(cached);
    const dateCol = Object.keys(columnMapping).find(k => columnMapping[k] === 'date');
    const locCol = Object.keys(columnMapping).find(k => columnMapping[k] === 'campus_location');
    const catCol = Object.keys(columnMapping).find(k => columnMapping[k] === 'waste_category');
    const weightCol = Object.keys(columnMapping).find(k => columnMapping[k] === 'weight_kg');
    const remarksCol = Object.keys(columnMapping).find(k => columnMapping[k] === 'remarks');

    if (!locCol || !catCol || !weightCol) {
      throw new Error('Please map Location, Category, and Weight columns.');
    }

    const validBatch = [];
    rows.forEach(r => {
      const rawWeight = Number(String(r[weightCol]).replace(/[^0-9.]/g, ''));
      if (!isNaN(rawWeight) && rawWeight > 0) {
        validBatch.push({
          date: dateCol && r[dateCol] ? String(r[dateCol]).trim() : new Date().toISOString().split('T')[0],
          campus_location: standardizeLocation(r[locCol]),
          waste_category: standardizeCategory(r[catCol]),
          weight_kg: Math.round(rawWeight * 100) / 100,
          remarks: remarksCol && r[remarksCol] ? String(r[remarksCol]).trim() : 'CSV Ingested'
        });
      }
    });

    if (validBatch.length === 0) {
      throw new Error('No valid positive weight rows found with the selected column mapping.');
    }

    const res = await createBatchRecords(validBatch);
    sessionStorage.removeItem(`${TEMPLATE_CACHE_KEY}_${tempFileId}`);
    return {
      success: true,
      records_imported: validBatch.length,
      duplicates_skipped: rows.length - validBatch.length,
      errors_count: 0
    };
  }
}

// ----------------------------------------------------------------------
// 14. Universal In-Browser CSV & Excel Exporters (Offline & Static Safe)
// ----------------------------------------------------------------------
export function downloadCSVFromData(rows, filename = 'ecocampus_export.csv') {
  if (!rows || rows.length === 0) {
    alert('No records available to export.');
    return;
  }
  const headers = Object.keys(rows[0]);
  const csvLines = [
    headers.join(','),
    ...rows.map(row => 
      headers.map(h => {
        const val = row[h] === null || row[h] === undefined ? '' : String(row[h]);
        return `"${val.replace(/"/g, '""')}"`;
      }).join(',')
    )
  ];
  const blob = new Blob([csvLines.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function downloadExcelFromData(rows, filename = 'ecocampus_export.xls') {
  if (!rows || rows.length === 0) {
    alert('No records available to export.');
    return;
  }
  const headers = Object.keys(rows[0]);
  let html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="utf-8"><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Waste Records</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head>
<body><table border="1"><thead><tr>`;
  headers.forEach(h => {
    html += `<th style="background-color:#10B981;color:#ffffff;font-weight:bold;padding:6px 12px;">${h}</th>`;
  });
  html += `</tr></thead><tbody>`;
  rows.forEach(r => {
    html += `<tr>`;
    headers.forEach(h => {
      const val = r[h] === null || r[h] === undefined ? '' : String(r[h]);
      html += `<td style="padding:4px 8px;">${val}</td>`;
    });
    html += `</tr>`;
  });
  html += `</tbody></table></body></html>`;

  const blob = new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function downloadSampleCSVTemplate() {
  const sample = [
    { "Date": "2026-11-20", "Location": "Canteen", "Waste type": "Food", "Weight (kg)": 15.0, "Remarks": "Project brief benchmark sample" },
    { "Date": "2026-11-20", "Location": "Classroom", "Waste type": "Paper", "Weight (kg)": 8.0, "Remarks": "Project brief benchmark sample" },
    { "Date": "2026-11-20", "Location": "Hostel", "Waste type": "Plastic", "Weight (kg)": 12.0, "Remarks": "Project brief benchmark sample" },
    { "Date": "2026-11-20", "Location": "Library", "Waste type": "Paper", "Weight (kg)": 5.0, "Remarks": "Project brief benchmark sample" },
    { "Date": "2026-11-20", "Location": "Playground", "Waste type": "Plastic", "Weight (kg)": 6.0, "Remarks": "Project brief benchmark sample" }
  ];
  downloadCSVFromData(sample, "ecocampus_sample_template.csv");
}

export async function exportCurrentRecordsCSV() {
  try {
    const res = await fetchRecords({ page: 1, pageSize: 10000 });
    if (res && res.records && res.records.length > 0) {
      downloadCSVFromData(res.records, `ecocampus_waste_records_${new Date().toISOString().slice(0, 10)}.csv`);
      return;
    }
  } catch (_) {}
  const local = getLocalRecords();
  if (local.length > 0) {
    downloadCSVFromData(local, `ecocampus_waste_records_${new Date().toISOString().slice(0, 10)}.csv`);
  } else {
    downloadCSVFromData([
      { record_id: "ECO-1001", date: new Date().toISOString().slice(0,10), campus_location: "Canteen", waste_category: "Organic / Food Waste", weight_kg: 15.0, remarks: "Project brief benchmark sample" }
    ], `ecocampus_waste_records.csv`);
  }
}

export async function exportCurrentRecordsExcel() {
  try {
    const res = await fetchRecords({ page: 1, pageSize: 10000 });
    if (res && res.records && res.records.length > 0) {
      downloadExcelFromData(res.records, `ecocampus_waste_records_${new Date().toISOString().slice(0, 10)}.xls`);
      return;
    }
  } catch (_) {}
  const local = getLocalRecords();
  if (local.length > 0) {
    downloadExcelFromData(local, `ecocampus_waste_records_${new Date().toISOString().slice(0, 10)}.xls`);
  } else {
    downloadExcelFromData([
      { record_id: "ECO-1001", date: new Date().toISOString().slice(0,10), campus_location: "Canteen", waste_category: "Organic / Food Waste", weight_kg: 15.0, remarks: "Project brief benchmark sample" }
    ], `ecocampus_waste_records.xls`);
  }
}
