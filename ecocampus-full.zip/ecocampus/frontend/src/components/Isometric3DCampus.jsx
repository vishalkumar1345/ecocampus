import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Utensils, 
  Home, 
  BookOpen, 
  GraduationCap, 
  Trophy, 
  Beaker, 
  Building, 
  Music, 
  Sparkles, 
  Play,
  Pause,
  Compass,
  Layers,
  ArrowRight,
  TrendingUp,
  BarChart3,
  CheckCircle2
} from 'lucide-react';

// The 8 major campus facilities with SIMPLE, DISTINCT, HIGH-CONTRAST COLORS
const CAMPUS_FACILITIES = [
  {
    id: 'canteen',
    name: 'Canteen & Dining',
    shortName: 'Canteen',
    icon: Utensils,
    color: '#10B981', // Emerald Green
    textColor: 'text-emerald-400',
    borderColor: 'border-emerald-500',
    bgBadge: 'bg-emerald-500/20',
    zone: 'Dining & Nutrition Zone',
    actionTip: 'Implement food-waste segregation at tray drop stations and install an on-site organic composter.',
    // Normalized 2D spatial coordinate on terrain plate
    gridX: 18,
    gridY: 20,
  },
  {
    id: 'hostel',
    name: 'Student Hostels',
    shortName: 'Hostel',
    icon: Home,
    color: '#0284C7', // Vivid Sky Blue
    textColor: 'text-sky-400',
    borderColor: 'border-sky-500',
    bgBadge: 'bg-sky-500/20',
    zone: 'Residential Living Quarters',
    actionTip: 'Place dedicated plastic bottle recovery chutes and cardboard recycling bins on residential floors.',
    gridX: 68,
    gridY: 18,
  },
  {
    id: 'classrooms',
    name: 'Academic Block',
    shortName: 'Classrooms',
    icon: GraduationCap,
    color: '#F59E0B', // Sun Amber
    textColor: 'text-amber-400',
    borderColor: 'border-amber-500',
    bgBadge: 'bg-amber-500/20',
    zone: 'Classrooms & Lecture Halls',
    actionTip: 'Promote duplex exam printing and convert course assignment submissions to digital-first LMS.',
    gridX: 42,
    gridY: 34,
  },
  {
    id: 'labs',
    name: 'Science & Research Labs',
    shortName: 'Labs',
    icon: Beaker,
    color: '#9333EA', // Royal Purple
    textColor: 'text-purple-400',
    borderColor: 'border-purple-500',
    bgBadge: 'bg-purple-500/20',
    zone: 'Science Laboratories',
    actionTip: 'Segregate non-hazardous packaging materials and recycle certified glass vials separately.',
    gridX: 16,
    gridY: 62,
  },
  {
    id: 'playground',
    name: 'Athletic Playground',
    shortName: 'Playground',
    icon: Trophy,
    color: '#EA580C', // Bright Orange
    textColor: 'text-orange-400',
    borderColor: 'border-orange-500',
    bgBadge: 'bg-orange-500/20',
    zone: 'Sports & Recreational Ground',
    actionTip: 'Position dual-stream beverage recycling kiosks near spectator bleachers and track gates.',
    gridX: 82,
    gridY: 52,
  },
  {
    id: 'library',
    name: 'University Library',
    shortName: 'Library',
    icon: BookOpen,
    color: '#6366F1', // Royal Indigo
    textColor: 'text-indigo-400',
    borderColor: 'border-indigo-500',
    bgBadge: 'bg-indigo-500/20',
    zone: 'Study & Reference Commons',
    actionTip: 'Partner with local paper mills for periodic shredded document and damaged book reclamation.',
    gridX: 46,
    gridY: 72,
  },
  {
    id: 'admin',
    name: 'Administration Block',
    shortName: 'Admin Block',
    icon: Building,
    color: '#0D9488', // Crisp Teal
    textColor: 'text-teal-400',
    borderColor: 'border-teal-500',
    bgBadge: 'bg-teal-500/20',
    zone: 'Administrative Offices',
    actionTip: 'Mandate digital document workflows and centralized recycling for administrative stationery.',
    gridX: 74,
    gridY: 78,
  },
  {
    id: 'auditorium',
    name: 'Campus Auditorium',
    shortName: 'Auditorium',
    icon: Music,
    color: '#E11D48', // Bold Crimson Rose
    textColor: 'text-rose-400',
    borderColor: 'border-rose-500',
    bgBadge: 'bg-rose-500/20',
    zone: 'Events & Cultural Arena',
    actionTip: 'Enforce single-use beverage bans during annual fests and deploy reusable cup return stations.',
    gridX: 20,
    gridY: 84,
  },
];

export default function Isometric3DCampus({ onSelectLocation, selectedLocation, locationsData = [] }) {
  // 3D Motion Controls
  const [isOrbiting, setIsOrbiting] = useState(false);
  const [rotationAngle, setRotationAngle] = useState(-30); // rotateZ
  const [tiltAngle, setTiltAngle] = useState(48); // rotateX
  const [selectedFacilityId, setSelectedFacilityId] = useState('canteen');
  const [viewPreset, setViewPreset] = useState('isometric'); // 'isometric', 'height', 'topdown'

  // Ref for orbit animation frame
  const orbitReqRef = useRef(null);

  // Auto-Orbit animation loop
  useEffect(() => {
    if (isOrbiting) {
      let angle = rotationAngle;
      const step = () => {
        angle = (angle + 0.35) % 360;
        setRotationAngle(angle);
        orbitReqRef.current = requestAnimationFrame(step);
      };
      orbitReqRef.current = requestAnimationFrame(step);
    } else {
      if (orbitReqRef.current) cancelAnimationFrame(orbitReqRef.current);
    }
    return () => {
      if (orbitReqRef.current) cancelAnimationFrame(orbitReqRef.current);
    };
  }, [isOrbiting]);

  // Handle Preset Switching
  const applyPreset = (preset) => {
    setViewPreset(preset);
    setIsOrbiting(false);
    if (preset === 'isometric') {
      setTiltAngle(48);
      setRotationAngle(-30);
    } else if (preset === 'height') {
      // Steep side elevation for comparing building heights
      setTiltAngle(72);
      setRotationAngle(-45);
    } else if (preset === 'topdown') {
      // Clear aerial layout
      setTiltAngle(20);
      setRotationAngle(0);
    }
  };

  // STRICTLY GIVEN DATA MATCHING (NO FAKE / UNGIVEN NUMBERS):
  const totalGivenKg = locationsData.reduce((acc, curr) => acc + (Number(curr.total_weight_kg) || 0), 0);
  const maxGivenKg = Math.max(...locationsData.map((l) => Number(l.total_weight_kg) || 0), 0);

  const activeFacilities = CAMPUS_FACILITIES.map((facility) => {
    const match = locationsData.find((l) => {
      const loc = (l.location || '').toLowerCase();
      return loc === facility.shortName.toLowerCase() ||
             loc === facility.id.toLowerCase() ||
             loc.includes(facility.shortName.toLowerCase());
    });

    const weightKg = match ? Number(match.total_weight_kg) || 0 : 0;
    const campusShare = totalGivenKg > 0 ? Number(((weightKg / totalGivenKg) * 100).toFixed(1)) : 0;
    const hasData = weightKg > 0;

    // Extrusion height:
    // If has data: scales from 45px to 175px directly proportional to weight!
    // If no data: 22px baseline foundation plinth
    const heightPx = hasData && maxGivenKg > 0
      ? Math.round(45 + (weightKg / maxGivenKg) * 130)
      : 22;

    return {
      ...facility,
      weightKg,
      campusShare,
      hasData,
      heightPx,
      recordsCount: match ? match.records_count || 1 : 0,
      topCategory: match?.top_category || 'General Waste'
    };
  });

  const currentSelectedFacility = activeFacilities.find((f) => f.id === selectedFacilityId) || activeFacilities[0];

  const handleFacilityClick = (facility) => {
    setSelectedFacilityId(facility.id);
    if (onSelectLocation) {
      onSelectLocation(facility.shortName);
    }
  };

  return (
    <div className="relative w-full rounded-3xl bg-gradient-to-b from-[#061715] via-[#041210] to-[#010807] border border-emerald-500/30 p-5 sm:p-7 shadow-glow-ambient space-y-6 select-none overflow-hidden text-white">
      
      {/* 1. TOP HEADER & DIRECT ANALYSIS CONTROLS */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-emerald-500/20 pb-5">
        <div>
          <div className="inline-flex items-center space-x-1.5 px-3 py-0.8 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 shadow-glow mb-1.5">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-spin" style={{ animationDuration: '6s' }} />
            <span>3D Spatial Topography & Waste Analysis</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-display font-black text-white tracking-tight">
            Campus Waste Generation Topography (3D)
          </h2>
          <p className="text-xs text-emerald-200/80 mt-1 max-w-2xl">
            Building extrusion heights scale strictly with verified kilograms recorded. Rotate in 3D or switch presets to analyze campus waste distribution.
          </p>
        </div>

        {/* 3D Motion Presets & Orbit Action */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Analysis View Presets */}
          <div className="flex items-center p-1 rounded-xl bg-forest-950/90 border border-emerald-500/30 text-xs">
            {[
              { id: 'isometric', label: '3D Isometric' },
              { id: 'height', label: 'Height Ranking View' },
              { id: 'topdown', label: 'Aerial Heatmap' },
            ].map((preset) => (
              <button
                key={preset.id}
                onClick={() => applyPreset(preset.id)}
                className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-all ${
                  viewPreset === preset.id
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-glow'
                    : 'text-forest-300 hover:text-white'
                }`}
              >
                {preset.label}
              </button>
            ))}
          </div>

          {/* 3D Auto-Orbit Toggle Button */}
          <button
            onClick={() => setIsOrbiting(!isOrbiting)}
            className={`px-3.5 py-1.5 rounded-xl border text-xs font-bold flex items-center space-x-1.5 transition ${
              isOrbiting
                ? 'bg-emerald-500 border-emerald-400 text-white shadow-glow animate-pulse'
                : 'bg-forest-900/90 border-emerald-500/40 text-emerald-300 hover:bg-forest-800'
            }`}
            title="Auto-rotate topography in 3D"
          >
            {isOrbiting ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            <span>{isOrbiting ? 'Orbiting 3D' : 'Auto-Orbit 3D'}</span>
          </button>
        </div>
      </div>

      {/* 2. FACILITY SELECTOR CHIPS WITH SIMPLE DISTINCT COLORS */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        <span className="text-[11px] font-mono text-emerald-400 uppercase tracking-wider font-bold whitespace-nowrap mr-1">
          Facilities:
        </span>
        {activeFacilities.map((f) => {
          const isSelected = selectedFacilityId === f.id;
          return (
            <button
              key={f.id}
              onClick={() => handleFacilityClick(f)}
              className={`flex items-center space-x-1.5 px-3 py-1 rounded-xl text-xs font-bold whitespace-nowrap transition-all border ${
                isSelected
                  ? 'bg-white text-forest-950 shadow-[0_0_15px_rgba(255,255,255,0.4)] scale-105 border-white'
                  : 'bg-forest-900/80 text-forest-300 border-forest-800 hover:border-emerald-500/40'
              }`}
            >
              <span 
                className="w-2.5 h-2.5 rounded-full" 
                style={{ backgroundColor: f.color }} 
              />
              <span>{f.shortName}</span>
              <span className={`text-[10px] font-mono ${f.hasData ? (isSelected ? 'text-forest-950 font-black' : 'text-emerald-300') : 'opacity-40'}`}>
                {f.hasData ? `${f.weightKg}kg` : '0kg'}
              </span>
            </button>
          );
        })}
      </div>

      {/* 3. DYNAMIC 3D MOVING TOPOGRAPHY VIEWPORT */}
      <div className="relative w-full h-[540px] sm:h-[600px] rounded-3xl bg-[#020B0A] border border-emerald-500/25 flex items-center justify-center overflow-hidden shadow-inner">
        
        {/* Ambient Volumetric Backdrop */}
        <div className="absolute w-[600px] h-[600px] rounded-full bg-emerald-500/10 blur-3xl pointer-events-none" />
        <div className="absolute w-[500px] h-[500px] rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />

        {/* 3D GIMBAL PLATFORM STAGE */}
        <div 
          className="relative select-none"
          style={{ perspective: 1200 }}
        >
          <motion.div
            animate={{
              rotateX: tiltAngle,
              rotateZ: rotationAngle,
            }}
            transition={{
              type: isOrbiting ? 'tween' : 'spring',
              stiffness: 180,
              damping: 24,
              ease: 'linear'
            }}
            className="relative w-[640px] sm:w-[720px] h-[480px] sm:h-[540px] rounded-3xl bg-gradient-to-br from-[#061C18] via-[#041512] to-[#010908] border-2 border-emerald-400/40 shadow-2xl backdrop-blur-xl"
            style={{
              transformStyle: 'preserve-3d',
              boxShadow: '0 40px 100px -15px rgba(0,0,0,0.95), 0 0 50px rgba(0, 245, 155, 0.2)',
            }}
          >
            {/* Terrain Grid Lines (Easy to Understand Campus Quad) */}
            <div 
              className="absolute inset-0 opacity-25 pointer-events-none rounded-3xl"
              style={{
                backgroundImage: 'linear-gradient(to right, #00F59B 1px, transparent 1px), linear-gradient(to bottom, #00E5FF 1px, transparent 1px)',
                backgroundSize: '40px 40px'
              }}
            />

            {/* Campus Avenue Highways (Clear Transit Paths) */}
            <div className="absolute top-1/2 left-0 right-0 h-10 -translate-y-1/2 bg-emerald-500/15 border-y border-dashed border-emerald-400/30 pointer-events-none" />
            <div className="absolute left-1/2 top-0 bottom-0 w-10 -translate-x-1/2 bg-cyan-500/15 border-x border-dashed border-cyan-400/30 pointer-events-none" />

            {/* Central Eco-Square Fountain Quad */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-28 h-28 rounded-full border-2 border-dashed border-emerald-400/40 bg-emerald-500/15 flex items-center justify-center pointer-events-none">
              <div className="w-14 h-14 rounded-full border border-cyan-400/50 flex items-center justify-center bg-cyan-500/20">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              </div>
            </div>

            {/* 3D EXTRACTED BUILDINGS - RENDERED IN TRUE 3D PROPORTION */}
            {activeFacilities.map((facility) => {
              const Icon = facility.icon;
              const isSelected = selectedFacilityId === facility.id;

              return (
                <div
                  key={facility.id}
                  onClick={() => handleFacilityClick(facility)}
                  className="absolute cursor-pointer transition-all duration-300 z-20 group"
                  style={{
                    left: `${facility.gridX}%`,
                    top: `${facility.gridY}%`,
                    transform: 'translate(-50%, -50%)',
                    transformStyle: 'preserve-3d',
                  }}
                >
                  {/* Ground Footprint Aura with SIMPLE DISTINCT COLOR */}
                  <div 
                    className="absolute -inset-3 rounded-2xl pointer-events-none transition-all duration-300"
                    style={{
                      backgroundColor: isSelected 
                        ? `${facility.color}45` 
                        : facility.hasData 
                          ? `${facility.color}15` 
                          : 'transparent',
                      border: isSelected 
                        ? `2.5px solid ${facility.color}` 
                        : facility.hasData 
                          ? `1.5px solid ${facility.color}60` 
                          : '1px dashed rgba(255,255,255,0.15)',
                      boxShadow: isSelected ? `0 0 35px ${facility.color}` : 'none',
                      transform: 'translateZ(-1px)',
                    }}
                  />

                  {/* Vertical Light Pillar when facility is selected */}
                  {isSelected && (
                    <div
                      className="absolute bottom-0 left-1/2 -translate-x-1/2 w-14 pointer-events-none blur-md rounded-full"
                      style={{
                        height: '320px',
                        background: `linear-gradient(to top, ${facility.color}80, transparent)`,
                        transform: 'rotateX(-90deg) translateZ(40px)',
                      }}
                    />
                  )}

                  {/* 3D Extruded Building Block (Proportional to Real Waste Mass) */}
                  <motion.div
                    animate={{
                      z: isSelected ? 35 : 0,
                      scale: isSelected ? 1.08 : 1,
                    }}
                    transition={{ type: 'spring', stiffness: 350, damping: 24 }}
                    className="relative w-20 sm:w-24 rounded-2xl flex flex-col justify-between shadow-2xl"
                    style={{
                      height: `${facility.heightPx}px`,
                      transformStyle: 'preserve-3d',
                      backgroundColor: facility.hasData ? '#061E1A' : '#0B1A17',
                      border: `2px solid ${facility.hasData ? facility.color : '#334155'}`,
                      boxShadow: facility.hasData 
                        ? `0 15px 30px -5px ${facility.color}35, inset 0 0 15px ${facility.color}20` 
                        : '0 5px 15px rgba(0,0,0,0.5)',
                    }}
                  >
                    {/* Roof Top with Vibrant Distinct Color & Icon */}
                    <div 
                      className="w-full h-10 rounded-t-xl flex items-center justify-between px-2 text-white border-b border-white/20"
                      style={{
                        backgroundColor: facility.hasData ? facility.color : '#334155',
                      }}
                    >
                      <div className="w-6 h-6 rounded-lg bg-black/35 flex items-center justify-center">
                        <Icon className="w-3.5 h-3.5 text-white" />
                      </div>
                      <span className="text-[10px] font-black font-mono">
                        {facility.hasData ? `${facility.campusShare}%` : '0%'}
                      </span>
                    </div>

                    {/* Front Facade Metric Label */}
                    <div className="p-1.5 text-center">
                      <div 
                        className="text-[11px] font-mono font-black"
                        style={{ color: facility.hasData ? facility.color : '#94A3B8' }}
                      >
                        {facility.hasData ? `${facility.weightKg} kg` : '0.0 kg'}
                      </div>
                    </div>
                  </motion.div>

                  {/* Clear Upright Billboarded HUD Tag (Counter-Rotated to always face front) */}
                  <div
                    className={`absolute -top-14 left-1/2 -translate-x-1/2 whitespace-nowrap px-3 py-1 rounded-xl text-center shadow-xl transition-all pointer-events-none z-30 ${
                      isSelected
                        ? 'bg-white text-forest-950 font-extrabold ring-4 ring-emerald-400 scale-110 shadow-[0_0_20px_#10B981]'
                        : facility.hasData
                          ? 'bg-forest-900/95 text-white border border-emerald-500/40'
                          : 'bg-forest-950/80 text-forest-400 border border-forest-800'
                    }`}
                    style={{
                      transform: `rotateZ(${-rotationAngle}deg) rotateX(${-tiltAngle}deg) translateZ(45px)`,
                    }}
                  >
                    <div className="text-[11px] font-bold flex items-center justify-center space-x-1">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: facility.color }} />
                      <span>{facility.shortName}</span>
                    </div>
                    <div className="text-[10px] font-mono font-semibold opacity-80">
                      {facility.hasData ? `${facility.weightKg} kg (${facility.campusShare}%)` : 'No records'}
                    </div>
                  </div>

                </div>
              );
            })}

          </motion.div>
        </div>

        {/* 4. OVERLAID FOCUSED FACILITY ANALYSIS CARD (Bottom Right) */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSelectedFacility.id}
            initial={{ opacity: 0, y: 15, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 15, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="absolute bottom-4 right-4 z-40 max-w-sm w-full p-4 rounded-2xl bg-forest-950/95 border border-emerald-500/40 shadow-2xl backdrop-blur-md space-y-3"
          >
            {/* Card Header with Distinct Simple Color */}
            <div className="flex items-center justify-between border-b border-forest-800 pb-2.5">
              <div className="flex items-center space-x-2.5">
                <div 
                  className="w-8 h-8 rounded-xl flex items-center justify-center text-white shadow-sm"
                  style={{ backgroundColor: currentSelectedFacility.color }}
                >
                  {React.createElement(currentSelectedFacility.icon, { className: "w-4 h-4" })}
                </div>
                <div>
                  <h4 className="font-display font-black text-white text-sm">
                    {currentSelectedFacility.name}
                  </h4>
                  <span className="text-[10px] text-forest-300 font-mono">
                    {currentSelectedFacility.zone}
                  </span>
                </div>
              </div>

              {/* Status Badge */}
              <span 
                className="px-2 py-0.5 rounded text-[10px] font-bold font-mono uppercase"
                style={{
                  backgroundColor: currentSelectedFacility.hasData ? `${currentSelectedFacility.color}25` : '#1E293B',
                  color: currentSelectedFacility.hasData ? currentSelectedFacility.color : '#94A3B8',
                  border: `1px solid ${currentSelectedFacility.hasData ? currentSelectedFacility.color : '#475569'}`
                }}
              >
                {currentSelectedFacility.hasData ? 'Active Audited' : '0.0 kg / Idle'}
              </span>
            </div>

            {/* Metric Readout */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-forest-900/80 border border-forest-800">
                <span className="text-[10px] text-forest-400 uppercase font-semibold">Total Given Output</span>
                <div className="text-base font-display font-black text-white mt-0.5">
                  {currentSelectedFacility.weightKg} <span className="text-xs text-emerald-400">kg</span>
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-forest-900/80 border border-forest-800">
                <span className="text-[10px] text-forest-400 uppercase font-semibold">Campus Share</span>
                <div 
                  className="text-base font-display font-black mt-0.5"
                  style={{ color: currentSelectedFacility.color }}
                >
                  {currentSelectedFacility.campusShare}%
                </div>
              </div>
            </div>

            {/* Reduction Tip */}
            <div className="text-[11px] text-forest-200 bg-emerald-950/40 p-2.5 rounded-xl border border-emerald-500/25 leading-relaxed">
              <strong className="text-emerald-400 flex items-center space-x-1 mb-0.5">
                <CheckCircle2 className="w-3 h-3 text-emerald-400 inline" />
                <span>Action Protocol:</span>
              </strong>
              {currentSelectedFacility.actionTip}
            </div>
          </motion.div>
        </AnimatePresence>

        {/* 5. MANUAL 3D ROTATION SLIDER (Bottom Left) */}
        <div className="absolute bottom-4 left-4 z-40 bg-forest-950/90 border border-emerald-500/30 p-2.5 rounded-2xl flex items-center space-x-3 text-xs shadow-xl backdrop-blur-md">
          <div className="flex items-center space-x-1.5 font-mono text-[11px] text-emerald-300">
            <Compass className="w-3.5 h-3.5" />
            <span>3D Angle:</span>
          </div>
          <input
            type="range"
            min="-180"
            max="180"
            value={rotationAngle}
            onChange={(e) => {
              setIsOrbiting(false);
              setRotationAngle(Number(e.target.value));
            }}
            className="w-24 sm:w-32 accent-emerald-400 cursor-pointer h-1.5 bg-forest-800 rounded-lg"
            title="Adjust 3D rotation angle"
          />
          <span className="font-mono text-[10px] text-emerald-400 w-8 text-right">
            {Math.round(rotationAngle)}°
          </span>
        </div>

      </div>

      {/* 6. BOTTOM LEGEND SUMMARY */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-forest-300 pt-1 border-t border-emerald-500/20 font-medium">
        <div className="flex items-center space-x-4">
          <span className="text-emerald-400 font-bold">Total Measured: {totalGivenKg.toFixed(1)} kg</span>
          <span>•</span>
          <span>{activeFacilities.filter(f => f.hasData).length} of 8 facilities logging data</span>
        </div>
        <div className="text-forest-400 text-[11px]">
          Click any facility block or use presets to analyze spatial waste distribution in 3D
        </div>
      </div>

    </div>
  );
}
