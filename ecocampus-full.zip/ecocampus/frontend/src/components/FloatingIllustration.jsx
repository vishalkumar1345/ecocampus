import React, { useRef, useState } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';

export default function FloatingIllustration() {
  const containerRef = useRef(null);
  const [isSpinning, setIsSpinning] = useState(false);

  // Mouse parallax motion values
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const springX = useSpring(mouseX, { stiffness: 180, damping: 24 });
  const springY = useSpring(mouseY, { stiffness: 180, damping: 24 });

  // 3D perspective gimbal tilt responding to mouse
  const stageRotateX = useTransform(springY, [-0.5, 0.5], [16, -14]);
  const stageRotateY = useTransform(springX, [-0.5, 0.5], [-20, 20]);

  const handleMouseMove = (e) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    mouseX.set(x);
    mouseY.set(y);
  };

  const handleMouseLeave = () => {
    mouseX.set(0);
    mouseY.set(0);
  };

  const trigger3sTrick = () => {
    if (isSpinning) return;
    setIsSpinning(true);
    setTimeout(() => {
      setIsSpinning(false);
    }, 3000);
  };

  return (
    <div 
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="relative w-full max-w-[580px] aspect-square mx-auto flex items-center justify-center select-none"
      style={{ perspective: 1300 }}
    >
      {/* Volumetric Ambient Lighting Orbs */}
      <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/25 via-emerald-500/20 to-teal-400/25 rounded-full blur-3xl transform scale-100 pointer-events-none" />
      <div className="absolute w-80 h-80 rounded-full bg-emerald-400/20 blur-2xl top-6 right-6 pointer-events-none" />
      <div className="absolute w-80 h-80 rounded-full bg-cyan-400/20 blur-2xl bottom-6 left-6 pointer-events-none" />

      {/* 3D Tilted Interactive Stage */}
      <motion.div
        style={{
          rotateX: stageRotateX,
          rotateY: stageRotateY,
          transformStyle: 'preserve-3d',
        }}
        className="relative w-[400px] sm:w-[460px] h-[400px] sm:h-[460px] flex items-center justify-center"
      >
        
        {/* 3D Reflective Ground Disc / Platform */}
        <div 
          className="absolute w-[440px] h-[440px] rounded-full border border-cyan-500/30 dark:border-cyan-400/25 bg-gradient-to-b from-cyan-500/10 via-emerald-500/5 to-transparent pointer-events-none"
          style={{
            transform: 'rotateX(75deg) translateZ(-140px)',
            boxShadow: '0 0 80px 20px rgba(0, 245, 155, 0.2)'
          }}
        >
          {/* Concentric Grid Rings */}
          <div className="absolute inset-8 rounded-full border border-dashed border-emerald-500/30 animate-spin" style={{ animationDuration: '36s' }} />
          <div className="absolute inset-16 rounded-full border border-cyan-400/30" />
          <div className="absolute inset-24 rounded-full bg-gradient-to-tr from-emerald-500/25 to-cyan-500/25 blur-md" />
        </div>

        {/* 3D Inclined Primary Orbiting Particle Ring */}
        <motion.div
          animate={{ rotateZ: [0, 360] }}
          transition={{ duration: 24, repeat: Infinity, ease: 'linear' }}
          className="absolute w-[490px] h-[490px] rounded-full border border-dashed border-cyan-400/35 pointer-events-none"
          style={{
            transform: 'rotateX(68deg) rotateY(15deg) translateZ(0px)',
            transformStyle: 'preserve-3d'
          }}
        >
          {/* Glowing Orbital Beacon 1 */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-gradient-to-r from-emerald-400 to-cyan-400 shadow-glow flex items-center justify-center">
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
          </div>
          {/* Glowing Orbital Beacon 2 */}
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-3.5 h-3.5 rounded-full bg-cyan-400 shadow-glow-cyan" />
          {/* Glowing Orbital Beacon 3 */}
          <div className="absolute top-1/2 left-0 -translate-y-1/2 w-3 h-3 rounded-full bg-emerald-300 shadow-glow" />
        </motion.div>

        {/* 3D Counter-Rotating Gyroscope Gimbal Ring */}
        <motion.div
          animate={{ rotateZ: [360, 0] }}
          transition={{ duration: 18, repeat: Infinity, ease: 'linear' }}
          className="absolute w-[510px] h-[510px] rounded-full border border-emerald-400/30 pointer-events-none"
          style={{
            transform: 'rotateX(-52deg) rotateY(-28deg) translateZ(10px)',
            transformStyle: 'preserve-3d'
          }}
        >
          {/* Counter-orbital Beacon A */}
          <div className="absolute top-1/4 right-0 w-3.5 h-3.5 rounded-full bg-emerald-400 shadow-glow flex items-center justify-center">
            <span className="w-1 h-1 rounded-full bg-white" />
          </div>
          {/* Counter-orbital Beacon B */}
          <div className="absolute bottom-1/4 left-0 w-3 h-3 rounded-full bg-cyan-300 shadow-glow-cyan" />
        </motion.div>

        {/* ======================================================== */}
        {/* CENTRAL 3D ECO-CAMPUS MÖBIUS PRISM LOGO (ENLARGED & PROMINENT) */}
        {/* ======================================================== */}
        <motion.div
          onClick={trigger3sTrick}
          animate={
            isSpinning
              ? {
                  y: [-12, 0, -12],
                  rotateY: [0, 360, 720],
                  rotateX: [0, -25, 0],
                  scale: [1, 1.18, 0.96, 1],
                }
              : {
                  y: [-14, 14, -14],
                  rotateZ: [-2, 2, -2],
                  scale: [1, 1.03, 1],
                }
          }
          transition={
            isSpinning
              ? { duration: 3.0, ease: [0.16, 1, 0.3, 1] }
              : {
                  y: { duration: 5, repeat: Infinity, ease: 'easeInOut' },
                  rotateZ: { duration: 7, repeat: Infinity, ease: 'easeInOut' },
                  scale: { duration: 5, repeat: Infinity, ease: 'easeInOut' },
                }
          }
          className="relative flex items-center justify-center cursor-pointer group select-none"
          style={{
            transformStyle: 'preserve-3d',
            transform: 'translateZ(65px)',
          }}
          title="Click to trigger 3s 3D animation"
        >
          {/* Luminous Ambient Ground Aura */}
          <div
            className="absolute inset-0 w-[310px] sm:w-[370px] h-[310px] sm:h-[370px] -bottom-10 rounded-full bg-gradient-to-tr from-emerald-500/25 via-teal-400/20 to-cyan-400/25 blur-3xl pointer-events-none"
            style={{
              transform: 'translateZ(-40px) scale(0.95)',
            }}
          />

          {/* Primary 3D Isometric EcoCampus Logo (Enlarged for High Prominence) */}
          <div className="relative w-[300px] sm:w-[350px] md:w-[380px] h-auto rounded-3xl p-1">
            <motion.img
              src="/ecocampus-logo-3d.png"
              alt="EcoCampus 3D Animated Logo"
              className="w-full h-auto object-contain drop-shadow-[0_28px_50px_rgba(0,245,155,0.42)] filter group-hover:brightness-110 transition-all duration-300"
              style={{
                transform: 'translateZ(30px)',
              }}
              whileHover={{ scale: 1.05 }}
            />

            {/* Specular Holographic Glare Shimmer Beam (Single Pass on Mount/Trigger) */}
            <motion.div
              key={isSpinning ? 'spin-sweep' : 'mount-sweep'}
              initial={{ x: '-140%' }}
              animate={{ x: '240%' }}
              transition={{
                duration: 1.6,
                delay: 0.3,
                repeat: 0, // ONLY ONCE
                ease: [0.16, 1, 0.3, 1]
              }}
              className="absolute inset-0 w-1/2 h-full bg-gradient-to-r from-transparent via-white/45 to-transparent skew-x-[-30deg] pointer-events-none"
              style={{
                mixBlendMode: 'overlay',
                transform: 'translateZ(35px)',
              }}
            />
          </div>

          {/* Luminous Inner Core Ambient Flare */}
          <div 
            className="absolute w-36 h-36 rounded-full bg-gradient-to-tr from-emerald-400/35 to-cyan-400/35 blur-xl pointer-events-none"
            style={{ transform: 'translateZ(-10px)' }}
          />

        </motion.div>

      </motion.div>
    </div>
  );
}
