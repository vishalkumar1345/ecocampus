import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

/**
 * PageLightSweep - A full-page cinematic specular light beam
 * Sweeps from left to right across the entire viewport ONCE upon entrance,
 * illuminating the top navbar (EcoCampus, Home, Dashboard, Records, etc.)
 * and the entire UI layout.
 */
export default function PageLightSweep({ onComplete }) {
  const [isActive, setIsActive] = useState(true);

  useEffect(() => {
    // Single sweep completes in 1.9 seconds, then unmounts
    const timer = setTimeout(() => {
      setIsActive(false);
      if (onComplete) onComplete();
    }, 1950);

    return () => clearTimeout(timer);
  }, [onComplete]);

  if (!isActive) return null;

  return (
    <div className="fixed inset-0 z-50 pointer-events-none overflow-hidden w-screen h-screen">
      {/* Primary Sweeping Luminous Beam (Single Left-to-Right Pass) */}
      <motion.div
        initial={{ x: '-130%' }}
        animate={{ x: '240%' }}
        transition={{
          duration: 1.85,
          ease: [0.16, 1, 0.3, 1], // Smooth cinematic acceleration & deceleration
          repeat: 0, // MOVES ONLY ONCE
        }}
        className="absolute top-0 bottom-0 w-[45vw] min-w-[380px] max-w-[750px] h-[220vh] -top-[60vh] skew-x-[-22deg] pointer-events-none"
        style={{
          background: 'linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(0,245,155,0.12) 20%, rgba(6,182,212,0.3) 40%, rgba(255,255,255,0.75) 50%, rgba(6,182,212,0.3) 60%, rgba(0,245,155,0.12) 80%, rgba(255,255,255,0) 100%)',
          filter: 'drop-shadow(0 0 35px rgba(0, 245, 155, 0.45)) drop-shadow(0 0 65px rgba(6, 182, 212, 0.35))',
          mixBlendMode: 'screen',
        }}
      >
        {/* Intense Specular Center Core Line */}
        <div 
          className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-4 bg-white/95 blur-[2px]"
          style={{
            boxShadow: '0 0 30px 10px rgba(255, 255, 255, 0.9), 0 0 60px 20px rgba(0, 245, 155, 0.7)'
          }}
        />

        {/* Ambient Halo Flaring */}
        <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-48 bg-gradient-to-r from-emerald-400/25 via-cyan-300/40 to-teal-400/25 blur-xl" />
      </motion.div>
    </div>
  );
}
