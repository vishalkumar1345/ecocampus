import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Recycle, 
  LayoutDashboard, 
  TableProperties, 
  UploadCloud, 
  MapPin, 
  PieChart, 
  FileText, 
  Moon, 
  Sun, 
  RotateCcw, 
  Menu, 
  X,
  GraduationCap,
  Sparkles
} from 'lucide-react';

export default function Navbar({ 
  activePage, 
  setActivePage, 
  darkMode, 
  setDarkMode
}) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'landing', label: 'Home', icon: Recycle },
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'records', label: 'Records', icon: TableProperties },
    { id: 'upload', label: 'Upload Data', icon: UploadCloud },
    { id: 'locations', label: 'Locations', icon: MapPin },
    { id: 'categories', label: 'Categories', icon: PieChart },
    { id: 'reports', label: 'Reports', icon: FileText },
  ];

  const handleNav = (id) => {
    setActivePage(id);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-white/80 dark:bg-forest-950/80 backdrop-blur-md border-b border-forest-100/80 dark:border-forest-800/80 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Brand Logo with 3D Crosswap Reference Logo */}
        <div 
          onClick={() => handleNav('landing')} 
          className="flex items-center space-x-3 cursor-pointer group"
        >
          <div className="w-11 h-11 rounded-2xl bg-forest-900/60 dark:bg-forest-900/80 border border-cyan-500/30 flex items-center justify-center p-1.5 shadow-glow group-hover:scale-110 group-hover:shadow-glow-cyan transition-all duration-200">
            <img src="/ecocampus-logo-3d.png" alt="EcoCampus 3D Logo" className="w-9 h-9 object-contain drop-shadow" />
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="font-display font-extrabold text-lg text-forest-800 dark:text-white tracking-tight">
                Eco<span className="text-emerald-500">Campus</span>
              </span>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300/40">
                Analytics
              </span>
            </div>
            <div className="text-[11px] text-ink-muted dark:text-forest-300 font-medium truncate max-w-[170px] sm:max-w-none">
              Waste Generation Intelligence
            </div>
          </div>
        </div>

        {/* Desktop Navigation Links with Smooth Sliding Pill */}
        <nav className="hidden lg:flex items-center space-x-1 p-1 rounded-xl bg-forest-50/60 dark:bg-forest-900/60 border border-forest-100 dark:border-forest-800/60">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`relative flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors duration-200 ${
                  isActive
                    ? 'text-white'
                    : 'text-forest-800 dark:text-forest-200 hover:text-cyan-600 dark:hover:text-cyan-400'
                }`}
              >
                {/* Sliding indicator tab */}
                {isActive && (
                  <motion.div
                    layoutId="activeNavTab"
                    className="absolute inset-0 bg-gradient-to-r from-emerald-600 to-teal-600 rounded-lg shadow-glow"
                    transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  />
                )}
                <span className="relative z-10 flex items-center space-x-1.5">
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-emerald-600 dark:text-cyan-400'}`} />
                  <span>{item.label}</span>
                </span>
              </button>
            );
          })}
        </nav>

        {/* Controls & Quick Actions */}
        <div className="hidden sm:flex items-center space-x-2">
          {/* Quick Upload Action */}
          <button
            onClick={() => handleNav('upload')}
            className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-glow transition hover:scale-105 active:scale-95"
          >
            <UploadCloud className="w-3.5 h-3.5" />
            <span>Upload Data</span>
          </button>

          {/* Dark / Light Mode Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            title={darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
            className="p-2 rounded-xl text-forest-700 dark:text-forest-200 hover:bg-forest-100 dark:hover:bg-forest-900 border border-transparent hover:border-forest-200 dark:hover:border-forest-800 transition"
          >
            {darkMode ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-forest-800" />
            )}
          </button>
        </div>

        {/* Mobile Menu Button */}
        <div className="flex items-center space-x-2 lg:hidden">
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-2 rounded-xl text-forest-700 dark:text-forest-200 hover:bg-forest-100 dark:hover:bg-forest-900"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-forest-800" />}
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-xl text-forest-800 dark:text-forest-100 hover:bg-forest-100 dark:hover:bg-forest-900 focus:outline-none"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-forest-200 dark:border-forest-800 bg-white dark:bg-forest-950 px-4 pt-2 pb-4 space-y-1 shadow-lg">
          <div className="py-2.5 px-3 mb-2 rounded-xl bg-emerald-50 dark:bg-forest-900 flex items-center justify-between text-xs text-forest-800 dark:text-forest-200">
            <div className="flex items-center space-x-2">
              <GraduationCap className="w-4 h-4 text-emerald-600" />
              <span className="font-semibold">EcoCampus Analytics</span>
            </div>
            <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
              Clean Data Engine
            </span>
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-semibold ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-forest-800 dark:text-forest-200 hover:bg-forest-50 dark:hover:bg-forest-900'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-emerald-600 dark:text-emerald-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
}
