import React from 'react';
import { Recycle, Database, Sparkles, BookOpen } from 'lucide-react';

export default function Footer({ setActivePage }) {
  return (
    <footer className="w-full bg-forest-900 text-forest-100 border-t border-forest-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          
          {/* Brand & Objective */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-forest-800 border border-cyan-500/30 flex items-center justify-center p-1 shadow-glow">
                <img src="/ecocampus-logo-3d.png" alt="EcoCampus 3D Logo" className="w-8 h-8 object-contain" />
              </div>
              <span className="font-display font-black text-xl text-white tracking-tight">
                Eco<span className="text-emerald-400">Campus</span>
              </span>
            </div>
            <p className="text-sm text-forest-300 max-w-md leading-relaxed">
              A modern data-driven campus waste intelligence platform. Empowering educational institutions with real-time location analytics, category distribution audits, and empirical sustainability insights.
            </p>
            <div className="pt-2">
              <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-forest-800/80 border border-emerald-500/30 text-xs text-emerald-300">
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                <span className="font-medium">"Measure Waste Today. Create a Greener Tomorrow."</span>
              </div>
            </div>
          </div>

          {/* Quick Navigation */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">Platform Modules</h4>
            <ul className="space-y-2.5 text-sm text-forest-300">
              <li>
                <button onClick={() => setActivePage('dashboard')} className="hover:text-emerald-400 transition">
                  Analytics Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => setActivePage('records')} className="hover:text-emerald-400 transition">
                  Waste Records Registry
                </button>
              </li>
              <li>
                <button onClick={() => setActivePage('upload')} className="hover:text-emerald-400 transition">
                  Dataset CSV/Excel Ingestion
                </button>
              </li>
              <li>
                <button onClick={() => setActivePage('locations')} className="hover:text-emerald-400 transition">
                  Location Comparison Engine
                </button>
              </li>
              <li>
                <button onClick={() => setActivePage('categories')} className="hover:text-emerald-400 transition">
                  Category & Circularity
                </button>
              </li>
              <li>
                <button onClick={() => setActivePage('reports')} className="hover:text-emerald-400 transition">
                  Institutional Reports & PDF
                </button>
              </li>
            </ul>
          </div>

          {/* Platform Institutional Details */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">Platform Overview</h4>
            <div className="p-4 rounded-xl bg-forest-800/60 border border-forest-700/60 space-y-2 text-xs text-forest-200">
              <div className="flex items-center space-x-2 text-emerald-400 font-bold">
                <BookOpen className="w-4 h-4" />
                <span>Sustainability Intelligence</span>
              </div>
              <div className="text-sm font-semibold text-white">Campus Waste Analytics</div>
              <div className="text-forest-400">Location, Category & Weight Metrics</div>
              <div className="pt-2 text-[11px] text-forest-400 border-t border-forest-700/50">
                Academic Year 2026–2027
              </div>
            </div>
          </div>
        </div>

        {/* Tech Stack Pills & Bottom Bar */}
        <div className="pt-8 border-t border-forest-800 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-forest-400">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2 py-1 rounded bg-forest-800 text-forest-300 font-mono">React 18</span>
            <span className="px-2 py-1 rounded bg-forest-800 text-forest-300 font-mono">Tailwind CSS</span>
            <span className="px-2 py-1 rounded bg-forest-800 text-forest-300 font-mono">Framer Motion</span>
            <span className="px-2 py-1 rounded bg-forest-800 text-forest-300 font-mono">Recharts</span>
            <span className="px-2 py-1 rounded bg-forest-800 text-emerald-400 font-mono">FastAPI</span>
            <span className="px-2 py-1 rounded bg-forest-800 text-emerald-400 font-mono">Pandas</span>
            <span className="px-2 py-1 rounded bg-forest-800 text-forest-300 font-mono">SQLite</span>
          </div>

          <div className="flex items-center space-x-1 text-center sm:text-right">
            <span>EcoCampus Sustainability Systems • Academic Year 2026–2027</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
