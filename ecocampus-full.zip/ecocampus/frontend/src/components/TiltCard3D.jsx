import React, { useRef, useState } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';

/**
 * TiltCard3D
 * Provides high-performance 3D perspective tilt with mouse tracking,
 * spring dampening, and specular holographic light glare.
 */
export default function TiltCard3D({ 
  children, 
  className = '', 
  tiltDegree = 10,
  glare = true,
  scale = 1.02,
  ...props 
}) {
  const cardRef = useRef(null);
  const [isHovered, setIsHovered] = useState(false);

  // Raw mouse coordinates normalized from -0.5 to 0.5
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  // Smooth spring physics for fluid 3D tilt
  const mouseX = useSpring(x, { stiffness: 240, damping: 22 });
  const mouseY = useSpring(y, { stiffness: 240, damping: 22 });

  // 3D rotations based on normalized mouse
  const rotateX = useTransform(mouseY, [-0.5, 0.5], [tiltDegree, -tiltDegree]);
  const rotateY = useTransform(mouseX, [-0.5, 0.5], [-tiltDegree, tiltDegree]);

  const handleMouseMove = (e) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const mouseXPos = e.clientX - rect.left;
    const mouseYPos = e.clientY - rect.top;

    x.set(mouseXPos / rect.width - 0.5);
    y.set(mouseYPos / rect.height - 0.5);
  };

  const handleMouseEnter = () => setIsHovered(true);

  const handleMouseLeave = () => {
    setIsHovered(false);
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      style={{
        rotateX,
        rotateY,
        transformStyle: 'preserve-3d',
        perspective: 1000
      }}
      whileHover={{ scale }}
      transition={{ duration: 0.2 }}
      className={`relative ${className}`}
      {...props}
    >
      {/* 3D Holographic Specular Glare Reflection */}
      {glare && (
        <div 
          className="absolute inset-0 pointer-events-none rounded-[inherit] overflow-hidden z-20 transition-opacity duration-300"
          style={{ opacity: isHovered ? 0.35 : 0 }}
        >
          <div 
            className="w-full h-full"
            style={{
              background: 'radial-gradient(circle 260px at center, rgba(0, 245, 155, 0.45), rgba(0, 229, 255, 0.15) 50%, transparent 80%)'
            }}
          />
        </div>
      )}

      {/* Card Content with 3D Depth */}
      <div className="w-full h-full" style={{ transform: 'translateZ(15px)', transformStyle: 'preserve-3d' }}>
        {children}
      </div>
    </motion.div>
  );
}
