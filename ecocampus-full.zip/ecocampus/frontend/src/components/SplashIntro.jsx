import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, ArrowRight } from 'lucide-react';

export default function SplashIntro({ onComplete }) {
  const [phase, setPhase] = useState('entering'); // 'entering' -> 'floating' -> 'exiting'

  useEffect(() => {
    // Stage 1: Floating & Shimmering at 1.8s
    const floatTimer = setTimeout(() => {
      setPhase('floating');
    }, 1200);

    // Stage 2: Grand Aperture Exit at 2.6s
    const exitTimer = setTimeout(() => {
      setPhase('exiting');
    }, 2600);

    // Stage 3: Complete Website Entrance at exactly 3.0s
    const completeTimer = setTimeout(() => {
      onComplete();
    }, 3000);

    return () => {
      clearTimeout(floatTimer);
      clearTimeout(exitTimer);
      clearTimeout(completeTimer);
    };
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={phase === 'exiting' ? { opacity: 0, scale: 1.15, filter: 'blur(16px)' } : { opacity: 1 }}
      exit={{ opacity: 0, scale: 1.2, filter: 'blur(20px)' }}
      transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
      onClick={onComplete}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#020B0A] text-white select-none overflow-hidden cursor-pointer"
      style={{ perspective: 1400 }}
    >
      {/* 1. FULL-PAGE DYNAMIC AURORA & QUANTUM BACKGROUND */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#020D0B] via-[#041613] to-[#010807]" />

      {/* Full-Page Radial Energy Gradients */}
      <motion.div
        animate={{
          scale: [0.9, 1.35, 1.1],
          opacity: [0.25, 0.65, 0.35],
        }}
        transition={{ duration: 3, ease: 'easeInOut' }}
        className="absolute w-[800px] sm:w-[1100px] h-[800px] sm:h-[1100px] rounded-full bg-gradient-to-tr from-emerald-500/25 via-teal-400/20 to-cyan-400/30 blur-3xl pointer-events-none"
      />

      <div className="absolute -top-32 -left-32 w-[550px] h-[550px] rounded-full bg-emerald-500/15 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-[550px] h-[550px] rounded-full bg-cyan-400/20 blur-3xl pointer-events-none" />

      {/* Fullscreen Isometric Matrix Grid */}
      <div 
        className="absolute inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: 'linear-gradient(to right, #00E5FF 1px, transparent 1px), linear-gradient(to bottom, #00E599 1px, transparent 1px)',
          backgroundSize: '48px 48px',
          maskImage: 'radial-gradient(ellipse 70% 70% at 50% 50%, #000 30%, transparent 100%)',
          WebkitMaskImage: 'radial-gradient(ellipse 70% 70% at 50% 50%, #000 30%, transparent 100%)',
        }}
      />

      {/* 2. FULLSCREEN EXPANDING SHOCKWAVE PULSE RINGS */}
      {/* Full-Page Specular Light Beam (Moves Left to Right ONLY ONCE) */}
      <motion.div
        initial={{ x: '-140%' }}
        animate={{ x: '240%' }}
        transition={{
          duration: 1.8,
          delay: 0.5,
          ease: [0.16, 1, 0.3, 1],
          repeat: 0, // ONLY ONCE
        }}
        className="absolute inset-y-0 w-[45vw] min-w-[360px] h-[200vh] -top-[50vh] skew-x-[-22deg] pointer-events-none z-30"
        style={{
          background: 'linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(0,245,155,0.15) 25%, rgba(255,255,255,0.7) 50%, rgba(6,182,212,0.3) 75%, rgba(255,255,255,0) 100%)',
          filter: 'drop-shadow(0 0 35px rgba(0, 245, 155, 0.5))',
          mixBlendMode: 'screen',
        }}
      />

      {/* Ring 1 - Outer Wave */}
      <motion.div
        initial={{ scale: 0.1, opacity: 0.9 }}
        animate={{ scale: [0.2, 1.6, 2.2], opacity: [0.8, 0.4, 0] }}
        transition={{ duration: 2.8, ease: 'easeOut' }}
        className="absolute w-[450px] h-[450px] rounded-full border-2 border-emerald-400/60 pointer-events-none"
      />

      {/* Ring 2 - Electric Cyan Counter Gyro Ring */}
      <motion.div
        initial={{ scale: 0.4, rotateX: 65, rotateZ: 0 }}
        animate={{
          scale: [0.4, 1.15, 1.05],
          rotateZ: [0, 180, 360],
          rotateX: [65, 45, 60]
        }}
        transition={{ duration: 3, ease: 'easeInOut' }}
        className="absolute w-[520px] sm:w-[620px] h-[520px] sm:h-[620px] rounded-full border border-dashed border-cyan-400/40 pointer-events-none shadow-[0_0_40px_rgba(6,182,212,0.25)]"
        style={{ transformStyle: 'preserve-3d' }}
      >
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-cyan-400 shadow-[0_0_20px_#22d3ee]" />
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-3.5 h-3.5 rounded-full bg-emerald-400 shadow-[0_0_15px_#34d399]" />
        <div className="absolute top-1/2 right-0 -translate-y-1/2 w-3 h-3 rounded-full bg-teal-300 shadow-[0_0_12px_#5eead4]" />
      </motion.div>

      {/* Ring 3 - Horizontal Orbital Plane Ring */}
      <motion.div
        initial={{ scale: 0.6, opacity: 0, rotateX: 75 }}
        animate={{ scale: [0.6, 1.3, 1.4], opacity: [0, 0.7, 0.3], rotateX: 75 }}
        transition={{ duration: 2.8, ease: 'easeOut' }}
        className="absolute w-[680px] sm:w-[780px] h-[680px] sm:h-[780px] rounded-full border border-emerald-400/30 pointer-events-none"
      />

      {/* 3. GRAND 3D MULTI-AXIS LOGO TUMBLE & ENTRANCE ANIMATION */}
      <div className="relative z-20 flex flex-col items-center justify-center">
        
        {/* The 3D Rotating & Scaling Logo Mass */}
        <motion.div
          initial={{
            scale: 0.15,
            opacity: 0,
            rotateX: 75,
            rotateY: -140,
            rotateZ: -50,
            z: -400,
          }}
          animate={
            phase === 'entering'
              ? {
                  scale: [0.15, 1.3, 1],
                  opacity: [0, 1, 1],
                  rotateX: [75, -18, 0],
                  rotateY: [-140, 25, 0],
                  rotateZ: [-50, 10, 0],
                  z: [-400, 80, 0],
                }
              : phase === 'floating'
              ? {
                  scale: [1, 1.08, 1],
                  opacity: 1,
                  rotateX: [0, -6, 4, 0],
                  rotateY: [0, 12, -8, 0],
                  rotateZ: [0, 3, -3, 0],
                  z: [0, 40, 0],
                }
              : {
                  scale: [1, 1.4],
                  opacity: [1, 0],
                  rotateZ: [0, 15],
                  z: [0, 200],
                }
          }
          transition={
            phase === 'entering'
              ? { duration: 1.2, ease: [0.16, 1, 0.3, 1] }
              : phase === 'floating'
              ? { duration: 1.4, repeat: Infinity, ease: 'easeInOut' }
              : { duration: 0.4, ease: 'easeIn' }
          }
          className="relative flex items-center justify-center"
          style={{ transformStyle: 'preserve-3d' }}
        >
          {/* Intense Back-Glow Behind Logo */}
          <div className="absolute inset-0 w-[300px] sm:w-[380px] h-[300px] sm:h-[380px] rounded-full bg-gradient-to-tr from-emerald-400/40 via-teal-400/30 to-cyan-400/40 blur-2xl pointer-events-none" />

          {/* Anamorphic Lens Flare Beam Slicing Horizontally */}
          <motion.div
            initial={{ scaleX: 0, opacity: 0 }}
            animate={{ scaleX: [0, 1.8, 1.2], opacity: [0, 0.9, 0.4] }}
            transition={{ duration: 1.4, delay: 0.3, ease: 'easeOut' }}
            className="absolute -inset-x-48 h-1 bg-gradient-to-r from-transparent via-cyan-200 to-transparent pointer-events-none shadow-[0_0_25px_#22d3ee]"
          />

          {/* Primary High-Resolution 3D Logo Image */}
          <div className="relative w-64 sm:w-80 md:w-96 h-auto">
            <motion.img
              src="/ecocampus-logo-3d.png"
              alt="EcoCampus 3D Logo"
              className="w-full h-auto object-contain drop-shadow-[0_25px_60px_rgba(0,245,155,0.55)] filter brightness-105"
            />

            {/* Specular Diagonal Light Sweep Beam across 3D Facets (Single Pass) */}
            <motion.div
              initial={{ x: '-140%' }}
              animate={{ x: '240%' }}
              transition={{ duration: 1.6, delay: 0.5, repeat: 0, ease: [0.16, 1, 0.3, 1] }}
              className="absolute inset-0 w-1/2 h-full bg-gradient-to-r from-transparent via-white/50 to-transparent skew-x-[-30deg] pointer-events-none"
              style={{ mixBlendMode: 'overlay' }}
            />
          </div>
        </motion.div>

        {/* 4. CINEMATIC TYPOGRAPHY & BRAND SWEEP */}
        <motion.div
          initial={{ opacity: 0, y: 35, letterSpacing: '0.15em' }}
          animate={{
            opacity: [0, 1, 1],
            y: [35, 0, 0],
            letterSpacing: ['0.15em', '0.35em', '0.28em']
          }}
          transition={{ duration: 1.4, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="text-center mt-8 z-30 px-4"
        >
          {/* Top Badge */}
          <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full text-xs font-bold tracking-widest uppercase bg-emerald-950/90 text-emerald-300 border border-emerald-400/40 mb-3 shadow-[0_0_30px_rgba(0,245,155,0.3)]">
            <Sparkles className="w-4 h-4 text-emerald-400 animate-spin" style={{ animationDuration: '4s' }} />
            <span>Campus Sustainability Intelligence</span>
          </div>

          {/* Majestic Grand Title */}
          <h1 className="text-4xl sm:text-6xl md:text-7xl font-display font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-emerald-200 to-cyan-300 drop-shadow-[0_10px_25px_rgba(0,245,155,0.35)]">
            ECOCAMPUS
          </h1>

          <p className="text-xs sm:text-base font-mono uppercase tracking-[0.25em] text-cyan-200/90 mt-2 font-semibold">
            Campus Waste Generation Analysis
          </p>
        </motion.div>

        {/* 5. 3-SECOND SUBTLE TIME TRACK & CLICK TO ENTER */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.4 }}
          className="mt-8 z-30 flex flex-col items-center space-y-2.5"
        >
          {/* Minimalist 3s Progress Line */}
          <div className="w-56 h-1 rounded-full bg-emerald-950/90 border border-emerald-800/60 overflow-hidden p-0.5">
            <motion.div
              initial={{ width: '0%' }}
              animate={{ width: '100%' }}
              transition={{ duration: 2.8, ease: 'linear' }}
              className="h-full rounded-full bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 shadow-[0_0_15px_#00e599]"
            />
          </div>

          <div className="text-[11px] font-mono text-emerald-300/60 tracking-wider">
            Click anywhere to enter • Auto-launching (3s)
          </div>
        </motion.div>

      </div>
    </motion.div>
  );
}
