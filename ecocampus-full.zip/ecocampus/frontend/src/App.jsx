import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Toast from './components/Toast';
import SplashIntro from './components/SplashIntro';
import PageLightSweep from './components/PageLightSweep';

import LandingPage from './pages/LandingPage';
import DashboardPage from './pages/DashboardPage';
import RecordsPage from './pages/RecordsPage';
import UploadPage from './pages/UploadPage';
import LocationAnalysisPage from './pages/LocationAnalysisPage';
import CategoryAnalysisPage from './pages/CategoryAnalysisPage';
import ReportsPage from './pages/ReportsPage';

import { ArrowUp } from 'lucide-react';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [showLightSweep, setShowLightSweep] = useState(false);
  const [activePage, setActivePage] = useState('landing');
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem('ecocampus_theme') === 'dark';
  });
  const [toast, setToast] = useState(null);
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Sync theme
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('ecocampus_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('ecocampus_theme', 'light');
    }
  }, [darkMode]);

  // Track scroll position for Scroll-to-Top button
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const showToast = ({ type = 'info', message }) => {
    setToast({ type, message });
    setTimeout(() => {
      setToast((prev) => (prev?.message === message ? null : prev));
    }, 4000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F4FAF7] dark:bg-forest-900 text-forest-950 dark:text-forest-100 selection:bg-emerald-500 selection:text-white transition-colors duration-200">
      
      {/* Initial Opening Splash Animation */}
      <AnimatePresence>
        {showSplash && (
          <SplashIntro 
            onComplete={() => {
              setShowSplash(false);
              setShowLightSweep(true);
            }} 
          />
        )}
      </AnimatePresence>

      {/* Full-Page Specular Light Sweep (Passes Left-to-Right ONCE across entire UI, Navbar & Page) */}
      <AnimatePresence>
        {showLightSweep && (
          <PageLightSweep onComplete={() => setShowLightSweep(false)} />
        )}
      </AnimatePresence>

      {/* Toast Notification */}
      <Toast toast={toast} onClose={() => setToast(null)} />

      {/* Navigation */}
      <Navbar
        activePage={activePage}
        setActivePage={setActivePage}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      {/* Main Content Area with 3D Depth Dissolve Page Transitions */}
      <main className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={activePage}
            initial={{ opacity: 0, y: 18, scale: 0.985, filter: 'blur(3px)' }}
            animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
            exit={{ opacity: 0, y: -18, scale: 0.985, filter: 'blur(3px)' }}
            transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
          >
            {activePage === 'landing' && <LandingPage setActivePage={setActivePage} />}
            {activePage === 'dashboard' && <DashboardPage setActivePage={setActivePage} />}
            {activePage === 'records' && <RecordsPage showToast={showToast} />}
            {activePage === 'upload' && <UploadPage showToast={showToast} setActivePage={setActivePage} />}
            {activePage === 'locations' && <LocationAnalysisPage setActivePage={setActivePage} />}
            {activePage === 'categories' && <CategoryAnalysisPage setActivePage={setActivePage} />}
            {activePage === 'reports' && <ReportsPage showToast={showToast} />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <Footer setActivePage={setActivePage} />

      {/* Floating Scroll to Top Pill */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            onClick={scrollToTop}
            title="Scroll to top"
            className="fixed bottom-6 right-6 z-40 p-3 rounded-2xl bg-emerald-600 text-white shadow-glow hover:bg-emerald-500 hover:scale-110 active:scale-95 transition-all duration-200"
          >
            <ArrowUp className="w-4 h-4 stroke-[2.5]" />
          </motion.button>
        )}
      </AnimatePresence>

    </div>
  );
}
