import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  PieChart as PieIcon, 
  Recycle, 
  Leaf, 
  Layers, 
  ShieldCheck, 
  ArrowRight, 
  Sparkles, 
  RefreshCw,
  Award,
  Globe2
} from 'lucide-react';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, 
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar 
} from 'recharts';
import { fetchCategoryAnalytics } from '../utils/api';
import AnimatedCounter from '../components/AnimatedCounter';
import TiltCard3D from '../components/TiltCard3D';

const COLORS = ['#00D084', '#06B6D4', '#F59E0B', '#8B5CF6', '#3B82F6', '#64748B'];

export default function CategoryAnalysisPage({ setActivePage }) {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    try {
      setLoading(true);
      const res = await fetchCategoryAnalytics();
      const list = Array.isArray(res) ? res : (Array.isArray(res?.categories) ? res.categories : []);
      setCategories(list);
    } catch (err) {
      console.error('Failed to load category data:', err);
      setCategories([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const safeCategories = Array.isArray(categories) ? categories : [];
  const totalKg = safeCategories.reduce((sum, c) => sum + (Number(c.total_weight_kg) || 0), 0);
  const totalCo2Saved = safeCategories.reduce((sum, c) => sum + (Number(c.co2e_saved_kg) || 0), 0);

  const diversionKg = safeCategories
    .filter(c => (c.recyclability_type === 'Recyclable' || c.recyclability_type === 'Compostable'))
    .reduce((sum, c) => sum + (Number(c.total_weight_kg) || 0), 0);
  const diversionShare = totalKg > 0 ? Math.round((diversionKg / totalKg) * 1000) / 10 : 0;

  // Data for radar comparison
  const radarData = safeCategories.map((c) => ({
    category: (c.category ? String(c.category).split('/')[0] : 'General').trim(),
    weight: Number(c.total_weight_kg) || 0,
    diversion: Number(c.diversion_potential_pct) || 0
  }));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fadeIn">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 mb-1.5 border border-emerald-300/40">
            <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
            <span>Material Streams & Circularity</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-display font-extrabold text-forest-900 dark:text-white">
            Campus Waste Category Analysis
          </h1>
          <p className="text-xs sm:text-sm text-forest-600 dark:text-forest-300 mt-1">
            Material composition analysis, diversion metrics, and carbon emissions avoidance modeling.
          </p>
        </div>

        <button
          onClick={loadData}
          className="p-2 rounded-xl bg-white dark:bg-forest-900 border border-forest-200 dark:border-forest-700 text-forest-700 dark:text-forest-200 hover:bg-forest-50 self-start shadow-sm"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-emerald-500' : ''}`} />
        </button>
      </div>

      {/* TOP AGGREGATE SUMMARY CARDS WITH 3D TILT */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <TiltCard3D tiltDegree={12} className="h-full">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="card-lighting p-5 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm relative overflow-hidden h-full flex flex-col justify-between"
          >
            <div className="text-xs font-semibold uppercase tracking-wider text-forest-500 dark:text-forest-400">
              Total Material Ingested
            </div>
            <div 
              className="text-3xl font-display font-black text-forest-900 dark:text-white mt-2"
              style={{ transform: 'translateZ(24px)' }}
            >
              <AnimatedCounter value={totalKg} decimals={1} suffix=" kg" />
            </div>
            <div className="text-xs text-emerald-600 dark:text-emerald-400 mt-1">
              Across 6 distinct waste fractions
            </div>
          </motion.div>
        </TiltCard3D>

        <TiltCard3D tiltDegree={12} className="h-full">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.06 }}
            className="card-lighting p-5 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm relative overflow-hidden h-full flex flex-col justify-between"
          >
            <div className="text-xs font-semibold uppercase tracking-wider text-forest-500 dark:text-forest-400">
              Estimated GHG Avoidance
            </div>
            <div 
              className="text-3xl font-display font-black text-emerald-600 dark:text-emerald-400 mt-2"
              style={{ transform: 'translateZ(24px)' }}
            >
              <AnimatedCounter value={totalCo2Saved} decimals={1} suffix=" kg CO2e" />
            </div>
            <div className="text-xs text-forest-500 dark:text-forest-400 mt-1">
              Calculated via circular diversion factors
            </div>
          </motion.div>
        </TiltCard3D>

        <TiltCard3D tiltDegree={12} className="h-full">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.12 }}
            className="card-lighting p-5 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm relative overflow-hidden h-full flex flex-col justify-between"
          >
            <div className="text-xs font-semibold uppercase tracking-wider text-forest-500 dark:text-forest-400">
              Compostable & Recyclable Share
            </div>
            <div 
              className="text-3xl font-display font-black text-cyan-600 dark:text-cyan-400 mt-2"
              style={{ transform: 'translateZ(24px)' }}
            >
              {diversionShare > 0 ? `${diversionShare}%` : '0%'}
            </div>
            <div className="text-xs text-forest-500 dark:text-forest-400 mt-1">
              High diversion viability
            </div>
          </motion.div>
        </TiltCard3D>
      </div>

      {/* CHARTS ROW: Interactive Donut & Radar Chart with Bidirectional Scroll */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Donut Chart */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.15 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="card-lighting lg:col-span-7 p-6 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-glow-ambient space-y-4"
        >
          <div>
            <h3 className="font-display font-bold text-base text-forest-900 dark:text-white">
              Waste Stream Weight Breakdown
            </h3>
            <p className="text-xs text-forest-500 dark:text-forest-400">
              Proportionate weight and percentage share across all categories
            </p>
          </div>

          <div className="h-72 w-full flex items-center justify-center">
            {safeCategories.length === 0 ? (
              <div className="flex flex-col items-center justify-center text-center space-y-2 text-forest-400">
                <PieIcon className="w-10 h-10 opacity-30" />
                <p className="text-xs">No category data recorded yet</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={safeCategories}
                    dataKey="total_weight_kg"
                    nameKey="category"
                    cx="50%"
                    cy="50%"
                    innerRadius={65}
                    outerRadius={95}
                    paddingAngle={3}
                  >
                    {safeCategories.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#123D32', 
                      borderColor: '#16A36A', 
                      borderRadius: '10px', 
                      color: '#fff',
                      fontSize: '12px'
                    }}
                    formatter={(val, name, item) => [`${val} kg (${item?.payload?.campus_share_pct || 0}%)`, name]}
                  />
                  <Legend 
                    layout="horizontal" 
                    verticalAlign="bottom" 
                    align="center"
                    iconType="circle"
                    wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </motion.div>

        {/* Circular Diversion Radar */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.15 }}
          transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="card-lighting lg:col-span-5 p-6 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-glow-ambient space-y-4"
        >
          <div>
            <h3 className="font-display font-bold text-base text-forest-900 dark:text-white">
              Diversion Viability Index
            </h3>
            <p className="text-xs text-forest-500 dark:text-forest-400">
              Circularity percentage potential per material stream
            </p>
          </div>

          <div className="h-72 w-full">
            {radarData.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-2 text-forest-400">
                <Layers className="w-10 h-10 opacity-30" />
                <p className="text-xs">No circularity metrics available yet</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart outerRadius={80} data={radarData}>
                  <PolarGrid opacity={0.2} />
                  <PolarAngleAxis dataKey="category" tick={{ fontSize: 11, fill: '#6B7280' }} />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 10, fill: '#6B7280' }} />
                  <Radar name="Diversion Potential %" dataKey="diversion" stroke="#16A36A" fill="#16A36A" fillOpacity={0.45} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#123D32', 
                      borderColor: '#16A36A', 
                      borderRadius: '10px', 
                      color: '#fff',
                      fontSize: '12px'
                    }}
                    formatter={(val) => [`${val}%`, 'Diversion Potential']}
                  />
                </RadarChart>
              </ResponsiveContainer>
            )}
          </div>
        </motion.div>

      </div>

      {/* CATEGORY DETAILS GRID */}
      <div className="space-y-4">
        <h2 className="text-lg font-display font-bold text-forest-900 dark:text-white flex items-center space-x-2">
          <Layers className="w-5 h-5 text-emerald-600" />
          <span>Category Technical Profiles</span>
        </h2>

        {safeCategories.length === 0 ? (
          <div className="p-8 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 text-center space-y-3">
            <Layers className="w-8 h-8 text-forest-400 mx-auto" />
            <h3 className="font-bold text-forest-900 dark:text-white">No Category Records Ingested</h3>
            <p className="text-xs text-forest-500 max-w-md mx-auto">
              Material stream breakdowns (Plastic, Organic, Paper, Glass, Metals) will display here once waste data is added.
            </p>
            <button
              onClick={() => setActivePage('upload')}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-glow inline-flex items-center space-x-1.5"
            >
              <span>Ingest Campus Data</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {safeCategories.map((cat, idx) => (
            <TiltCard3D key={cat.category || idx} tiltDegree={10} className="h-full">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: false, amount: 0.15 }}
                transition={{ duration: 0.5, delay: idx * 0.05 }}
                className="card-lighting p-5 rounded-2xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm space-y-4 hover:shadow-glow transition-all duration-300 h-full flex flex-col justify-between"
              >
                <div>
                  {/* Badge & Title */}
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-forest-100 dark:bg-forest-800 text-forest-800 dark:text-forest-200">
                      {cat.recyclability_type || 'General Stream'}
                    </span>
                    <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 font-mono">
                      {cat.campus_share_pct || 0}% Share
                    </span>
                  </div>

                  <div className="mt-2">
                    <h3 
                      className="text-base font-display font-extrabold text-forest-900 dark:text-white"
                      style={{ transform: 'translateZ(18px)' }}
                    >
                      {cat.category || 'General'}
                    </h3>
                    <div 
                      className="text-2xl font-black text-forest-900 dark:text-white mt-1"
                      style={{ transform: 'translateZ(22px)' }}
                    >
                      <AnimatedCounter value={Number(cat.total_weight_kg) || 0} decimals={1} suffix=" kg" />
                    </div>
                  </div>
                </div>

                <div className="space-y-3 pt-2">
                  {/* Carbon Offset & Top Location */}
                  <div className="p-3 rounded-xl bg-forest-50/70 dark:bg-forest-800/50 border border-forest-100 dark:border-forest-700/60 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-forest-500 dark:text-forest-400">GHG Avoidance:</span>
                      <strong className="text-emerald-600 dark:text-emerald-400">
                        ~{cat.co2e_saved_kg || 0} kg CO2e
                      </strong>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-forest-500 dark:text-forest-400">Peak Campus Origin:</span>
                      <strong className="text-forest-800 dark:text-forest-200 truncate max-w-[130px]">
                        {cat.top_location || 'Campus Wide'}
                      </strong>
                    </div>
                  </div>

                  {/* Action pill */}
                  <div className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 px-3 py-1.5 rounded-lg border border-emerald-200/60 dark:border-emerald-800/60 flex items-center space-x-1.5">
                    <Leaf className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                    <span>{cat.badge || 'Monitored Material'}</span>
                  </div>
                </div>
              </motion.div>
            </TiltCard3D>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
