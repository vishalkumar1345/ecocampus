import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  ArrowUpDown, 
  Edit3, 
  Trash2, 
  FileSpreadsheet, 
  Download, 
  RotateCcw, 
  ChevronLeft, 
  ChevronRight, 
  AlertTriangle,
  Sparkles,
  Tag
} from 'lucide-react';
import Modal from '../components/Modal';
import { 
  fetchRecords, 
  createRecord, 
  updateRecord, 
  deleteRecord, 
  loadBenchmarkSample,
  exportCurrentRecordsCSV,
  exportCurrentRecordsExcel 
} from '../utils/api';

const LOCATIONS = [
  "Canteen",
  "Hostel",
  "Classrooms",
  "Library",
  "Playground",
  "Labs",
  "Admin Block",
  "Auditorium"
];

const CATEGORIES = [
  "Organic / Food Waste",
  "Plastic Waste",
  "Paper Waste",
  "Metal Waste",
  "Glass Waste",
  "Other Waste"
];

export default function RecordsPage({ showToast }) {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);
  const [totalPages, setTotalPages] = useState(1);

  // Filters & sorting
  const [search, setSearch] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('All Locations');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [sortBy, setSortBy] = useState('date');
  const [sortOrder, setSortOrder] = useState('desc');

  // Modals state
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [activeRecord, setActiveRecord] = useState(null);

  // Form fields
  const [formDate, setFormDate] = useState(new Date().toISOString().slice(0, 10));
  const [formLocation, setFormLocation] = useState(LOCATIONS[0]);
  const [formCategory, setFormCategory] = useState(CATEGORIES[0]);
  const [formWeight, setFormWeight] = useState('');
  const [formRemarks, setFormRemarks] = useState('');
  const [formError, setFormError] = useState('');

  const loadRecords = async () => {
    try {
      setLoading(true);
      const res = await fetchRecords({
        page,
        pageSize,
        search,
        location: selectedLocation,
        category: selectedCategory,
        sortBy,
        sortOrder
      });
      setRecords(res.records);
      setTotal(res.total);
      setTotalPages(res.total_pages);
    } catch (err) {
      showToast({ type: 'error', message: err.message || 'Failed to load records' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRecords();
  }, [page, pageSize, selectedLocation, selectedCategory, sortBy, sortOrder]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    setPage(1);
    loadRecords();
  };

  const handleLoadBenchmark = async () => {
    try {
      setLoading(true);
      const res = await loadBenchmarkSample();
      showToast({ type: 'success', message: res.message });
      setPage(1);
      loadRecords();
    } catch (err) {
      showToast({ type: 'error', message: err.message || 'Failed to load benchmark' });
    } finally {
      setLoading(false);
    }
  };

  const openAddModal = () => {
    setFormDate(new Date().toISOString().slice(0, 10));
    setFormLocation(LOCATIONS[0]);
    setFormCategory(CATEGORIES[0]);
    setFormWeight('');
    setFormRemarks('');
    setFormError('');
    setIsAddOpen(true);
  };

  const handleCreateRecord = async (e) => {
    e.preventDefault();
    setFormError('');
    const weightNum = parseFloat(formWeight);
    if (isNaN(weightNum) || weightNum <= 0) {
      setFormError('Please enter a valid weight in kg greater than 0.');
      return;
    }

    try {
      await createRecord({
        date: formDate,
        campus_location: formLocation,
        waste_category: formCategory,
        weight_kg: weightNum,
        remarks: formRemarks
      });
      setIsAddOpen(false);
      showToast({ type: 'success', message: 'New waste record successfully created!' });
      loadRecords();
    } catch (err) {
      setFormError(err.message || 'Error creating record');
    }
  };

  const openEditModal = (rec) => {
    setActiveRecord(rec);
    setFormDate(rec.date);
    setFormLocation(rec.campus_location);
    setFormCategory(rec.waste_category);
    setFormWeight(String(rec.weight_kg));
    setFormRemarks(rec.remarks || '');
    setFormError('');
    setIsEditOpen(true);
  };

  const handleUpdateRecord = async (e) => {
    e.preventDefault();
    if (!activeRecord) return;
    setFormError('');
    const weightNum = parseFloat(formWeight);
    if (isNaN(weightNum) || weightNum <= 0) {
      setFormError('Weight must be a number greater than 0.');
      return;
    }

    try {
      await updateRecord(activeRecord.id, {
        date: formDate,
        campus_location: formLocation,
        waste_category: formCategory,
        weight_kg: weightNum,
        remarks: formRemarks
      });
      setIsEditOpen(false);
      showToast({ type: 'success', message: `Record ${activeRecord.record_id} updated successfully!` });
      loadRecords();
    } catch (err) {
      setFormError(err.message || 'Error updating record');
    }
  };

  const openDeleteModal = (rec) => {
    setActiveRecord(rec);
    setIsDeleteOpen(true);
  };

  const handleDeleteRecord = async () => {
    if (!activeRecord) return;
    try {
      await deleteRecord(activeRecord.id);
      setIsDeleteOpen(false);
      showToast({ type: 'success', message: `Record ${activeRecord.record_id} deleted!` });
      loadRecords();
    } catch (err) {
      showToast({ type: 'error', message: err.message || 'Failed to delete record' });
    }
  };

  const toggleSort = (col) => {
    if (sortBy === col) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(col);
      setSortOrder('desc');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Header & Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-display font-extrabold text-forest-900 dark:text-white">
            Campus Waste Registry
          </h1>
          <p className="text-xs sm:text-sm text-forest-600 dark:text-forest-300 mt-1">
            Comprehensive audit table for waste records with real-time editing, categorization, and weights.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={openAddModal}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold transition flex items-center space-x-1.5 shadow-glow hover:scale-105 active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Add Record</span>
          </button>

          <button
            onClick={() => exportCurrentRecordsCSV()}
            className="px-3.5 py-2 rounded-xl bg-white dark:bg-forest-900 border border-forest-200 dark:border-forest-700 text-forest-800 dark:text-forest-200 text-xs font-semibold hover:bg-forest-50 dark:hover:bg-forest-800 transition flex items-center space-x-1.5 shadow-sm hover:scale-105 active:scale-95"
            title="Download CSV file of records"
          >
            <Download className="w-4 h-4 text-emerald-600" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => exportCurrentRecordsExcel()}
            className="px-3.5 py-2 rounded-xl bg-white dark:bg-forest-900 border border-forest-200 dark:border-forest-700 text-forest-800 dark:text-forest-200 text-xs font-semibold hover:bg-forest-50 dark:hover:bg-forest-800 transition flex items-center space-x-1.5 shadow-sm hover:scale-105 active:scale-95"
            title="Download Excel spreadsheet of records"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Export Excel</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Search */}
        <form onSubmit={handleSearchSubmit} className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3 top-3 text-forest-400" />
          <input
            type="text"
            placeholder="Search record ID, area, or remarks..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
          />
        </form>

        {/* Dropdowns */}
        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          <select
            value={selectedLocation}
            onChange={(e) => { setSelectedLocation(e.target.value); setPage(1); }}
            className="text-xs font-medium px-3 py-2 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-800 dark:text-forest-200 focus:outline-none"
          >
            <option value="All Locations">All Locations</option>
            {LOCATIONS.map((l) => (
              <option key={l} value={l}>{l}</option>
            ))}
          </select>

          <select
            value={selectedCategory}
            onChange={(e) => { setSelectedCategory(e.target.value); setPage(1); }}
            className="text-xs font-medium px-3 py-2 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-800 dark:text-forest-200 focus:outline-none"
          >
            <option value="All Categories">All Categories</option>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>

          <select
            value={pageSize}
            onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }}
            className="text-xs font-medium px-2.5 py-2 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-800 dark:text-forest-200 focus:outline-none"
          >
            <option value={10}>10 / page</option>
            <option value={15}>15 / page</option>
            <option value={25}>25 / page</option>
            <option value={50}>50 / page</option>
          </select>
        </div>
      </div>

      {/* Main Table */}
      <div className="rounded-2xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-forest-50/70 dark:bg-forest-800/60 border-b border-forest-100 dark:border-forest-800 text-forest-600 dark:text-forest-300 font-semibold uppercase tracking-wider">
                <th 
                  onClick={() => toggleSort('record_id')}
                  className="py-3.5 px-4 cursor-pointer hover:text-emerald-600 transition"
                >
                  <div className="flex items-center space-x-1">
                    <span>Record ID</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th 
                  onClick={() => toggleSort('date')}
                  className="py-3.5 px-4 cursor-pointer hover:text-emerald-600 transition"
                >
                  <div className="flex items-center space-x-1">
                    <span>Date</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3.5 px-4">Campus Location</th>
                <th className="py-3.5 px-4">Waste Category</th>
                <th 
                  onClick={() => toggleSort('weight_kg')}
                  className="py-3.5 px-4 cursor-pointer hover:text-emerald-600 transition"
                >
                  <div className="flex items-center space-x-1">
                    <span>Weight (kg)</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3.5 px-4">Remarks</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-forest-50 dark:divide-forest-800/60">
              {loading ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-forest-400">
                    <div className="inline-block animate-spin w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full mb-2" />
                    <div>Loading campus records...</div>
                  </td>
                </tr>
              ) : records.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-14 text-center">
                    <div className="max-w-sm mx-auto space-y-3">
                      <div className="w-12 h-12 rounded-2xl bg-forest-100 dark:bg-forest-800 flex items-center justify-center mx-auto text-forest-500 dark:text-forest-400">
                        <FileSpreadsheet className="w-6 h-6" />
                      </div>
                      <div className="text-sm font-bold text-forest-900 dark:text-white">
                        No Records in Database
                      </div>
                      <p className="text-xs text-forest-500 dark:text-forest-400">
                        Database is clean and ready. Add your first campus waste record manually or upload a spreadsheet file.
                      </p>
                      <button
                        onClick={() => setIsAddOpen(true)}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-glow inline-flex items-center space-x-1.5 transition hover:scale-105 active:scale-95"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add First Record</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                records.map((rec) => (
                  <tr key={rec.id} className="hover:bg-forest-50/40 dark:hover:bg-forest-800/30 transition">
                    <td className="py-3 px-4 font-mono font-medium text-forest-900 dark:text-forest-100 flex items-center space-x-2">
                      <span>{rec.record_id}</span>
                      {rec.is_demo ? (
                        <span className="px-1.5 py-0.5 rounded text-[10px] bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 font-semibold" title="Synthesized sample measurement">
                          DEMO
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 font-semibold">
                          USER
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-forest-700 dark:text-forest-200">
                      {rec.date}
                    </td>
                    <td className="py-3 px-4 font-semibold text-forest-900 dark:text-white">
                      {rec.campus_location}
                    </td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-forest-100 dark:bg-forest-800 text-forest-800 dark:text-forest-200">
                        {rec.waste_category}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-bold text-emerald-600 dark:text-emerald-400">
                      {rec.weight_kg} kg
                    </td>
                    <td className="py-3 px-4 text-forest-500 dark:text-forest-400 max-w-xs truncate" title={rec.remarks}>
                      {rec.remarks || '—'}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <button
                          onClick={() => openEditModal(rec)}
                          className="p-1.5 rounded-lg text-forest-600 dark:text-forest-300 hover:text-emerald-600 hover:bg-forest-100 dark:hover:bg-forest-800 transition"
                          title="Edit Record"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => openDeleteModal(rec)}
                          className="p-1.5 rounded-lg text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950/50 transition"
                          title="Delete Record"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="p-4 border-t border-forest-100 dark:border-forest-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-forest-500 dark:text-forest-400">
          <div>
            Showing <strong className="text-forest-800 dark:text-white">{records.length}</strong> of{' '}
            <strong className="text-forest-800 dark:text-white">{total}</strong> total records
          </div>

          <div className="flex items-center space-x-2">
            <button
              disabled={page <= 1}
              onClick={() => setPage(page - 1)}
              className="px-3 py-1.5 rounded-lg border border-forest-200 dark:border-forest-700 hover:bg-forest-50 dark:hover:bg-forest-800 disabled:opacity-40 disabled:cursor-not-allowed transition flex items-center space-x-1"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Prev</span>
            </button>
            <span className="font-semibold px-2">
              Page {page} of {totalPages}
            </span>
            <button
              disabled={page >= totalPages}
              onClick={() => setPage(page + 1)}
              className="px-3 py-1.5 rounded-lg border border-forest-200 dark:border-forest-700 hover:bg-forest-50 dark:hover:bg-forest-800 disabled:opacity-40 disabled:cursor-not-allowed transition flex items-center space-x-1"
            >
              <span>Next</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* ADD RECORD MODAL */}
      <Modal isOpen={isAddOpen} onClose={() => setIsAddOpen(false)} title="Log New Campus Waste Record">
        <form onSubmit={handleCreateRecord} className="space-y-4 text-xs">
          {formError && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300">
              {formError}
            </div>
          )}

          <div className="space-y-1">
            <label className="font-semibold text-forest-800 dark:text-forest-200">Date of Measurement</label>
            <input
              type="date"
              required
              value={formDate}
              onChange={(e) => setFormDate(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-forest-800 dark:text-forest-200">Campus Facility</label>
              <select
                value={formLocation}
                onChange={(e) => setFormLocation(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-900 dark:text-white focus:outline-none"
              >
                {LOCATIONS.map((l) => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-forest-800 dark:text-forest-200">Waste Material Stream</label>
              <select
                value={formCategory}
                onChange={(e) => setFormCategory(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-900 dark:text-white focus:outline-none"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-1">
            <label className="font-semibold text-forest-800 dark:text-forest-200">Waste Weight (kg)</label>
            <input
              type="number"
              step="0.1"
              min="0.1"
              required
              placeholder="e.g. 15.5"
              value={formWeight}
              onChange={(e) => setFormWeight(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div className="space-y-1">
            <label className="font-semibold text-forest-800 dark:text-forest-200">Remarks / Operational Context</label>
            <input
              type="text"
              placeholder="e.g. Post-seminar cleanup, food preparation peels"
              value={formRemarks}
              onChange={(e) => setFormRemarks(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div className="pt-4 flex items-center justify-end space-x-2">
            <button
              type="button"
              onClick={() => setIsAddOpen(false)}
              className="px-4 py-2 rounded-xl border border-forest-200 dark:border-forest-700 text-forest-700 dark:text-forest-200 hover:bg-forest-50 dark:hover:bg-forest-800 font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-glow"
            >
              Save Record
            </button>
          </div>
        </form>
      </Modal>

      {/* EDIT RECORD MODAL */}
      <Modal isOpen={isEditOpen} onClose={() => setIsEditOpen(false)} title={`Edit Record (${activeRecord?.record_id})`}>
        <form onSubmit={handleUpdateRecord} className="space-y-4 text-xs">
          {formError && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300">
              {formError}
            </div>
          )}

          <div className="space-y-1">
            <label className="font-semibold text-forest-800 dark:text-forest-200">Date</label>
            <input
              type="date"
              required
              value={formDate}
              onChange={(e) => setFormDate(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-forest-800 dark:text-forest-200">Location</label>
              <select
                value={formLocation}
                onChange={(e) => setFormLocation(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-900 dark:text-white focus:outline-none"
              >
                {LOCATIONS.map((l) => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-forest-800 dark:text-forest-200">Category</label>
              <select
                value={formCategory}
                onChange={(e) => setFormCategory(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-900 dark:text-white focus:outline-none"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-1">
            <label className="font-semibold text-forest-800 dark:text-forest-200">Weight (kg)</label>
            <input
              type="number"
              step="0.1"
              min="0.1"
              required
              value={formWeight}
              onChange={(e) => setFormWeight(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div className="space-y-1">
            <label className="font-semibold text-forest-800 dark:text-forest-200">Remarks</label>
            <input
              type="text"
              value={formRemarks}
              onChange={(e) => setFormRemarks(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div className="pt-4 flex items-center justify-end space-x-2">
            <button
              type="button"
              onClick={() => setIsEditOpen(false)}
              className="px-4 py-2 rounded-xl border border-forest-200 dark:border-forest-700 text-forest-700 dark:text-forest-200 hover:bg-forest-50 dark:hover:bg-forest-800 font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-glow"
            >
              Update Record
            </button>
          </div>
        </form>
      </Modal>

      {/* DELETE CONFIRMATION MODAL */}
      <Modal isOpen={isDeleteOpen} onClose={() => setIsDeleteOpen(false)} title="Confirm Record Deletion">
        <div className="space-y-4 text-xs">
          <div className="p-3.5 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 flex items-start space-x-3 text-red-800 dark:text-red-200">
            <AlertTriangle className="w-5 h-5 text-red-600 dark:text-red-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-bold">Are you sure you want to delete this record?</p>
              <p className="mt-1 text-[11px] text-red-700 dark:text-red-300">
                This will permanently remove record <strong className="font-mono">{activeRecord?.record_id}</strong> ({activeRecord?.campus_location} • {activeRecord?.weight_kg} kg) from the SQLite database.
              </p>
            </div>
          </div>

          <div className="flex items-center justify-end space-x-2 pt-2">
            <button
              onClick={() => setIsDeleteOpen(false)}
              className="px-4 py-2 rounded-xl border border-forest-200 dark:border-forest-700 text-forest-700 dark:text-forest-200 hover:bg-forest-50 font-semibold"
            >
              Cancel
            </button>
            <button
              onClick={handleDeleteRecord}
              className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold shadow-sm"
            >
              Confirm Delete
            </button>
          </div>
        </div>
      </Modal>

    </div>
  );
}
