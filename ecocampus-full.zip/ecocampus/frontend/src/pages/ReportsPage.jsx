import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FileText, 
  Download, 
  Printer, 
  Calendar, 
  FileSpreadsheet, 
  Sparkles, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle,
  Building2,
  PieChart,
  Lightbulb,
  GraduationCap,
  UploadCloud,
  Database
} from 'lucide-react';
import { 
  fetchReportSummary, 
  loadBenchmarkSample, 
  exportCurrentRecordsCSV, 
  exportCurrentRecordsExcel 
} from '../utils/api';

export default function ReportsPage({ showToast }) {
  const [periodType, setPeriodType] = useState('monthly');
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadReport = async () => {
    try {
      setLoading(true);
      const data = await fetchReportSummary(periodType);
      setReport(data);
    } catch (err) {
      showToast?.({ type: 'error', message: err.message || 'Failed to generate report' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReport();
  }, [periodType]);

  const handlePrintPDF = () => {
    window.print();
  };

  const hasData = report && report.summary && report.summary.total_waste_kg > 0;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6 animate-fadeIn">
      
      {/* Top Header & Actions (hidden on print) */}
      <div className="no-print flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 mb-1.5 border border-emerald-300/40">
            <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
            <span>Official Campus Audit</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-display font-extrabold text-forest-900 dark:text-white">
            Campus Sustainability Reports
          </h1>
          <p className="text-xs sm:text-sm text-forest-600 dark:text-forest-300 mt-1">
            Executive waste management audit summary and multi-format exports.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handlePrintPDF}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-glow flex items-center space-x-1.5 transition hover:scale-105 active:scale-95"
          >
            <Printer className="w-4 h-4" />
            <span>Download / Print PDF</span>
          </button>

          <button
            onClick={() => exportCurrentRecordsCSV()}
            className="px-3.5 py-2 rounded-xl bg-white dark:bg-forest-900 border border-forest-200 dark:border-forest-700 text-forest-800 dark:text-forest-200 text-xs font-semibold hover:bg-forest-50 dark:hover:bg-forest-800 transition flex items-center space-x-1.5 shadow-sm hover:scale-105 active:scale-95"
            title="Download CSV file of records"
          >
            <Download className="w-4 h-4 text-emerald-600" />
            <span>CSV</span>
          </button>

          <button
            onClick={() => exportCurrentRecordsExcel()}
            className="px-3.5 py-2 rounded-xl bg-white dark:bg-forest-900 border border-forest-200 dark:border-forest-700 text-forest-800 dark:text-forest-200 text-xs font-semibold hover:bg-forest-50 dark:hover:bg-forest-800 transition flex items-center space-x-1.5 shadow-sm hover:scale-105 active:scale-95"
            title="Download Excel spreadsheet of records"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Excel</span>
          </button>
        </div>
      </div>

      {/* Audit Period Selector (hidden on print) */}
      <div className="no-print p-3.5 rounded-2xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-2">
          <Calendar className="w-4 h-4 text-emerald-600" />
          <span className="text-xs font-bold text-forest-800 dark:text-forest-200">Select Audit Window:</span>
        </div>

        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-forest-50/80 dark:bg-forest-950/80 border border-forest-100 dark:border-forest-800/80">
          {[
            { id: 'daily', label: 'Daily Report' },
            { id: 'weekly', label: 'Weekly Report' },
            { id: 'monthly', label: 'Monthly Report' },
          ].map((tab) => {
            const isActive = periodType === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setPeriodType(tab.id)}
                className={`relative px-4 py-1.5 rounded-lg text-xs font-bold transition-colors duration-150 ${
                  isActive
                    ? 'text-white'
                    : 'text-forest-700 dark:text-forest-300 hover:text-emerald-600'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="reportPeriodPill"
                    className="absolute inset-0 bg-gradient-to-r from-emerald-600 to-teal-600 rounded-lg shadow-glow"
                    transition={{ type: "spring", stiffness: 400, damping: 28 }}
                  />
                )}
                <span className="relative z-10">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* FORMAL CLEAN EXECUTIVE REPORT PAPER */}
      <AnimatePresence mode="wait">
        <motion.div 
          key={periodType}
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -14 }}
          transition={{ duration: 0.24 }}
          className="p-8 sm:p-10 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-glow-ambient space-y-8 print-card text-forest-900 dark:text-white"
        >
        
        {/* Document Header */}
        <div className="border-b border-forest-100 dark:border-forest-800 pb-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-widest text-emerald-600 dark:text-emerald-400">
              Campus Environmental Audit • Executive Document
            </div>
            <h2 className="text-xl sm:text-2xl font-display font-bold text-forest-900 dark:text-white mt-1">
              Waste Generation & Material Flow Audit
            </h2>
            <div className="flex flex-wrap items-center gap-2 text-xs text-forest-500 dark:text-forest-400 mt-1.5 font-medium">
              <span><strong>Period:</strong> {report?.reporting_period}</span>
              <span>•</span>
              <span><strong>Generated:</strong> {report?.generated_at}</span>
            </div>
          </div>

          <div className="text-left sm:text-right text-xs">
            <div className="font-bold text-forest-900 dark:text-white flex items-center sm:justify-end space-x-1.5">
              <GraduationCap className="w-4 h-4 text-emerald-600" />
              <span>Campus Sustainability Division</span>
            </div>
            <div className="text-forest-500 dark:text-forest-400 mt-0.5">Facility Audit Operations</div>
          </div>
        </div>

        {/* If no data exists in this audit window */}
        {!hasData ? (
          <div className="py-12 px-6 text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-forest-50 dark:bg-forest-800/80 border border-forest-200 dark:border-forest-700/80 mx-auto flex items-center justify-center text-forest-400">
              <FileText className="w-7 h-7" />
            </div>
            <div className="max-w-md mx-auto">
              <h3 className="text-base font-bold text-forest-900 dark:text-white">
                No Waste Records Logged for this Window
              </h3>
              <p className="text-xs text-forest-500 dark:text-forest-400 mt-1.5 leading-relaxed">
                The database currently contains no recorded waste measurements for this selected reporting period. Ingest campus records or switch audit periods to generate report metrics.
              </p>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2 no-print">
              <button
                onClick={async () => {
                  try {
                    await loadBenchmarkSample();
                    showToast?.({ type: 'success', message: 'Loaded brief benchmark records' });
                    loadReport();
                  } catch (err) {
                    showToast?.({ type: 'error', message: err.message || 'Failed to load sample' });
                  }
                }}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-glow flex items-center space-x-1.5 transition"
              >
                <Database className="w-4 h-4" />
                <span>Load Benchmark Dataset</span>
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* 1. EXECUTIVE KPI SUMMARY STRIP */}
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-forest-400 mb-3">
                Key Performance Indicators
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
                <div className="p-4 rounded-2xl bg-forest-50/70 dark:bg-forest-800/50 border border-forest-100 dark:border-forest-700/60">
                  <div className="text-[11px] text-forest-500 dark:text-forest-400">Total Waste Output</div>
                  <div className="text-2xl font-black text-forest-900 dark:text-white mt-1">
                    {report?.summary?.total_waste_kg} kg
                  </div>
                  <div className="text-[10px] text-forest-400 mt-0.5">
                    {report?.summary?.records_count} logged entries
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-forest-50/70 dark:bg-forest-800/50 border border-forest-100 dark:border-forest-700/60">
                  <div className="text-[11px] text-forest-500 dark:text-forest-400">Daily Average Rate</div>
                  <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
                    {report?.summary?.daily_average_kg} kg/day
                  </div>
                  <div className="text-[10px] text-emerald-600/80 mt-0.5">
                    Audit period rate
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-forest-50/70 dark:bg-forest-800/50 border border-forest-100 dark:border-forest-700/60">
                  <div className="text-[11px] text-forest-500 dark:text-forest-400">Peak Facility</div>
                  <div className="text-lg font-black text-forest-900 dark:text-white mt-1 truncate" title={report?.summary?.highest_waste_location?.location}>
                    {report?.summary?.highest_waste_location?.location || 'N/A'}
                  </div>
                  <div className="text-[10px] text-amber-600 font-semibold mt-0.5">
                    {report?.summary?.highest_waste_location?.percentage}% share ({report?.summary?.highest_waste_location?.weight_kg} kg)
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-forest-50/70 dark:bg-forest-800/50 border border-forest-100 dark:border-forest-700/60">
                  <div className="text-[11px] text-forest-500 dark:text-forest-400">Dominant Stream</div>
                  <div className="text-lg font-black text-forest-900 dark:text-white mt-1 truncate" title={report?.summary?.dominant_waste_category?.category}>
                    {report?.summary?.dominant_waste_category?.category || 'N/A'}
                  </div>
                  <div className="text-[10px] text-teal-600 dark:text-teal-400 font-semibold mt-0.5">
                    {report?.summary?.dominant_waste_category?.percentage}% share ({report?.summary?.dominant_waste_category?.weight_kg} kg)
                  </div>
                </div>
              </div>
            </div>

            {/* 2. SIDE-BY-SIDE SPATIAL & CATEGORY BREAKDOWN */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
              
              {/* Location Breakdown */}
              <div className="p-5 rounded-2xl bg-forest-50/40 dark:bg-forest-800/30 border border-forest-100 dark:border-forest-800 space-y-3">
                <div className="flex items-center justify-between pb-1 border-b border-forest-100 dark:border-forest-800">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-forest-700 dark:text-forest-300 flex items-center space-x-1.5">
                    <Building2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Campus Location Breakdown</span>
                  </h3>
                  <span className="text-[11px] text-forest-400">Ranked by volume</span>
                </div>

                <div className="space-y-3 pt-1">
                  {report?.location_analysis?.map((loc, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-forest-900 dark:text-white">{loc.location}</span>
                        <div className="flex items-center space-x-2 font-mono">
                          <span className="font-bold text-forest-800 dark:text-forest-200">{loc.weight_kg} kg</span>
                          <span className="text-[11px] text-forest-500">({loc.percentage}%)</span>
                        </div>
                      </div>
                      <div className="w-full bg-forest-200/60 dark:bg-forest-700/60 h-2 rounded-full overflow-hidden">
                        <div 
                          className="bg-emerald-500 h-full rounded-full transition-all duration-500" 
                          style={{ width: `${Math.min(100, Math.max(8, loc.percentage))}%` }} 
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Category Breakdown */}
              <div className="p-5 rounded-2xl bg-forest-50/40 dark:bg-forest-800/30 border border-forest-100 dark:border-forest-800 space-y-3">
                <div className="flex items-center justify-between pb-1 border-b border-forest-100 dark:border-forest-800">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-forest-700 dark:text-forest-300 flex items-center space-x-1.5">
                    <PieChart className="w-3.5 h-3.5 text-teal-600" />
                    <span>Material Stream Composition</span>
                  </h3>
                  <span className="text-[11px] text-forest-400">By waste type</span>
                </div>

                <div className="space-y-3 pt-1">
                  {report?.category_analysis?.map((cat, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-forest-900 dark:text-white">{cat.category}</span>
                        <div className="flex items-center space-x-2 font-mono">
                          <span className="font-bold text-teal-700 dark:text-teal-300">{cat.weight_kg} kg</span>
                          <span className="text-[11px] text-forest-500">({cat.percentage}%)</span>
                        </div>
                      </div>
                      <div className="w-full bg-forest-200/60 dark:bg-forest-700/60 h-2 rounded-full overflow-hidden">
                        <div 
                          className="bg-teal-500 h-full rounded-full transition-all duration-500" 
                          style={{ width: `${Math.min(100, Math.max(8, cat.percentage))}%` }} 
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* 3. CONCISE ACTIONABLE RECOMMENDATIONS */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center space-x-2">
                <Lightbulb className="w-4 h-4 text-emerald-600" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-forest-700 dark:text-forest-300">
                  Actionable Policy Recommendations
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                {report?.recommendations?.slice(0, 3).map((rec, i) => (
                  <div key={i} className="p-4 rounded-2xl bg-forest-50/60 dark:bg-forest-800/40 border border-forest-100 dark:border-forest-700/60 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-forest-900 dark:text-white">{rec.target}</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                        {rec.priority}
                      </span>
                    </div>
                    <p className="text-forest-600 dark:text-forest-300 leading-relaxed text-[11px]">
                      {rec.action}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Clean Document Sign-off */}
            <div className="pt-6 border-t border-forest-100 dark:border-forest-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-forest-500 dark:text-forest-400">
              <div>
                EcoCampus System • Continuous Environmental Intelligence
              </div>
              <div className="font-medium text-emerald-600 dark:text-emerald-400">
                Institutional Facility Compliance
              </div>
            </div>
          </>
        )}

      </motion.div>
      </AnimatePresence>

    </div>
  );
}
