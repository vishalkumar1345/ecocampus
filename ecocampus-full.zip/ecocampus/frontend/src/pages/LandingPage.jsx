import React, { useRef, useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowRight, 
  Sparkles, 
  BarChart3, 
  MapPin, 
  PieChart, 
  FileSpreadsheet, 
  TrendingUp, 
  Recycle, 
  ShieldCheck, 
  FileText,
  ChevronDown,
  MousePointer2,
  CheckCircle2,
  Leaf,
  UploadCloud,
  PlusCircle,
  Database
} from 'lucide-react';
import FloatingIllustration from '../components/FloatingIllustration';
import AnimatedCounter from '../components/AnimatedCounter';
import TiltCard3D from '../components/TiltCard3D';
import { fetchDashboardAnalytics } from '../utils/api';

export default function LandingPage({ setActivePage }) {
  const previewSectionRef = useRef(null);
  const [dashboardData, setDashboardData] = useState(null);
  const [dataLoading, setDataLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    async function loadPreview() {
      try {
        const data = await fetchDashboardAnalytics('all');
        if (isMounted) {
          setDashboardData(data);
        }
      } catch (err) {
        console.error('Failed to load preview dashboard data:', err);
      } finally {
        if (isMounted) setDataLoading(false);
      }
    }
    loadPreview();
    return () => { isMounted = false; };
  }, []);

  const scrollToPreview = () => {
    previewSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.12 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 35 },
    show: { 
      opacity: 1, 
      y: 0, 
      transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] } 
    }
  };

  const features = [
    {
      icon: MapPin,
      title: "Campus Location Mapping",
      desc: "Granular monitoring across Canteen, Hostels, Classrooms, Libraries, Laboratories, and Playgrounds with ranking leaderboards.",
      tag: "Spatial Analysis"
    },
    {
      icon: PieChart,
      title: "Waste Stream Segregation",
      desc: "Scientific classification across Organic/Food, Plastics, Paper, Glass, Metals, and Residual fractions with carbon offset estimates.",
      tag: "Circularity"
    },
    {
      icon: FileSpreadsheet,
      title: "Excel, CSV & ODF Ingestion",
      desc: "Intuitive drag-and-drop file upload with schema mapping, missing value alerts, and duplicate detection powered by Pandas.",
      tag: "ETL Pipeline"
    },
    {
      icon: BarChart3,
      title: "Dynamic Trend Analytics",
      desc: "Multi-interval temporal filtering (Today, 7D, 30D, Monthly, Custom) with real-time responsive visualizations.",
      tag: "Live Recharts"
    },
    {
      icon: FileText,
      title: "Executive PDF Reports",
      desc: "Comprehensive institutional sustainability reports with targeted operational recommendations ready for campus administration.",
      tag: "Print & Export"
    },
    {
      icon: ShieldCheck,
      title: "Mathematical Rigor",
      desc: "Strict numerical validation without data omission. Automated ingestion and standardization of spreadsheet datasets with zero silent discards.",
      tag: "Clean Data"
    }
  ];

  const steps = [
    {
      num: "01",
      title: "Log or Upload Dataset",
      desc: "Log daily collection measurements manually through the interactive batch grid or upload spreadsheets in Excel, CSV, or ODF format."
    },
    {
      num: "02",
      title: "Pandas Analytics Engine",
      desc: "Python backend performs real-time data cleaning, cross-tabulation, percentage computations, moving averages, and spatial ranking."
    },
    {
      num: "03",
      title: "Actionable Campus Circularity",
      desc: "Identify peak waste zones, optimize collection schedules, size composting digesters, and track campus diversion milestones."
    }
  ];

  const tickerItems = [
    "📍 8 Audited Campus Facilities",
    "♻️ 82.4% Average Diversion Viability",
    "🌱 ~1.2 Tons CO2e Offset Potential",
    "⚡ Pandas Real-time Aggregation",
    "🥗 Canteen Food Waste Digestion Ready",
    "📑 Institutional Print-Ready PDF Audit",
    "📊 6 Distinct Material Stream Categories"
  ];

  return (
    <div className="w-full overflow-hidden">
      
      {/* HERO SECTION */}
      <section className="relative pt-8 pb-16 lg:pt-16 lg:pb-24">
        
        {/* Ambient Radial Lighting Glows */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[550px] bg-gradient-to-b from-emerald-500/15 via-emerald-500/5 to-transparent blur-3xl pointer-events-none" />
        <div className="ambient-light-orb top-20 right-10 w-96 h-96 bg-emerald-400/10" />
        <div className="ambient-light-orb top-40 left-10 w-80 h-80 bg-teal-500/10" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
            
            {/* Left Content Column with Smooth Slide-in */}
            <motion.div 
              initial={{ opacity: 0, x: -40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              className="lg:col-span-7 space-y-6 text-center lg:text-left"
            >
              {/* Platform Identity Badge */}
              <motion.div 
                initial={{ opacity: 0, y: -15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-white/90 dark:bg-forest-900/90 backdrop-blur-md border border-emerald-200/80 dark:border-emerald-700/80 text-xs font-semibold text-emerald-800 dark:text-emerald-300 shadow-sm"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Campus Sustainability Intelligence Platform</span>
              </motion.div>

              {/* Main Heading */}
              <h1 className="font-display font-black text-4xl sm:text-5xl lg:text-6xl text-forest-900 dark:text-white tracking-tight leading-[1.12]">
                Understand Waste. <br />
                <span className="bg-gradient-to-r from-emerald-500 via-cyan-400 to-blue-500 bg-clip-text text-transparent">
                  Build a Cleaner Campus.
                </span>
              </h1>

              {/* Subtitle */}
              <p className="text-base sm:text-lg text-forest-700 dark:text-forest-200 max-w-xl leading-relaxed mx-auto lg:mx-0">
                A modern data-driven analytics platform that helps college management quantify waste generation across campus facilities, isolate peak disposal areas, and establish circular recycling practices.
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 pt-2">
                <button
                  onClick={() => setActivePage('dashboard')}
                  className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-glow flex items-center justify-center space-x-2 transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
                >
                  <span>Explore Dashboard</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setActivePage('upload')}
                  className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-white dark:bg-forest-900 hover:bg-forest-50 dark:hover:bg-forest-800 text-forest-800 dark:text-forest-100 font-semibold text-sm border border-forest-200/80 dark:border-forest-700/80 shadow-sm flex items-center justify-center space-x-2 transition duration-200 hover:scale-[1.01]"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-500" />
                  <span>Upload / Enter Data</span>
                </button>
              </div>

              {/* Quick Trust Highlights with lighting cards */}
              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-forest-100 dark:border-forest-800/80 max-w-lg mx-auto lg:mx-0">
                <div className="p-3 rounded-2xl bg-white/60 dark:bg-forest-900/40 backdrop-blur-sm border border-forest-100/80 dark:border-forest-800/60 shadow-sm">
                  <div className="text-2xl font-black text-forest-900 dark:text-white">
                    <AnimatedCounter value={8} duration={1000} suffix=" Sites" />
                  </div>
                  <div className="text-xs text-forest-500 dark:text-forest-400 font-medium mt-0.5">Campus Facilities</div>
                </div>
                <div className="p-3 rounded-2xl bg-white/60 dark:bg-forest-900/40 backdrop-blur-sm border border-forest-100/80 dark:border-forest-800/60 shadow-sm">
                  <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
                    <AnimatedCounter value={6} duration={1000} suffix=" Streams" />
                  </div>
                  <div className="text-xs text-forest-500 dark:text-forest-400 font-medium mt-0.5">Segregated Types</div>
                </div>
                <div className="p-3 rounded-2xl bg-white/60 dark:bg-forest-900/40 backdrop-blur-sm border border-forest-100/80 dark:border-forest-800/60 shadow-sm">
                  <div className="text-2xl font-black text-forest-900 dark:text-white">
                    <AnimatedCounter value={100} duration={1000} suffix="%" />
                  </div>
                  <div className="text-xs text-forest-500 dark:text-forest-400 font-medium mt-0.5">Pandas Powered</div>
                </div>
              </div>
            </motion.div>

            {/* Right Graphic Column with Smooth Slide-in from Right */}
            <motion.div 
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
              className="lg:col-span-5 flex items-center justify-center"
            >
              <FloatingIllustration />
            </motion.div>

          </div>
        </div>

        {/* ANIMATED SCROLL-DOWN INDICATOR */}
        <div className="pt-12 flex flex-col items-center justify-center">
          <button
            onClick={scrollToPreview}
            className="group flex flex-col items-center space-y-2 text-xs font-semibold text-forest-500 dark:text-forest-400 hover:text-emerald-600 dark:hover:text-emerald-400 transition cursor-pointer"
          >
            <span>Scroll down to explore</span>
            <motion.div
              animate={{ y: [0, 6, 0] }}
              transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
              className="w-6 h-10 rounded-full border-2 border-forest-300 dark:border-forest-700 flex items-start justify-center p-1 shadow-sm"
            >
              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
                className="w-1.5 h-2.5 rounded-full bg-emerald-500"
              />
            </motion.div>
          </button>
        </div>
      </section>

      {/* CONTINUOUS SLIDING TICKER / MARQUEE */}
      <div className="py-3 bg-white/80 dark:bg-forest-950/80 backdrop-blur-md border-y border-forest-100 dark:border-forest-800/80 overflow-hidden relative select-none">
        <motion.div
          animate={{ x: ['0%', '-50%'] }}
          transition={{ duration: 25, ease: 'linear', repeat: Infinity }}
          className="flex items-center space-x-8 whitespace-nowrap will-change-transform"
        >
          {[...tickerItems, ...tickerItems].map((text, idx) => (
            <div key={idx} className="flex items-center space-x-3 text-xs font-semibold text-forest-700 dark:text-forest-300">
              <span>{text}</span>
              <span className="text-emerald-400 text-base">•</span>
            </div>
          ))}
        </motion.div>
      </div>

      {/* DASHBOARD PREVIEW BANNER WITH BIDIRECTIONAL SCROLL REVEAL */}
      <section ref={previewSectionRef} className="py-20 bg-forest-50/50 dark:bg-forest-900/30 relative">
        <div className="ambient-light-orb top-10 left-1/4 w-96 h-96 bg-emerald-500/10" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          <motion.div 
            initial={{ opacity: 0, y: 35 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="text-center max-w-3xl mx-auto mb-12"
          >
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
              Interactive Preview
            </span>
            <h2 className="text-3xl font-display font-extrabold text-forest-900 dark:text-white mt-1">
              Engineered for Actionable Environmental Decisions
            </h2>
            <p className="text-sm text-forest-600 dark:text-forest-300 mt-2">
              Transform raw campus disposal entries into immediate high-waste heatmaps and segregation strategies.
            </p>
          </motion.div>

          {/* Interactive Card Mockup with Bidirectional Slide-Up */}
          <motion.div 
            initial={{ opacity: 0, y: 45 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false, amount: 0.2 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="card-lighting rounded-3xl bg-white dark:bg-forest-900 border border-forest-200/80 dark:border-forest-800 shadow-glow-ambient overflow-hidden p-6 lg:p-8 hover:shadow-premium-hover transition-all duration-300"
          >
            <div className="flex flex-col md:flex-row items-center justify-between pb-6 border-b border-forest-100 dark:border-forest-800 gap-4">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 rounded-full bg-red-400" />
                <div className="w-3 h-3 rounded-full bg-amber-400" />
                <div className="w-3 h-3 rounded-full bg-emerald-400" />
                <span className="text-xs font-mono text-forest-500 dark:text-forest-400 ml-2">
                  EcoCampus Analytics Dashboard • Live Metrics
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                  REAL-TIME ANALYTICS
                </span>
                <button
                  onClick={() => setActivePage('dashboard')}
                  className="text-xs font-bold text-emerald-600 hover:text-emerald-500 flex items-center space-x-1"
                >
                  <span>Open Full Dashboard</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Quick Metrics Bar in Preview */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 my-6">
              <div className="p-4 rounded-2xl bg-forest-50 dark:bg-forest-800/60 border border-forest-100 dark:border-forest-700/60 shadow-sm">
                <div className="text-xs text-forest-500 dark:text-forest-300">Total Measured Waste</div>
                <div className="text-2xl font-black text-forest-900 dark:text-white mt-1">
                  {dashboardData && dashboardData.records_count > 0 ? (
                    <span>{dashboardData.total_weight_kg.toFixed(1)} kg</span>
                  ) : (
                    <span>0.0 kg</span>
                  )}
                </div>
                <div className="text-[11px] text-emerald-600 font-medium mt-1">
                  {dashboardData && dashboardData.records_count > 0
                    ? `Across ${dashboardData.locations_count} campus locations (${dashboardData.records_count} logs)`
                    : 'Awaiting campus records'}
                </div>
              </div>
              <div className="p-4 rounded-2xl bg-forest-50 dark:bg-forest-800/60 border border-forest-100 dark:border-forest-700/60 shadow-sm">
                <div className="text-xs text-forest-500 dark:text-forest-300">Peak Waste Zone</div>
                <div className="text-2xl font-black text-forest-900 dark:text-white mt-1 truncate" title={dashboardData?.top_location?.name}>
                  {dashboardData && dashboardData.records_count > 0 && dashboardData.top_location?.name !== 'None' ? (
                    `${dashboardData.top_location.name} (${dashboardData.top_location.percentage}%)`
                  ) : (
                    'No Data'
                  )}
                </div>
                <div className="text-[11px] text-amber-600 font-medium mt-1 truncate">
                  {dashboardData && dashboardData.records_count > 0 && dashboardData.top_location?.name !== 'None'
                    ? `${dashboardData.top_location.weight_kg} kg recorded`
                    : 'Awaiting log ingestion'}
                </div>
              </div>
              <div className="p-4 rounded-2xl bg-forest-50 dark:bg-forest-800/60 border border-forest-100 dark:border-forest-700/60 shadow-sm">
                <div className="text-xs text-forest-500 dark:text-forest-300">Dominant Stream</div>
                <div className="text-2xl font-black text-forest-900 dark:text-white mt-1 truncate" title={dashboardData?.top_category?.name}>
                  {dashboardData && dashboardData.records_count > 0 && dashboardData.top_category?.name !== 'None' ? (
                    `${dashboardData.top_category.name}`
                  ) : (
                    'No Data'
                  )}
                </div>
                <div className="text-[11px] text-emerald-600 font-medium mt-1">
                  {dashboardData && dashboardData.records_count > 0 && dashboardData.top_category?.name !== 'None'
                    ? `${dashboardData.top_category.percentage}% of campus waste`
                    : 'Awaiting log ingestion'}
                </div>
              </div>
              <div className="p-4 rounded-2xl bg-forest-50 dark:bg-forest-800/60 border border-forest-100 dark:border-forest-700/60 shadow-sm">
                <div className="text-xs text-forest-500 dark:text-forest-300">Diversion Potential</div>
                <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
                  {dashboardData && dashboardData.records_count > 0 ? (
                    `~${(dashboardData.total_weight_kg * 0.45).toFixed(1)} kg`
                  ) : (
                    '0.0 kg'
                  )}
                </div>
                <div className="text-[11px] text-forest-500 dark:text-forest-400 font-medium mt-1">
                  {dashboardData && dashboardData.records_count > 0
                    ? 'Circularity & recovery target'
                    : 'Awaiting log ingestion'}
                </div>
              </div>
            </div>

            {/* Live Facility Distribution Bar Chart */}
            <div className="p-5 rounded-2xl bg-forest-50/50 dark:bg-forest-800/30 border border-forest-100 dark:border-forest-700/50 space-y-3">
              <div className="flex items-center justify-between">
                <div className="text-xs font-bold text-forest-700 dark:text-forest-300 uppercase tracking-wider">
                  Live Facility Waste Output Distribution
                </div>
                {dashboardData && dashboardData.records_count > 0 && (
                  <span className="text-[11px] text-forest-500 font-mono">
                    {dashboardData.records_count} total entries audited
                  </span>
                )}
              </div>

              {dashboardData && dashboardData.records_count > 0 && dashboardData.location_distribution?.length > 0 ? (
                <div className="space-y-3 pt-1">
                  {dashboardData.location_distribution.slice(0, 6).map((item, idx) => {
                    const maxWeight = dashboardData.location_distribution[0]?.weight_kg || 1;
                    const barWidth = Math.max(8, Math.round((item.weight_kg / maxWeight) * 100));
                    const colors = [
                      'bg-gradient-to-r from-emerald-500 to-teal-400',
                      'bg-gradient-to-r from-teal-500 to-cyan-400',
                      'bg-gradient-to-r from-cyan-500 to-blue-400',
                      'bg-gradient-to-r from-blue-500 to-indigo-400',
                      'bg-gradient-to-r from-amber-500 to-orange-400',
                      'bg-gradient-to-r from-emerald-600 to-green-400'
                    ];
                    return (
                      <div key={idx} className="flex items-center space-x-3 text-xs">
                        <span className="w-28 font-semibold text-forest-800 dark:text-forest-200 truncate" title={item.location}>
                          {item.location}
                        </span>
                        <div className="flex-1 bg-forest-200/70 dark:bg-forest-700/70 h-3 rounded-full overflow-hidden p-0.5">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${barWidth}%` }}
                            transition={{ duration: 0.8, ease: "easeOut" }}
                            className={`h-full ${colors[idx % colors.length]} rounded-full shadow-sm`} 
                          />
                        </div>
                        <div className="w-24 text-right flex items-center justify-end space-x-1 font-mono">
                          <span className="font-bold text-forest-900 dark:text-forest-100">{item.weight_kg} kg</span>
                          <span className="text-[10px] text-forest-500 dark:text-forest-400">({item.percentage}%)</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="py-8 px-4 text-center space-y-4">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 mx-auto flex items-center justify-center text-emerald-600">
                    <Database className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-forest-900 dark:text-white">
                      No Waste Records in Current Dataset
                    </h4>
                    <p className="text-xs text-forest-500 dark:text-forest-400 max-w-md mx-auto mt-1">
                      Upload your campus CSV/Excel sheet or enter measurements manually to visualize location and category breakdowns in real time.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
                    <button
                      onClick={() => setActivePage('upload')}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-glow flex items-center space-x-1.5 transition hover:scale-105 active:scale-95"
                    >
                      <UploadCloud className="w-4 h-4" />
                      <span>Upload Dataset (CSV/Excel)</span>
                    </button>
                    <button
                      onClick={() => setActivePage('records')}
                      className="px-4 py-2 rounded-xl bg-white dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-800 dark:text-forest-200 text-xs font-semibold hover:bg-forest-50 transition flex items-center space-x-1.5"
                    >
                      <PlusCircle className="w-4 h-4 text-emerald-600" />
                      <span>Manual Log Entry</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </section>

      {/* CORE FEATURES GRID WITH BIDIRECTIONAL SCROLL REVEAL */}
      <section className="py-24 relative">
        <div className="ambient-light-orb bottom-10 right-1/4 w-96 h-96 bg-emerald-500/10" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 35 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="text-center max-w-3xl mx-auto mb-16"
          >
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
              Platform Capabilities
            </span>
            <h2 className="text-3xl sm:text-4xl font-display font-extrabold text-forest-900 dark:text-white mt-1">
              Comprehensive Tools for College Waste Management
            </h2>
            <p className="text-sm sm:text-base text-forest-600 dark:text-forest-300 mt-3">
              Engineered from the ground up for students, campus sustainability officers, and facility administrators.
            </p>
          </motion.div>

          <motion.div 
            variants={containerVariants}
            initial="hidden"
            whileInView="show"
            viewport={{ once: false, amount: 0.15 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {features.map((feat, index) => {
              const Icon = feat.icon;
              return (
                <TiltCard3D key={index} tiltDegree={10} className="h-full">
                  <motion.div
                    variants={itemVariants}
                    className="card-lighting p-6 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-premium hover:shadow-premium-hover transition-all duration-300 h-full group flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <div 
                          className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500/10 via-cyan-500/10 to-teal-500/10 border border-emerald-400/30 flex items-center justify-center text-emerald-500 dark:text-emerald-400 group-hover:scale-110 shadow-glow transition-transform"
                          style={{ transform: 'translateZ(20px)' }}
                        >
                          <Icon className="w-6 h-6" />
                        </div>
                        <span 
                          className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-forest-50 dark:bg-forest-800 text-forest-600 dark:text-forest-400 font-semibold"
                          style={{ transform: 'translateZ(15px)' }}
                        >
                          {feat.tag}
                        </span>
                      </div>
                      <h3 
                        className="text-lg font-display font-bold text-forest-900 dark:text-white mb-2"
                        style={{ transform: 'translateZ(18px)' }}
                      >
                        {feat.title}
                      </h3>
                      <p className="text-xs sm:text-sm text-forest-600 dark:text-forest-300 leading-relaxed">
                        {feat.desc}
                      </p>
                    </div>
                  </motion.div>
                </TiltCard3D>
              );
            })}
          </motion.div>
        </div>
      </section>

      {/* HOW IT WORKS / SLIDING TIMELINE WITH BIDIRECTIONAL SCROLL */}
      <section className="py-24 bg-forest-50/60 dark:bg-forest-900/40 border-t border-forest-100 dark:border-forest-800 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 35 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false, amount: 0.2 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-2xl mx-auto mb-16"
          >
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
              Workflow Pipeline
            </span>
            <h2 className="text-3xl font-display font-extrabold text-forest-900 dark:text-white mt-1">
              How EcoCampus Works
            </h2>
            <p className="text-sm text-forest-600 dark:text-forest-300 mt-2">
              From field weight measurements to institutional policy formulation in three intuitive steps.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((st, i) => (
              <TiltCard3D key={i} tiltDegree={10} className="h-full">
                <motion.div 
                  initial={{ opacity: 0, y: 35 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: false, amount: 0.2 }}
                  transition={{ duration: 0.5, delay: i * 0.12, ease: [0.16, 1, 0.3, 1] }}
                  className="card-lighting relative p-7 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm hover:shadow-glow transition-all duration-300 h-full flex flex-col justify-between"
                >
                  <div>
                    <div 
                      className="text-5xl font-black font-display text-emerald-500/25 dark:text-emerald-400/25 mb-3"
                      style={{ transform: 'translateZ(25px)' }}
                    >
                      {st.num}
                    </div>
                    <h3 
                      className="text-base font-bold text-forest-900 dark:text-white mb-2"
                      style={{ transform: 'translateZ(18px)' }}
                    >
                      {st.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-forest-600 dark:text-forest-300 leading-relaxed">
                      {st.desc}
                    </p>
                  </div>
                </motion.div>
              </TiltCard3D>
            ))}
          </div>
        </div>
      </section>

      {/* BOTTOM INVITATION CTA WITH LIGHTING GLOW */}
      <section className="py-20 relative">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, scale: 0.94 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: false, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="rounded-3xl bg-gradient-to-br from-forest-800 via-forest-900 to-emerald-950 text-white p-8 sm:p-14 text-center relative overflow-hidden shadow-glow-lg border border-emerald-500/30"
          >
            {/* Ambient Lighting orbs */}
            <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/25 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-80 h-80 bg-teal-500/20 rounded-full blur-3xl pointer-events-none" />
            
            <div className="relative z-10 space-y-4">
              <span className="inline-block px-3.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold tracking-wide uppercase border border-emerald-400/30 backdrop-blur-md">
                Ready for Campus Audit
              </span>
              <h2 className="text-3xl sm:text-4xl font-display font-black tracking-tight">
                "Measure Waste Today. Create a Greener Tomorrow."
              </h2>
              <p className="text-sm sm:text-base text-forest-200 max-w-xl mx-auto">
                Ready to review the interactive metrics? Dive into the live dashboard or inspect location-specific profiles.
              </p>
              <div className="pt-3">
                <button
                  onClick={() => setActivePage('dashboard')}
                  className="px-8 py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-sm shadow-glow transition duration-200 hover:scale-105 active:scale-95"
                >
                  Launch Dashboard Now
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

    </div>
  );
}
