import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  UploadCloud, 
  FileSpreadsheet, 
  CheckCircle2, 
  AlertTriangle, 
  Download, 
  ArrowRight, 
  RefreshCw,
  Sparkles,
  Info,
  Plus,
  Trash2,
  Table,
  Edit3,
  Check,
  RotateCcw,
  Layers,
  FileCode
} from 'lucide-react';
import { uploadPreviewFile, confirmImport, createBatchRecords, downloadSampleCSVTemplate } from '../utils/api';

const TARGET_FIELDS = [
  { key: 'date', label: 'Date', required: true, example: '2026-11-20' },
  { key: 'campus_location', label: 'Campus Location', required: true, example: 'Canteen, Hostel' },
  { key: 'waste_category', label: 'Waste Category', required: true, example: 'Organic, Plastic' },
  { key: 'weight_kg', label: 'Weight (kg)', required: true, example: '14.5' },
  { key: 'remarks', label: 'Remarks / Notes', required: false, example: 'Event cleanup' },
];

const STANDARD_LOCATIONS = [
  'Canteen',
  'Hostel',
  'Classrooms',
  'Library',
  'Playground',
  'Laboratories',
  'Auditorium',
  'Administrative Block',
  'Sports Complex',
  'Campus Grounds'
];

const STANDARD_CATEGORIES = [
  'Organic / Food Waste',
  'Plastic Waste',
  'Paper Waste',
  'Metal Waste',
  'Glass Waste',
  'Other Waste'
];

const getTodayDate = () => {
  const d = new Date();
  return d.toISOString().split('T')[0];
};

export default function UploadPage({ showToast, setActivePage }) {
  // Mode: 'file' or 'manual'
  const [activeTab, setActiveTab] = useState('file');

  // --- FILE UPLOAD STATE ---
  const [file, setFile] = useState(null);
  const [dragActive, setDragActive] = useState(false);
  const [previewData, setPreviewData] = useState(null);
  const [mapping, setMapping] = useState({});
  const [skipDuplicates, setSkipDuplicates] = useState(true);
  const [importing, setImporting] = useState(false);
  const [previewing, setPreviewing] = useState(false);
  const [importResult, setImportResult] = useState(null);
  const inputRef = useRef(null);

  // --- MANUAL DATA ENTRY STATE (Clean Start) ---
  const [manualRows, setManualRows] = useState([
    { id: 1, date: getTodayDate(), campus_location: 'Canteen', waste_category: 'Organic / Food Waste', weight_kg: '', remarks: '' },
  ]);
  const [manualSubmitting, setManualSubmitting] = useState(false);
  const [manualResult, setManualResult] = useState(null);

  // --- FILE DRAG & DROP HANDLERS ---
  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processSelectedFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      processSelectedFile(e.target.files[0]);
    }
  };

  const processSelectedFile = async (selectedFile) => {
    const ext = selectedFile.name.split('.').pop().toLowerCase();
    const validExtensions = ['csv', 'xlsx', 'xls', 'ods', 'odf'];
    if (!validExtensions.includes(ext)) {
      showToast({ 
        type: 'error', 
        message: 'Unsupported format. Please upload CSV (.csv), Excel (.xlsx, .xls), or ODF (.ods, .odf).' 
      });
      return;
    }

    setFile(selectedFile);
    setImportResult(null);
    setPreviewing(true);

    try {
      const res = await uploadPreviewFile(selectedFile);
      setPreviewData(res);
      setMapping(res.suggested_mapping || {});
      showToast({ type: 'success', message: `File analyzed: ${res.total_rows} rows detected.` });
    } catch (err) {
      showToast({ type: 'error', message: err.message || 'Error parsing file.' });
      setPreviewData(null);
    } finally {
      setPreviewing(false);
    }
  };

  const handleMappingChange = (fieldKey, selectedCol) => {
    setMapping((prev) => ({
      ...prev,
      [fieldKey]: selectedCol === '' ? null : selectedCol
    }));
  };

  const handleConfirmImport = async () => {
    if (!previewData) return;

    for (const tf of TARGET_FIELDS) {
      if (tf.required && !mapping[tf.key]) {
        showToast({ type: 'error', message: `Please map column for required field "${tf.label}"` });
        return;
      }
    }

    try {
      setImporting(true);
      const res = await confirmImport(previewData.file_id, mapping, skipDuplicates);
      setImportResult(res);
      showToast({ type: 'success', message: `Successfully imported ${res.imported_count} records!` });
    } catch (err) {
      showToast({ type: 'error', message: err.message || 'Failed to import records' });
    } finally {
      setImporting(false);
    }
  };

  const resetUpload = () => {
    setFile(null);
    setPreviewData(null);
    setMapping({});
    setImportResult(null);
    if (inputRef.current) inputRef.current.value = '';
  };

  // --- MANUAL ENTRY HANDLERS ---
  const handleAddRow = () => {
    const newId = manualRows.length > 0 ? Math.max(...manualRows.map(r => r.id)) + 1 : 1;
    setManualRows([
      ...manualRows,
      { id: newId, date: getTodayDate(), campus_location: 'Canteen', waste_category: 'Organic / Food Waste', weight_kg: '', remarks: '' }
    ]);
  };

  const handleAddMultipleRows = (count = 5) => {
    const currentMax = manualRows.length > 0 ? Math.max(...manualRows.map(r => r.id)) : 0;
    const newItems = Array.from({ length: count }, (_, i) => ({
      id: currentMax + i + 1,
      date: getTodayDate(),
      campus_location: STANDARD_LOCATIONS[i % STANDARD_LOCATIONS.length],
      waste_category: STANDARD_CATEGORIES[i % STANDARD_CATEGORIES.length],
      weight_kg: '',
      remarks: ''
    }));
    setManualRows([...manualRows, ...newItems]);
  };

  const handleRemoveRow = (id) => {
    if (manualRows.length <= 1) {
      showToast({ type: 'error', message: 'At least one row is required in the grid.' });
      return;
    }
    setManualRows(manualRows.filter(r => r.id !== id));
  };

  const handleRowChange = (id, field, value) => {
    setManualRows(manualRows.map(row => {
      if (row.id === id) {
        return { ...row, [field]: value };
      }
      return row;
    }));
  };

  const handleLoadBenchmarkRows = () => {
    setManualRows([
      { id: 101, date: getTodayDate(), campus_location: 'Canteen', waste_category: 'Organic / Food Waste', weight_kg: '15.0', remarks: 'Brief Benchmark: Canteen food waste' },
      { id: 102, date: getTodayDate(), campus_location: 'Classrooms', waste_category: 'Paper Waste', weight_kg: '8.0', remarks: 'Brief Benchmark: Classroom paper waste' },
      { id: 103, date: getTodayDate(), campus_location: 'Hostel', waste_category: 'Plastic Waste', weight_kg: '12.0', remarks: 'Brief Benchmark: Hostel plastic waste' },
      { id: 104, date: getTodayDate(), campus_location: 'Library', waste_category: 'Paper Waste', weight_kg: '5.0', remarks: 'Brief Benchmark: Library paper waste' },
      { id: 105, date: getTodayDate(), campus_location: 'Playground', waste_category: 'Plastic Waste', weight_kg: '6.0', remarks: 'Brief Benchmark: Playground plastic waste' },
    ]);
    showToast({ type: 'success', message: 'Loaded 5 benchmark rows from project brief into entry grid.' });
  };

  const handleClearGrid = () => {
    setManualRows([
      { id: 1, date: getTodayDate(), campus_location: 'Canteen', waste_category: 'Organic / Food Waste', weight_kg: '', remarks: '' }
    ]);
    setManualResult(null);
  };

  const handleSubmitManualBatch = async () => {
    // Validate rows
    const cleaned = [];
    for (let i = 0; i < manualRows.length; i++) {
      const row = manualRows[i];
      const w = parseFloat(row.weight_kg);
      if (!row.date) {
        showToast({ type: 'error', message: `Row #${i + 1}: Missing date.` });
        return;
      }
      if (!row.campus_location) {
        showToast({ type: 'error', message: `Row #${i + 1}: Missing location.` });
        return;
      }
      if (!row.waste_category) {
        showToast({ type: 'error', message: `Row #${i + 1}: Missing category.` });
        return;
      }
      if (isNaN(w) || w <= 0) {
        showToast({ type: 'error', message: `Row #${i + 1}: Weight must be a positive number greater than 0 kg.` });
        return;
      }
      cleaned.push({
        date: row.date,
        campus_location: row.campus_location,
        waste_category: row.waste_category,
        weight_kg: w,
        remarks: row.remarks || 'Manual batch entry'
      });
    }

    try {
      setManualSubmitting(true);
      const res = await createBatchRecords(cleaned);
      setManualResult(res);
      showToast({ type: 'success', message: `Successfully inserted ${res.inserted_count} records into database!` });
    } catch (err) {
      showToast({ type: 'error', message: err.message || 'Failed to submit manual records.' });
    } finally {
      setManualSubmitting(false);
    }
  };

  // Compute live statistics for manual grid
  const validRowCount = manualRows.filter(r => parseFloat(r.weight_kg) > 0).length;
  const totalWeightInGrid = manualRows
    .reduce((sum, r) => sum + (parseFloat(r.weight_kg) > 0 ? parseFloat(r.weight_kg) : 0), 0)
    .toFixed(1);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fadeIn">
      
      {/* Top Ambient Lighting Glow Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-forest-900 via-cyan-950 to-forest-850 p-6 sm:p-8 text-white shadow-glow-ambient border border-cyan-500/30">
        <div className="absolute -top-24 -right-24 w-80 h-80 rounded-full bg-cyan-500/20 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-80 h-80 rounded-full bg-emerald-500/20 blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-semibold backdrop-blur-md">
              <Sparkles className="w-3.5 h-3.5 animate-pulse text-emerald-400" />
              <span>Multi-Source Ingestion Engine</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-display font-extrabold tracking-tight">
              Campus Waste Data Ingestion
            </h1>
            <p className="text-xs sm:text-sm text-forest-200 leading-relaxed">
              Import waste measurement records via spreadsheet upload (<strong>Excel</strong>, <strong>CSV</strong>, or <strong>ODF</strong>) or use the interactive <strong>Manual Batch Data Entry Grid</strong> with instant SQLite validation.
            </p>
          </div>

          {/* Quick template download */}
          <button
            onClick={() => downloadSampleCSVTemplate()}
            className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-semibold backdrop-blur-md transition flex items-center space-x-2 self-start md:self-center shadow-lg hover:shadow-glow hover:scale-105 active:scale-95"
          >
            <Download className="w-4 h-4 text-cyan-300" />
            <span>Download CSV Template</span>
          </button>
        </div>
      </div>

      {/* MODE TABS SWITCHER WITH ANIMATED SLIDING PILL */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-1.5 bg-forest-50/80 dark:bg-forest-900/60 rounded-2xl border border-forest-100 dark:border-forest-800 backdrop-blur-md">
        <div className="grid grid-cols-2 gap-2 w-full sm:w-auto relative">
          <button
            onClick={() => setActiveTab('file')}
            className={`relative flex items-center justify-center space-x-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all duration-200 ${
              activeTab === 'file'
                ? 'text-white'
                : 'text-forest-700 dark:text-forest-300 hover:bg-forest-100 dark:hover:bg-forest-800'
            }`}
          >
            {activeTab === 'file' && (
              <motion.div
                layoutId="uploadActiveTabPill"
                className="absolute inset-0 bg-gradient-to-r from-emerald-600 to-teal-600 rounded-xl shadow-glow"
                transition={{ type: "spring", stiffness: 380, damping: 28 }}
              />
            )}
            <span className="relative z-10 flex items-center space-x-2">
              <FileSpreadsheet className="w-4 h-4" />
              <span>Spreadsheet File Upload</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/20 ml-1 font-mono">Excel / CSV / ODF</span>
            </span>
          </button>

          <button
            onClick={() => setActiveTab('manual')}
            className={`relative flex items-center justify-center space-x-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all duration-200 ${
              activeTab === 'manual'
                ? 'text-white'
                : 'text-forest-700 dark:text-forest-300 hover:bg-forest-100 dark:hover:bg-forest-800'
            }`}
          >
            {activeTab === 'manual' && (
              <motion.div
                layoutId="uploadActiveTabPill"
                className="absolute inset-0 bg-gradient-to-r from-emerald-600 to-teal-600 rounded-xl shadow-glow"
                transition={{ type: "spring", stiffness: 380, damping: 28 }}
              />
            )}
            <span className="relative z-10 flex items-center space-x-2">
              <Table className="w-4 h-4" />
              <span>Manual Data Entry Grid</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/20 ml-1 font-mono">Interactive</span>
            </span>
          </button>
        </div>

        {/* Format Compatibility Badges */}
        <div className="flex items-center space-x-2 text-[11px] text-forest-500 dark:text-forest-400 font-medium px-2">
          <span>Supported:</span>
          <span className="px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-semibold border border-emerald-200 dark:border-emerald-800">
            .xlsx / .xls
          </span>
          <span className="px-2 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 font-semibold border border-blue-200 dark:border-blue-800">
            .csv
          </span>
          <span className="px-2 py-0.5 rounded-md bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 font-semibold border border-purple-200 dark:border-purple-800">
            .ods / .odf
          </span>
        </div>
      </div>

      {/* ======================================================== */}
      {/* ANIMATED TAB PANELS (In & Out Transitions)               */}
      {/* ======================================================== */}
      <AnimatePresence mode="wait">
        {activeTab === 'file' ? (
          <motion.div
            key="spreadsheet-upload-tab"
            initial={{ opacity: 0, y: 16, scale: 0.99 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -16, scale: 0.99 }}
            transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-6"
          >

          {/* Pandas Data Cleaning Protocol Card */}
          <div className="p-5 rounded-2xl bg-forest-50/70 dark:bg-forest-900/40 border border-forest-100 dark:border-forest-800 space-y-2 text-xs shadow-sm">
            <div className="flex items-center space-x-2 text-emerald-700 dark:text-emerald-400 font-bold">
              <Sparkles className="w-4 h-4" />
              <span className="uppercase tracking-wider">Automated Pandas Data Cleaning & Preparation Pipeline</span>
            </div>
            <p className="text-forest-600 dark:text-forest-300 leading-relaxed">
              Uploaded files pass through rigorous data hygiene filters: (1) <strong>Missing entries</strong> are inspected via <code className="font-mono text-emerald-600">isnull()</code> and flagged; (2) <strong>Duplicates</strong> are filtered via <code className="font-mono text-emerald-600">drop_duplicates()</code>; (3) <strong>Category synonyms</strong> (e.g. "Food" → "Organic / Food Waste") and locations are automatically standardized; (4) <strong>Weights</strong> are coerced to positive numerical floats (&gt; 0 kg) via <code className="font-mono text-emerald-600">pd.to_numeric()</code>.
            </p>
          </div>

          {/* DRAG AND DROP ZONE */}
          {!previewData && (
            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              onClick={() => inputRef.current?.click()}
              className={`border-2 border-dashed rounded-3xl p-10 sm:p-14 text-center cursor-pointer transition-all duration-200 flex flex-col items-center justify-center space-y-4 shadow-sm hover:shadow-glow relative overflow-hidden ${
                dragActive
                  ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/30 scale-[1.01]'
                  : 'border-forest-200 dark:border-forest-700 hover:border-emerald-500 bg-white dark:bg-forest-900'
              }`}
            >
              <input
                ref={inputRef}
                type="file"
                accept=".csv, .xlsx, .xls, .ods, .odf"
                onChange={handleFileChange}
                className="hidden"
              />

              <div className="w-16 h-16 rounded-2xl bg-emerald-50 dark:bg-forest-800 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shadow-glow">
                <UploadCloud className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <h3 className="text-base sm:text-lg font-bold text-forest-900 dark:text-white">
                  Drag & Drop your spreadsheet here, or <span className="text-emerald-600 dark:text-emerald-400 underline">Browse File</span>
                </h3>
                <p className="text-xs text-forest-500 dark:text-forest-400">
                  Supports <strong>Excel (.xlsx, .xls)</strong>, <strong>CSV (.csv)</strong>, and <strong>ODF OpenDocument (.ods, .odf)</strong> up to 25MB
                </p>
              </div>

              <div className="pt-2 flex flex-wrap items-center justify-center gap-2 text-[11px] text-forest-400">
                <span className="px-2.5 py-1 rounded-md bg-forest-50 dark:bg-forest-800 font-mono">Date</span>
                <span className="px-2.5 py-1 rounded-md bg-forest-50 dark:bg-forest-800 font-mono">Campus Location</span>
                <span className="px-2.5 py-1 rounded-md bg-forest-50 dark:bg-forest-800 font-mono">Waste Category</span>
                <span className="px-2.5 py-1 rounded-md bg-forest-50 dark:bg-forest-800 font-mono">Weight (kg)</span>
                <span className="px-2.5 py-1 rounded-md bg-forest-50 dark:bg-forest-800 font-mono">Remarks (Optional)</span>
              </div>

              {previewing && (
                <div className="flex items-center space-x-2 text-xs font-semibold text-emerald-600 animate-pulse pt-2">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Analyzing spreadsheet headers, nulls, and rows...</span>
                </div>
              )}
            </div>
          )}

          {/* PREVIEW & COLUMN MAPPING */}
          {previewData && !importResult && (
            <div className="space-y-6">
              
              {/* File Card Banner */}
              <div className="p-5 rounded-2xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center space-x-3.5">
                  <div className="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-forest-800 border border-emerald-200 dark:border-forest-700 flex items-center justify-center text-emerald-600">
                    <FileSpreadsheet className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-forest-900 dark:text-white flex items-center space-x-2">
                      <span>{previewData.filename}</span>
                      <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-mono">
                        {previewData.file_size_kb} KB
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 font-mono uppercase">
                        {previewData.extension}
                      </span>
                    </div>
                    <div className="text-xs text-forest-500 dark:text-forest-400 mt-0.5">
                      Detected <strong className="text-emerald-600 dark:text-emerald-400">{previewData.total_rows} rows</strong> • {previewData.columns.length} columns • {previewData.file_duplicates} internal duplicate rows
                    </div>
                  </div>
                </div>

                <button
                  onClick={resetUpload}
                  className="text-xs font-semibold text-forest-500 hover:text-red-500 transition"
                >
                  Choose different file
                </button>
              </div>

              {/* Column Mapping Section */}
              <div className="p-6 rounded-2xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm space-y-4">
                <div>
                  <h3 className="font-display font-bold text-base text-forest-900 dark:text-white">
                    Step 1: Verify Column Mapping
                  </h3>
                  <p className="text-xs text-forest-500 dark:text-forest-400">
                    Match your dataset columns to EcoCampus target fields. Auto-detected values are selected below.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
                  {TARGET_FIELDS.map((tf) => (
                    <div key={tf.key} className="p-3.5 rounded-xl bg-forest-50/70 dark:bg-forest-800/50 border border-forest-100 dark:border-forest-700/60 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-forest-900 dark:text-white flex items-center space-x-1">
                          <span>{tf.label}</span>
                          {tf.required && <span className="text-red-500">*</span>}
                        </span>
                        <span className="text-[10px] text-forest-400 font-mono">ex: {tf.example}</span>
                      </div>

                      <select
                        value={mapping[tf.key] || ''}
                        onChange={(e) => handleMappingChange(tf.key, e.target.value)}
                        className="w-full text-xs font-medium px-2.5 py-1.5 rounded-lg bg-white dark:bg-forest-900 border border-forest-200 dark:border-forest-700 text-forest-800 dark:text-forest-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      >
                        <option value="">— Select Column —</option>
                        {previewData.columns.map((col) => (
                          <option key={col} value={col}>{col}</option>
                        ))}
                      </select>
                    </div>
                  ))}
                </div>

                {/* Ingestion Options */}
                <div className="pt-2 flex items-center space-x-2 text-xs text-forest-700 dark:text-forest-300">
                  <input
                    type="checkbox"
                    id="skipDupes"
                    checked={skipDuplicates}
                    onChange={(e) => setSkipDuplicates(e.target.checked)}
                    className="rounded border-forest-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                  />
                  <label htmlFor="skipDupes" className="cursor-pointer font-medium">
                    Skip duplicate records (matching same date, location, category, and weight in database)
                  </label>
                </div>
              </div>

              {/* Missing Values & Diagnostics Summary */}
              <div className="p-5 rounded-2xl bg-forest-50/60 dark:bg-forest-900/40 border border-forest-100 dark:border-forest-800 space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-forest-700 dark:text-forest-300 flex items-center space-x-1.5">
                  <Info className="w-4 h-4 text-emerald-600" />
                  <span>Dataset Hygiene Diagnostics</span>
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  {Object.entries(previewData.missing_summary).map(([col, missingCount]) => (
                    <div key={col} className="p-2.5 rounded-lg bg-white dark:bg-forest-800 border border-forest-100 dark:border-forest-700">
                      <div className="text-[11px] font-mono text-forest-500 dark:text-forest-400 truncate">{col}</div>
                      <div className="text-sm font-bold text-forest-900 dark:text-white mt-0.5">
                        {missingCount > 0 ? (
                          <span className="text-amber-600 font-semibold">{missingCount} missing</span>
                        ) : (
                          <span className="text-emerald-600">0 nulls</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* First 10 Sample Rows Preview Table */}
              <div className="p-6 rounded-2xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm space-y-3">
                <h3 className="font-display font-bold text-base text-forest-900 dark:text-white">
                  Data Sample (First 10 Rows)
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-forest-50/70 dark:bg-forest-800/60 border-b border-forest-100 dark:border-forest-800 font-semibold text-forest-600 dark:text-forest-300">
                        <th className="py-2 px-3">#</th>
                        {previewData.columns.map((c) => (
                          <th key={c} className="py-2 px-3 font-mono">{c}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-forest-50 dark:divide-forest-800/60">
                      {previewData.preview_rows.map((row, idx) => (
                        <tr key={idx} className="hover:bg-forest-50/50 dark:hover:bg-forest-800/40">
                          <td className="py-2 px-3 text-forest-400 font-mono">{idx + 1}</td>
                          {previewData.columns.map((c) => (
                            <td key={c} className="py-2 px-3 text-forest-800 dark:text-forest-200">
                              {row[c] !== null && row[c] !== undefined ? String(row[c]) : <span className="text-forest-400 italic">null</span>}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Action Bar */}
              <div className="flex items-center justify-end space-x-3 pt-2">
                <button
                  onClick={resetUpload}
                  className="px-4 py-2.5 rounded-xl border border-forest-200 dark:border-forest-700 text-forest-700 dark:text-forest-200 text-xs font-semibold hover:bg-forest-50"
                >
                  Cancel
                </button>
                <button
                  disabled={importing}
                  onClick={handleConfirmImport}
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-glow flex items-center space-x-2 transition disabled:opacity-50"
                >
                  {importing ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Validating & Importing...</span>
                    </>
                  ) : (
                    <>
                      <span>Import Records into Database</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>

            </div>
          )}

          {/* IMPORT RESULTS REPORT */}
          {importResult && (
            <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-xl space-y-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 shadow-glow">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-display font-extrabold text-xl text-forest-900 dark:text-white">
                    File Ingestion Completed Successfully
                  </h3>
                  <p className="text-xs text-forest-500 dark:text-forest-400">
                    All records validated, standardized, and stored into SQLite database.
                  </p>
                </div>
              </div>

              {/* Metrics summary */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
                  <div className="text-xs text-emerald-800 dark:text-emerald-300 font-semibold">Imported Records</div>
                  <div className="text-3xl font-black text-emerald-700 dark:text-emerald-400 mt-1">
                    {importResult.imported_count}
                  </div>
                  <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-0.5">Tagged as USER DATA</div>
                </div>

                <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800">
                  <div className="text-xs text-amber-800 dark:text-amber-300 font-semibold">Skipped Duplicates</div>
                  <div className="text-3xl font-black text-amber-700 dark:text-amber-400 mt-1">
                    {importResult.duplicate_count}
                  </div>
                  <div className="text-[11px] text-amber-600 dark:text-amber-400 mt-0.5">Existing database keys matched</div>
                </div>

                <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800">
                  <div className="text-xs text-red-800 dark:text-red-300 font-semibold">Invalid / Rejected Rows</div>
                  <div className="text-3xl font-black text-red-700 dark:text-red-400 mt-1">
                    {importResult.invalid_count}
                  </div>
                  <div className="text-[11px] text-red-600 dark:text-red-400 mt-0.5">Detailed below (never silently dropped)</div>
                </div>
              </div>

              {/* Diagnostics of Invalid Rows if any */}
              {importResult.invalid_records?.length > 0 && (
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-red-600 uppercase tracking-wider flex items-center space-x-1">
                    <AlertTriangle className="w-4 h-4" />
                    <span>Rejected Rows Audit</span>
                  </h4>
                  <div className="border border-red-200 dark:border-red-800 rounded-xl overflow-hidden text-xs">
                    {importResult.invalid_records.map((inv, i) => (
                      <div key={i} className="p-3 border-b border-red-100 dark:border-red-900/50 bg-red-50/40 dark:bg-red-950/20 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <span className="font-mono font-bold text-red-700 dark:text-red-300">
                          Row #{inv.row_number}
                        </span>
                        <span className="text-red-600 dark:text-red-400 font-medium">
                          Errors: {inv.errors.join(', ')}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Navigation CTA */}
              <div className="pt-4 flex flex-wrap items-center justify-between gap-3 border-t border-forest-100 dark:border-forest-800">
                <button
                  onClick={resetUpload}
                  className="px-4 py-2 rounded-xl border border-forest-200 dark:border-forest-700 text-forest-700 dark:text-forest-200 text-xs font-semibold hover:bg-forest-50"
                >
                  Upload Another File
                </button>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setActivePage('records')}
                    className="px-4 py-2 rounded-xl bg-forest-100 dark:bg-forest-800 text-forest-800 dark:text-forest-200 text-xs font-bold hover:bg-forest-200"
                  >
                    View in Records Table
                  </button>
                  <button
                    onClick={() => setActivePage('dashboard')}
                    className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-glow flex items-center space-x-1.5"
                  >
                    <span>Open Dashboard</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          )}

          </motion.div>
        ) : (
          <motion.div
            key="manual-entry-tab"
            initial={{ opacity: 0, y: 16, scale: 0.99 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -16, scale: 0.99 }}
            transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-6"
          >
          
          {/* Top Control Header & Benchmark Loader */}
          <div className="p-5 rounded-2xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <h3 className="font-display font-bold text-base text-forest-900 dark:text-white">
                  Interactive Batch Record Grid
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold">
                  {manualRows.length} Rows
                </span>
                <span className="px-2 py-0.5 rounded-full bg-forest-100 dark:bg-forest-800 text-forest-700 dark:text-forest-300 text-[10px] font-mono">
                  {totalWeightInGrid} kg Total
                </span>
              </div>
              <p className="text-xs text-forest-500 dark:text-forest-400">
                Type or modify multiple records simultaneously. Add rows, adjust weights, and click Submit to push them straight into the database.
              </p>
            </div>

            {/* Quick Actions */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleLoadBenchmarkRows}
                className="px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs font-bold hover:bg-emerald-100 transition flex items-center space-x-1.5"
                title="Populate table with the 5 illustrative records from the problem brief"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span>Load 5 Brief Samples</span>
              </button>

              <button
                type="button"
                onClick={handleAddRow}
                className="px-3 py-1.5 rounded-xl bg-forest-100 dark:bg-forest-800 text-forest-800 dark:text-forest-200 text-xs font-bold hover:bg-forest-200 transition flex items-center space-x-1"
              >
                <Plus className="w-3.5 h-3.5 text-emerald-600" />
                <span>Add Row</span>
              </button>

              <button
                type="button"
                onClick={() => handleAddMultipleRows(5)}
                className="px-3 py-1.5 rounded-xl bg-forest-100 dark:bg-forest-800 text-forest-800 dark:text-forest-200 text-xs font-bold hover:bg-forest-200 transition flex items-center space-x-1"
              >
                <Plus className="w-3.5 h-3.5 text-emerald-600" />
                <span>+5 Rows</span>
              </button>

              <button
                type="button"
                onClick={handleClearGrid}
                className="px-2.5 py-1.5 rounded-xl border border-forest-200 dark:border-forest-700 text-forest-500 hover:text-red-500 text-xs font-semibold transition"
                title="Reset grid"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Interactive Multi-Row Table */}
          <div className="rounded-2xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-forest-50/80 dark:bg-forest-800/80 border-b border-forest-100 dark:border-forest-800 font-bold text-forest-700 dark:text-forest-200 uppercase tracking-wider text-[11px]">
                    <th className="py-3 px-3 w-12 text-center">#</th>
                    <th className="py-3 px-3 w-36">Date</th>
                    <th className="py-3 px-3 w-48">Campus Location</th>
                    <th className="py-3 px-3 w-52">Waste Category</th>
                    <th className="py-3 px-3 w-32">Weight (kg)</th>
                    <th className="py-3 px-3">Remarks / Context</th>
                    <th className="py-3 px-3 w-14 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-forest-50 dark:divide-forest-800/50">
                  {manualRows.map((row, index) => (
                    <tr key={row.id} className="hover:bg-forest-50/40 dark:hover:bg-forest-800/30 transition-colors">
                      <td className="py-2.5 px-3 text-center text-forest-400 font-mono">
                        {index + 1}
                      </td>

                      {/* Date */}
                      <td className="py-2.5 px-3">
                        <input
                          type="date"
                          value={row.date}
                          onChange={(e) => handleRowChange(row.id, 'date', e.target.value)}
                          className="w-full px-2.5 py-1.5 rounded-lg border border-forest-200 dark:border-forest-700 bg-white dark:bg-forest-800 text-forest-800 dark:text-forest-100 text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                        />
                      </td>

                      {/* Location dropdown */}
                      <td className="py-2.5 px-3">
                        <select
                          value={row.campus_location}
                          onChange={(e) => handleRowChange(row.id, 'campus_location', e.target.value)}
                          className="w-full px-2.5 py-1.5 rounded-lg border border-forest-200 dark:border-forest-700 bg-white dark:bg-forest-800 text-forest-800 dark:text-forest-100 text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none font-medium"
                        >
                          {STANDARD_LOCATIONS.map((loc) => (
                            <option key={loc} value={loc}>{loc}</option>
                          ))}
                        </select>
                      </td>

                      {/* Category dropdown */}
                      <td className="py-2.5 px-3">
                        <select
                          value={row.waste_category}
                          onChange={(e) => handleRowChange(row.id, 'waste_category', e.target.value)}
                          className="w-full px-2.5 py-1.5 rounded-lg border border-forest-200 dark:border-forest-700 bg-white dark:bg-forest-800 text-forest-800 dark:text-forest-100 text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none font-medium"
                        >
                          {STANDARD_CATEGORIES.map((cat) => (
                            <option key={cat} value={cat}>{cat}</option>
                          ))}
                        </select>
                      </td>

                      {/* Weight (kg) */}
                      <td className="py-2.5 px-3">
                        <div className="relative">
                          <input
                            type="number"
                            step="0.1"
                            min="0.1"
                            placeholder="0.0"
                            value={row.weight_kg}
                            onChange={(e) => handleRowChange(row.id, 'weight_kg', e.target.value)}
                            className="w-full pr-7 pl-2.5 py-1.5 rounded-lg border border-forest-200 dark:border-forest-700 bg-white dark:bg-forest-800 text-forest-900 dark:text-forest-100 font-mono text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none font-semibold"
                          />
                          <span className="absolute right-2 top-2 text-[10px] text-forest-400 font-mono pointer-events-none">
                            kg
                          </span>
                        </div>
                      </td>

                      {/* Remarks */}
                      <td className="py-2.5 px-3">
                        <input
                          type="text"
                          placeholder="e.g. Afternoon audit, cafeteria sweep..."
                          value={row.remarks}
                          onChange={(e) => handleRowChange(row.id, 'remarks', e.target.value)}
                          className="w-full px-2.5 py-1.5 rounded-lg border border-forest-200 dark:border-forest-700 bg-white dark:bg-forest-800 text-forest-800 dark:text-forest-100 text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                        />
                      </td>

                      {/* Remove Row Button */}
                      <td className="py-2.5 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => handleRemoveRow(row.id)}
                          className="p-1 rounded-lg text-forest-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition"
                          title="Remove row"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Bottom Grid Summary Footer */}
            <div className="p-4 bg-forest-50/70 dark:bg-forest-800/50 border-t border-forest-100 dark:border-forest-800 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center space-x-3 text-xs text-forest-600 dark:text-forest-300">
                <button
                  type="button"
                  onClick={handleAddRow}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-xs hover:bg-emerald-500 transition flex items-center space-x-1 shadow-sm"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Insert Row</span>
                </button>
                <span>
                  Valid Rows Ready: <strong className="text-emerald-600 dark:text-emerald-400 font-mono">{validRowCount}</strong> / {manualRows.length}
                </span>
                <span>•</span>
                <span>
                  Total Weight: <strong className="text-emerald-600 dark:text-emerald-400 font-mono">{totalWeightInGrid} kg</strong>
                </span>
              </div>

              {/* Submit Batch Button */}
              <button
                type="button"
                disabled={manualSubmitting || validRowCount === 0}
                onClick={handleSubmitManualBatch}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-glow flex items-center justify-center space-x-2 transition disabled:opacity-40"
              >
                {manualSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Inserting Batch into SQLite...</span>
                  </>
                ) : (
                  <>
                    <span>Submit {validRowCount} Records to Database</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Success Result Banner */}
          {manualResult && (
            <div className="p-6 rounded-3xl bg-white dark:bg-forest-900 border border-emerald-500/30 shadow-glow space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 shadow-glow">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-display font-extrabold text-lg text-forest-900 dark:text-white">
                    {manualResult.message}
                  </h3>
                  <p className="text-xs text-forest-500 dark:text-forest-400">
                    Your batch of manual records has been recorded and immediately integrated into all analytical aggregations.
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={() => {
                    handleClearGrid();
                    setManualResult(null);
                  }}
                  className="px-4 py-2 rounded-xl border border-forest-200 dark:border-forest-700 text-forest-700 dark:text-forest-200 text-xs font-semibold hover:bg-forest-50"
                >
                  Enter Another Batch
                </button>
                <button
                  onClick={() => setActivePage('records')}
                  className="px-4 py-2 rounded-xl bg-forest-100 dark:bg-forest-800 text-forest-800 dark:text-forest-200 text-xs font-bold hover:bg-forest-200"
                >
                  View in Records Table
                </button>
                <button
                  onClick={() => setActivePage('dashboard')}
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-glow flex items-center space-x-1.5"
                >
                  <span>Open Dashboard</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
