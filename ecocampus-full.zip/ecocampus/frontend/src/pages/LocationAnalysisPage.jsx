import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  MapPin, 
  Trophy, 
  TrendingUp, 
  TrendingDown, 
  BarChart2, 
  Layers, 
  ArrowRight, 
  CheckSquare, 
  Square,
  Sparkles,
  RefreshCw
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend 
} from 'recharts';
import { fetchLocationAnalytics } from '../utils/api';
import AnimatedCounter from '../components/AnimatedCounter';
import TiltCard3D from '../components/TiltCard3D';
import Isometric3DCampus from '../components/Isometric3DCampus';

const CATEGORY_COLORS = {
  "Organic / Food Waste": "#00D084",
  "Plastic Waste": "#06B6D4",
  "Paper Waste": "#F59E0B",
  "Metal Waste": "#8B5CF6",
  "Glass Waste": "#3B82F6",
  "Other Waste": "#64748B"
};

export default function LocationAnalysisPage({ setActivePage }) {
  const [locations, setLocations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedToCompare, setSelectedToCompare] = useState(['Canteen', 'Hostel', 'Classrooms']);

  const loadData = async () => {
    try {
      setLoading(true);
      const res = await fetchLocationAnalytics();
      setLocations(Array.isArray(res) ? res : []);
    } catch (err) {
      console.error(err);
      setLocations([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const toggleLocationSelection = (locName) => {
    if (selectedToCompare.includes(locName)) {
      if (selectedToCompare.length > 1) {
        setSelectedToCompare(selectedToCompare.filter((l) => l !== locName));
      }
    } else {
      if (selectedToCompare.length < 5) {
        setSelectedToCompare([...selectedToCompare, locName]);
      }
    }
  };

  // Prepare comparison chart data
  const safeLocations = Array.isArray(locations) ? locations : [];
  const comparisonData = safeLocations
    .filter((l) => selectedToCompare.includes(l.location))
    .map((l) => {
      const entry = {
        name: l.location,
        Total: l.total_weight_kg,
        Average: l.average_weight_kg,
        ...l.category_breakdown
      };
      return entry;
    });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fadeIn">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 mb-1.5 border border-emerald-300/40">
            <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
            <span>Spatial Generation Audit</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-display font-extrabold text-forest-900 dark:text-white">
            Campus Location Analysis & Benchmarking
          </h1>
          <p className="text-xs sm:text-sm text-forest-600 dark:text-forest-300 mt-1">
            Comparative spatial evaluation across college dining, residential, academic, and recreational facilities.
          </p>
        </div>

        <button
          onClick={loadData}
          className="p-2 rounded-xl bg-white dark:bg-forest-900 border border-forest-200 dark:border-forest-700 text-forest-700 dark:text-forest-200 hover:bg-forest-50 self-start shadow-sm"
          title="Reload metrics"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-emerald-500' : ''}`} />
        </button>
      </div>

      {/* 3D ISOMETRIC CAMPUS TOPOGRAPHY VISUALIZER (Large & Clearly Visible) */}
      <Isometric3DCampus 
        onSelectLocation={(name) => toggleLocationSelection(name)} 
        selectedLocation={selectedToCompare[0]}
        locationsData={locations}
      />

      {/* MULTI-LOCATION COMPARISON ENGINE WITH BIDIRECTIONAL SCROLL */}
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: false, amount: 0.15 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="card-lighting p-6 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-glow-ambient space-y-6"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-display font-bold text-forest-900 dark:text-white flex items-center space-x-2">
              <BarChart2 className="w-5 h-5 text-emerald-600" />
              <span>Multi-Location Head-to-Head Comparison</span>
            </h2>
            <p className="text-xs text-forest-500 dark:text-forest-400 mt-0.5">
              Select 2 to 5 campus zones to benchmark total output and material distribution.
            </p>
          </div>

          {/* Selectors Pills */}
          <div className="flex flex-wrap items-center gap-1.5">
            {locations.map((loc) => {
              const isSelected = selectedToCompare.includes(loc.location);
              return (
                <button
                  key={loc.location}
                  onClick={() => toggleLocationSelection(loc.location)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center space-x-1.5 ${
                    isSelected
                      ? 'bg-emerald-600 text-white shadow-glow'
                      : 'bg-forest-50 dark:bg-forest-800 text-forest-700 dark:text-forest-300 hover:bg-forest-100 dark:hover:bg-forest-700'
                  }`}
                >
                  {isSelected ? <CheckSquare className="w-3.5 h-3.5" /> : <Square className="w-3.5 h-3.5 text-forest-400" />}
                  <span>{loc.location}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Comparison Bar Chart */}
        <div className="h-80 w-full pt-4">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={comparisonData} margin={{ top: 10, right: 10, left: -10, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.15} />
              <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#6B7280' }} />
              <YAxis tick={{ fontSize: 11, fill: '#6B7280' }} unit=" kg" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#123D32', 
                  borderColor: '#16A36A', 
                  borderRadius: '12px', 
                  color: '#fff',
                  fontSize: '12px'
                }}
                formatter={(val, name) => [`${val} kg`, name]}
              />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
              <Bar dataKey="Total" fill="#16A36A" name="Total Generated (kg)" radius={[6, 6, 0, 0]} />
              <Bar dataKey="Organic / Food Waste" fill="#10B981" name="Organic (kg)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Plastic Waste" fill="#3B82F6" name="Plastic (kg)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Paper Waste" fill="#F59E0B" name="Paper (kg)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* LOCATION CARDS & LEADERBOARD GRID */}
      <div>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-display font-bold text-forest-900 dark:text-white flex items-center space-x-2">
            <Trophy className="w-5 h-5 text-amber-500" />
            <span>Campus Location Leaderboard</span>
          </h2>
          <span className="text-xs text-forest-500 font-medium">Ranked by aggregate volume</span>
        </div>

        {locations.length === 0 ? (
          <div className="p-8 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 text-center space-y-3">
            <MapPin className="w-8 h-8 text-forest-400 mx-auto" />
            <h3 className="font-bold text-forest-900 dark:text-white">No Location Records Yet</h3>
            <p className="text-xs text-forest-500 max-w-md mx-auto">
              Location rankings will automatically emerge once campus waste data is uploaded or entered.
            </p>
            <button
              onClick={() => setActivePage('upload')}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-glow inline-flex items-center space-x-1.5"
            >
              <span>Ingest Campus Data</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {locations.map((loc, idx) => {
            const isRank1 = loc.rank === 1;
            return (
              <TiltCard3D key={loc.location} tiltDegree={10} className="h-full">
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: false, amount: 0.15 }}
                  transition={{ duration: 0.5, delay: idx * 0.06 }}
                  className={`card-lighting p-5 rounded-2xl bg-white dark:bg-forest-900 border transition-all duration-300 shadow-sm hover:shadow-glow h-full flex flex-col justify-between ${
                    isRank1
                      ? 'border-amber-300 dark:border-amber-700 ring-2 ring-amber-400/20'
                      : 'border-forest-100 dark:border-forest-800'
                  }`}
                >
                  <div>
                    {/* Top Rank Badge */}
                    <div className="flex items-center justify-between">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-mono font-bold ${
                        isRank1 
                          ? 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300' 
                          : 'bg-forest-100 dark:bg-forest-800 text-forest-700 dark:text-forest-300'
                      }`}>
                        Rank #{loc.rank}
                      </span>
                      <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                        {loc.campus_share_pct}% Campus Share
                      </span>
                    </div>

                    <h3 
                      className="text-lg font-display font-black text-forest-900 dark:text-white mt-3"
                      style={{ transform: 'translateZ(18px)' }}
                    >
                      {loc.location}
                    </h3>

                    {/* Weight Stats */}
                    <div className="mt-2 space-y-1">
                      <div 
                        className="text-2xl font-black text-forest-900 dark:text-white"
                        style={{ transform: 'translateZ(22px)' }}
                      >
                        <AnimatedCounter value={loc.total_weight_kg} decimals={1} suffix=" kg" />
                      </div>
                      <div className="text-xs text-forest-500 dark:text-forest-400">
                        Avg: <strong className="text-forest-800 dark:text-forest-200">{loc.average_weight_kg} kg</strong>/collection ({loc.records_count} logs)
                      </div>
                    </div>

                    {/* Top Waste Material Stream */}
                    <div className="mt-4 pt-3 border-t border-forest-100 dark:border-forest-800/80">
                      <div className="text-[10px] uppercase font-bold text-forest-400 tracking-wider">Top Material</div>
                      <div className="text-xs font-bold text-forest-800 dark:text-forest-200 mt-0.5 truncate">
                        {loc.top_category}
                      </div>
                    </div>
                  </div>

                  {/* Category mini breakdown bars */}
                  <div className="mt-4 pt-3 border-t border-forest-100 dark:border-forest-800/80 space-y-1.5">
                    <div className="text-[10px] text-forest-400 font-semibold uppercase tracking-wider">Stream Distribution</div>
                    <div className="space-y-1">
                      {Object.entries(loc.category_breakdown).slice(0, 3).map(([cat, val]) => (
                        <div key={cat} className="flex items-center justify-between text-[11px]">
                          <span className="text-forest-600 dark:text-forest-400 truncate max-w-[120px]">{cat}</span>
                          <span className="font-mono font-medium text-forest-800 dark:text-forest-200">{val} kg</span>
                        </div>
                      ))}
                    </div>
                  </div>

                </motion.div>
              </TiltCard3D>
            );
          })}
        </div>
        )}
      </div>

    </div>
  );
}
