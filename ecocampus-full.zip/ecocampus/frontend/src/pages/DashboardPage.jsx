import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area, CartesianGrid, Legend 
} from 'recharts';
import { 
  Scale, 
  MapPin, 
  Flame, 
  Layers, 
  Filter, 
  Calendar, 
  TrendingUp, 
  RefreshCw, 
  Info, 
  Sparkles,
  ArrowUpRight,
  Lightbulb,
  CheckCircle2,
  TableProperties,
  UploadCloud
} from 'lucide-react';
import AnimatedCounter from '../components/AnimatedCounter';
import TiltCard3D from '../components/TiltCard3D';
import { fetchDashboardAnalytics, loadBenchmarkSample } from '../utils/api';

const COLORS = ['#00D084', '#06B6D4', '#F59E0B', '#8B5CF6', '#3B82F6', '#EC4899', '#64748B'];

export default function DashboardPage({ setActivePage }) {
  const [filter, setFilter] = useState('last_30_days');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('All Locations');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [showMovingAverage, setShowMovingAverage] = useState(true);
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [actionNotice, setActionNotice] = useState(null);

  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetchDashboardAnalytics(filter, startDate, endDate, selectedLocation, selectedCategory);
      setData(res);
    } catch (err) {
      setError(err.message || 'Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [filter, startDate, endDate, selectedLocation, selectedCategory]);

  // Listen to external reset events
  useEffect(() => {
    const handleReset = () => loadData();
    window.addEventListener('ecocampus-data-reset', handleReset);
    return () => window.removeEventListener('ecocampus-data-reset', handleReset);
  }, []);

  const handleFilterClick = (f) => {
    setFilter(f);
    if (f !== 'custom') {
      setStartDate('');
      setEndDate('');
    }
  };

  const handleLoadBenchmark = async () => {
    try {
      setLoading(true);
      const res = await loadBenchmarkSample();
      setActionNotice(res.message);
      setTimeout(() => setActionNotice(null), 5000);
      setFilter('all');
      await loadData();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const locationsList = [
    'All Locations', 'Canteen', 'Hostel', 'Classrooms', 'Library', 'Playground', 'Labs', 'Admin Block', 'Auditorium'
  ];

  const categoriesList = [
    'All Categories', 'Organic / Food Waste', 'Plastic Waste', 'Paper Waste', 'Metal Waste', 'Glass Waste', 'Other Waste'
  ];

  const filterButtons = [
    { id: 'today', label: 'Today' },
    { id: 'last_7_days', label: 'Last 7 Days' },
    { id: 'last_30_days', label: 'Last 30 Days' },
    { id: 'this_month', label: 'This Month' },
    { id: 'all', label: 'All Time' },
    { id: 'custom', label: 'Custom Range' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Header & Context */}
      <motion.div 
        initial={{ opacity: 0, y: -15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-col md:flex-row md:items-center justify-between gap-4"
      >
        <div>
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 mb-1.5">
            <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
            <span>Real-time Analytical Engine</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-display font-extrabold text-forest-900 dark:text-white">
            Campus Waste Analytics Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-forest-600 dark:text-forest-300 mt-1">
            Empirical measurements, location breakdown, and material distribution across campus.
          </p>
        </div>

        {/* Action Buttons: Upload Data & Reload */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setActivePage('upload')}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold transition flex items-center space-x-1.5 shadow-glow hover:scale-105 active:scale-95"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Upload Dataset</span>
          </button>

          <button
            onClick={loadData}
            title="Refresh statistics"
            className="p-2.5 rounded-xl bg-white dark:bg-forest-900 border border-forest-200 dark:border-forest-700 text-forest-700 dark:text-forest-200 hover:bg-forest-50 transition shadow-sm"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-emerald-500' : ''}`} />
          </button>
        </div>
      </motion.div>

      {/* Fresh Clean State Banner if 0 records */}
      {data && data.records_count === 0 && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-8 rounded-3xl bg-gradient-to-r from-forest-900 via-cyan-950 to-forest-850 border border-cyan-500/30 text-white shadow-glow-ambient flex flex-col md:flex-row items-center justify-between gap-6"
        >
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>Clean State • Start From New</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-display font-extrabold">
              Your Campus Waste Database is Fresh & Ready
            </h2>
            <p className="text-xs sm:text-sm text-forest-200 max-w-xl">
              No records exist yet. Ingest your college's real waste measurement records via CSV, Excel, or ODF spreadsheet, or type entries into the interactive manual grid.
            </p>
          </div>
          <button
            onClick={() => setActivePage('upload')}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-forest-950 font-extrabold text-sm shadow-glow flex items-center space-x-2 flex-shrink-0 transition hover:scale-105 active:scale-95"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Go to Data Ingestion</span>
          </button>
        </motion.div>
      )}

      {/* AUTOMATED STATISTICAL FINDINGS & COMMENTARY CARD */}
      {data?.insights && data.insights.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-5 sm:p-6 rounded-3xl bg-emerald-50/70 dark:bg-forest-900/50 border border-emerald-200/80 dark:border-emerald-800/60 shadow-sm space-y-3"
        >
          <div className="flex items-center space-x-2">
            <Lightbulb className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <h3 className="font-display font-extrabold text-sm text-forest-900 dark:text-white uppercase tracking-wider">
              Automated Statistical Insights & Findings
            </h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-forest-700 dark:text-forest-200">
            {data.insights.map((insight, idx) => (
              <div key={idx} className="p-3 rounded-2xl bg-white/80 dark:bg-forest-800/60 border border-emerald-100 dark:border-forest-700/60 flex items-start space-x-2.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5 flex-shrink-0" />
                <span className="leading-relaxed">{insight}</span>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* FILTER BAR WITH SLIDING PILL SWITCH */}
      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.05 }}
        className="p-4 sm:p-5 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm space-y-4"
      >
        <div className="flex flex-wrap items-center justify-between gap-4">
          
          {/* Preset Buttons with Sliding Motion Pill */}
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 p-1 rounded-2xl bg-forest-50/80 dark:bg-forest-950/80 border border-forest-100 dark:border-forest-800/80">
            {filterButtons.map((btn) => {
              const isActive = filter === btn.id;
              return (
                <button
                  key={btn.id}
                  onClick={() => handleFilterClick(btn.id)}
                  className={`relative px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors duration-150 ${
                    isActive
                      ? 'text-white'
                      : 'text-forest-700 dark:text-forest-300 hover:text-emerald-600'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeFilterPill"
                      className="absolute inset-0 bg-emerald-600 rounded-xl shadow-sm"
                      transition={{ type: "spring", stiffness: 400, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10">{btn.label}</span>
                </button>
              );
            })}
          </div>

          {/* Location & Category Selectors */}
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(e.target.value)}
              className="text-xs font-semibold px-3 py-2 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-800 dark:text-forest-200 focus:outline-none focus:ring-1 focus:ring-emerald-500 shadow-sm"
            >
              {locationsList.map((l) => (
                <option key={l} value={l}>{l}</option>
              ))}
            </select>

            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="text-xs font-semibold px-3 py-2 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-800 dark:text-forest-200 focus:outline-none focus:ring-1 focus:ring-emerald-500 shadow-sm"
            >
              {categoriesList.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Custom Date Pickers */}
        {filter === 'custom' && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="pt-3 border-t border-forest-100 dark:border-forest-800 flex flex-wrap items-center gap-3 text-xs"
          >
            <span className="font-semibold text-forest-700 dark:text-forest-300 flex items-center space-x-1">
              <Calendar className="w-3.5 h-3.5 text-emerald-500" />
              <span>Select Date Span:</span>
            </span>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-800 dark:text-forest-200 text-xs font-medium"
            />
            <span className="text-forest-400 font-semibold">to</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-forest-50 dark:bg-forest-800 border border-forest-200 dark:border-forest-700 text-forest-800 dark:text-forest-200 text-xs font-medium"
            />
          </motion.div>
        )}
      </motion.div>

      {/* TOP 4 STATISTIC CARDS WITH 3D TILT ANIMATION */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        
        {/* Card 1: Total Waste */}
        <TiltCard3D tiltDegree={12} className="h-full">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="card-lighting p-5 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm relative overflow-hidden h-full flex flex-col justify-between"
          >
            <div className="flex items-center justify-between text-forest-500 dark:text-forest-400">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                Total Waste
              </span>
              <div 
                className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-cyan-500 flex items-center justify-center text-white shadow-glow"
                style={{ transform: 'translateZ(30px)' }}
              >
                <Scale className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-3">
              <div 
                className="text-3xl font-display font-black text-forest-900 dark:text-white"
                style={{ transform: 'translateZ(24px)' }}
              >
                <AnimatedCounter value={data?.total_weight_kg || 0} decimals={1} suffix=" kg" />
              </div>
              <div className="text-xs text-forest-500 dark:text-forest-400 mt-1 flex items-center space-x-1">
                <span>Avg Rate: </span>
                <strong className="text-emerald-600 dark:text-emerald-400 font-semibold">
                  {data?.average_daily_weight_kg || 0} kg/day
                </strong>
              </div>
            </div>
          </motion.div>
        </TiltCard3D>

        {/* Card 2: Campus Locations */}
        <TiltCard3D tiltDegree={12} className="h-full">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.05 }}
            className="card-lighting p-5 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm relative overflow-hidden h-full flex flex-col justify-between"
          >
            <div className="flex items-center justify-between text-forest-500 dark:text-forest-400">
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-600 dark:text-cyan-400">
                Active Locations
              </span>
              <div 
                className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-500 flex items-center justify-center text-white shadow-glow-cyan"
                style={{ transform: 'translateZ(30px)' }}
              >
                <MapPin className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-3">
              <div 
                className="text-3xl font-display font-black text-forest-900 dark:text-white"
                style={{ transform: 'translateZ(24px)' }}
              >
                <AnimatedCounter value={data?.locations_count || 0} suffix=" Sites" />
              </div>
              <div className="text-xs text-forest-500 dark:text-forest-400 mt-1 font-medium">
                From {data?.records_count || 0} logged records
              </div>
            </div>
          </motion.div>
        </TiltCard3D>

        {/* Card 3: Highest Waste Location */}
        <TiltCard3D tiltDegree={12} className="h-full">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            className="card-lighting p-5 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm relative overflow-hidden h-full flex flex-col justify-between"
          >
            <div className="flex items-center justify-between text-forest-500 dark:text-forest-400">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                Peak Producer
              </span>
              <div 
                className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-white shadow-glow"
                style={{ transform: 'translateZ(30px)' }}
              >
                <Flame className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-3">
              <div 
                className="text-2xl font-display font-black text-forest-900 dark:text-white truncate"
                title={data?.top_location?.name}
                style={{ transform: 'translateZ(24px)' }}
              >
                {data?.top_location?.name || 'N/A'}
              </div>
              <div className="text-xs text-amber-600 dark:text-amber-400 font-bold mt-1">
                <AnimatedCounter value={data?.top_location?.weight_kg || 0} decimals={1} suffix=" kg" />
                <span className="text-forest-500 dark:text-forest-400 font-normal ml-1">
                  ({data?.top_location?.percentage || 0}%)
                </span>
              </div>
            </div>
          </motion.div>
        </TiltCard3D>

        {/* Card 4: Most Common Waste Category */}
        <TiltCard3D tiltDegree={12} className="h-full">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.15 }}
            className="card-lighting p-5 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm relative overflow-hidden h-full flex flex-col justify-between"
          >
            <div className="flex items-center justify-between text-forest-500 dark:text-forest-400">
              <span className="text-xs font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">
                Dominant Stream
              </span>
              <div 
                className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-500 to-pink-500 flex items-center justify-center text-white shadow-glow"
                style={{ transform: 'translateZ(30px)' }}
              >
                <Layers className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-3">
              <div 
                className="text-xl font-display font-black text-forest-900 dark:text-white truncate"
                title={data?.top_category?.name}
                style={{ transform: 'translateZ(24px)' }}
              >
                {data?.top_category?.name || 'N/A'}
              </div>
              <div className="text-xs text-purple-600 dark:text-purple-400 font-bold mt-1">
                <AnimatedCounter value={data?.top_category?.weight_kg || 0} decimals={1} suffix=" kg" />
                <span className="text-forest-500 dark:text-forest-400 font-normal ml-1">
                  ({data?.top_category?.percentage || 0}%)
                </span>
              </div>
            </div>
          </motion.div>
        </TiltCard3D>

      </div>

      {/* CHARTS ROW 1: Location Bar Chart & Category Donut */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Waste Generation by Location (Bar Chart) */}
        <motion.div 
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.15 }}
          transition={{ duration: 0.5 }}
          className="card-lighting lg:col-span-7 p-6 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm hover:shadow-glow-ambient transition-all duration-300 space-y-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-display font-bold text-base text-forest-900 dark:text-white">
                Waste Generation by Campus Location
              </h3>
              <p className="text-xs text-forest-500 dark:text-forest-400">
                Sorted by aggregate kilograms generated in selected period
              </p>
            </div>
            <button
              onClick={() => setActivePage('locations')}
              className="text-xs font-bold text-emerald-600 hover:text-emerald-500 flex items-center space-x-1"
            >
              <span>Deep Dive</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-72 w-full pt-4">
            {data?.location_distribution?.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.location_distribution} margin={{ top: 15, right: 10, left: -10, bottom: 25 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.15} />
                  <XAxis 
                    dataKey="location" 
                    angle={-25} 
                    textAnchor="end" 
                    interval={0}
                    height={45} 
                    tick={{ fontSize: 11, fill: '#6B7280' }} 
                  />
                  <YAxis tick={{ fontSize: 11, fill: '#6B7280' }} unit=" kg" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#123D32', 
                      borderColor: '#16A36A', 
                      borderRadius: '12px', 
                      color: '#fff',
                      fontSize: '12px'
                    }}
                    formatter={(val, name, item) => [`${val} kg (${item.payload.percentage}%)`, 'Total Waste']}
                  />
                  <Bar dataKey="weight_kg" fill="#16A36A" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-forest-400">
                No location records match the active filter.
              </div>
            )}
          </div>
        </motion.div>

        {/* Waste Distribution by Category (Donut / Pie) */}
        <motion.div 
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.15 }}
          transition={{ duration: 0.5, delay: 0.08 }}
          className="card-lighting lg:col-span-5 p-6 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm hover:shadow-glow-ambient transition-all duration-300 space-y-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-display font-bold text-base text-forest-900 dark:text-white">
                Category Composition
              </h3>
              <p className="text-xs text-forest-500 dark:text-forest-400">
                Part-to-whole material percentage breakdown
              </p>
            </div>
            <button
              onClick={() => setActivePage('categories')}
              className="text-xs font-bold text-emerald-600 hover:text-emerald-500 flex items-center space-x-1"
            >
              <span>Circularity</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-72 w-full flex items-center justify-center">
            {data?.category_distribution?.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data.category_distribution}
                    dataKey="weight_kg"
                    nameKey="category"
                    cx="50%"
                    cy="45%"
                    innerRadius={55}
                    outerRadius={85}
                    paddingAngle={3}
                  >
                    {data.category_distribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#123D32', 
                      borderColor: '#16A36A', 
                      borderRadius: '12px', 
                      color: '#fff',
                      fontSize: '12px'
                    }}
                    formatter={(val, name, item) => [`${val} kg (${item.payload.percentage}%)`, name]}
                  />
                  <Legend 
                    layout="horizontal" 
                    verticalAlign="bottom" 
                    align="center"
                    iconType="circle"
                    wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-forest-400">
                No category records available.
              </div>
            )}
          </div>
        </motion.div>

      </div>

      {/* CHARTS ROW 2: Daily Trend (with 7-Day Moving Average Toggle) & Monthly Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Daily Generation Line Chart with Moving Average Toggle */}
        <motion.div 
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.15 }}
          transition={{ duration: 0.5 }}
          className="card-lighting lg:col-span-8 p-6 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm hover:shadow-glow-ambient transition-all duration-300 space-y-4"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="font-display font-bold text-base text-forest-900 dark:text-white">
                Daily Waste Timeline & 7-Day Moving Average
              </h3>
              <p className="text-xs text-forest-500 dark:text-forest-400">
                Chronological pattern of daily collection with statistical smoothing
              </p>
            </div>

            {/* Toggle 7-Day Moving Average */}
            <div className="flex items-center space-x-2 text-xs">
              <button
                onClick={() => setShowMovingAverage(!showMovingAverage)}
                className={`px-2.5 py-1 rounded-lg font-semibold transition ${
                  showMovingAverage
                    ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700'
                    : 'bg-forest-100 dark:bg-forest-800 text-forest-600 dark:text-forest-400'
                }`}
              >
                {showMovingAverage ? '✓ 7-Day Moving Avg ON' : 'Show 7-Day Moving Avg'}
              </button>
            </div>
          </div>

          <div className="h-72 w-full pt-4">
            {data?.daily_trend?.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={data.daily_trend} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.15} />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 11, fill: '#6B7280' }} 
                    tickFormatter={(d) => d.slice(5)}
                  />
                  <YAxis tick={{ fontSize: 11, fill: '#6B7280' }} unit=" kg" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#123D32', 
                      borderColor: '#16A36A', 
                      borderRadius: '12px', 
                      color: '#fff',
                      fontSize: '12px'
                    }}
                    formatter={(val, name) => [`${val} kg`, name === 'weight_kg' ? 'Daily Weight' : '7-Day Moving Avg']}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                  <Line 
                    type="monotone" 
                    dataKey="weight_kg" 
                    name="Daily Waste (kg)"
                    stroke="#16A36A" 
                    strokeWidth={2} 
                    dot={{ r: 2.5, fill: '#16A36A' }}
                    activeDot={{ r: 5, stroke: '#FFFFFF', strokeWidth: 2 }}
                  />
                  {showMovingAverage && (
                    <Line 
                      type="monotone" 
                      dataKey="moving_avg_7d" 
                      name="7-Day Moving Average"
                      stroke="#3B82F6" 
                      strokeWidth={2.5} 
                      strokeDasharray="4 4"
                      dot={false}
                    />
                  )}
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-forest-400">
                No daily timeline points found for this range.
              </div>
            )}
          </div>
        </motion.div>

        {/* Monthly Trend Area Chart */}
        <motion.div 
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.15 }}
          transition={{ duration: 0.5, delay: 0.08 }}
          className="card-lighting lg:col-span-4 p-6 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm hover:shadow-glow-ambient transition-all duration-300 space-y-4"
        >
          <div>
            <h3 className="font-display font-bold text-base text-forest-900 dark:text-white">
              Monthly Aggregates
            </h3>
            <p className="text-xs text-forest-500 dark:text-forest-400">
              Aggregate collection volume across calendar months
            </p>
          </div>

          <div className="h-72 w-full pt-4">
            {data?.monthly_trend?.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data.monthly_trend} margin={{ top: 10, right: 10, left: -15, bottom: 5 }}>
                  <defs>
                    <linearGradient id="monthGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#16A36A" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="#16A36A" stopOpacity={0.0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.15} />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#6B7280' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#6B7280' }} unit=" kg" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#123D32', 
                      borderColor: '#16A36A', 
                      borderRadius: '12px', 
                      color: '#fff',
                      fontSize: '12px'
                    }}
                    formatter={(val) => [`${val} kg`, 'Monthly Total']}
                  />
                  <Area type="monotone" dataKey="weight_kg" stroke="#16A36A" fillOpacity={1} fill="url(#monthGrad)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-forest-400">
                No monthly data available.
              </div>
            )}
          </div>
        </motion.div>

      </div>

      {/* MATRIX TABLE / CROSS-TABULATION: Location vs Categories */}
      <motion.div 
        initial={{ opacity: 0, y: 25 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: false, amount: 0.15 }}
        transition={{ duration: 0.5 }}
        className="card-lighting p-6 rounded-3xl bg-white dark:bg-forest-900 border border-forest-100 dark:border-forest-800 shadow-sm hover:shadow-glow-ambient transition-all duration-300 space-y-4"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="font-display font-bold text-base text-forest-900 dark:text-white">
              Location × Category Generation Matrix (kg)
            </h3>
            <p className="text-xs text-forest-500 dark:text-forest-400">
              Cross-tabulation showing exact material distribution across each campus facility
            </p>
          </div>
          <span className="text-xs font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
            Computed via pd.crosstab
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-forest-100 dark:border-forest-800 text-forest-500 dark:text-forest-400 font-semibold uppercase tracking-wider">
                <th className="py-2.5 px-3">Location</th>
                <th className="py-2.5 px-3">Organic</th>
                <th className="py-2.5 px-3">Plastic</th>
                <th className="py-2.5 px-3">Paper</th>
                <th className="py-2.5 px-3">Metal</th>
                <th className="py-2.5 px-3">Glass</th>
                <th className="py-2.5 px-3">Other</th>
                <th className="py-2.5 px-3 text-right">Total (kg)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-forest-50 dark:divide-forest-800/60">
              {data?.location_category_matrix?.map((row, idx) => (
                <tr key={idx} className="hover:bg-forest-50/50 dark:hover:bg-forest-800/40 transition">
                  <td className="py-2.5 px-3 font-bold text-forest-900 dark:text-white">
                    {row.location}
                  </td>
                  <td className="py-2.5 px-3 text-forest-700 dark:text-forest-200">
                    {row['Organic / Food Waste'] ? `${row['Organic / Food Waste']} kg` : '—'}
                  </td>
                  <td className="py-2.5 px-3 text-forest-700 dark:text-forest-200">
                    {row['Plastic Waste'] ? `${row['Plastic Waste']} kg` : '—'}
                  </td>
                  <td className="py-2.5 px-3 text-forest-700 dark:text-forest-200">
                    {row['Paper Waste'] ? `${row['Paper Waste']} kg` : '—'}
                  </td>
                  <td className="py-2.5 px-3 text-forest-700 dark:text-forest-200">
                    {row['Metal Waste'] ? `${row['Metal Waste']} kg` : '—'}
                  </td>
                  <td className="py-2.5 px-3 text-forest-700 dark:text-forest-200">
                    {row['Glass Waste'] ? `${row['Glass Waste']} kg` : '—'}
                  </td>
                  <td className="py-2.5 px-3 text-forest-700 dark:text-forest-200">
                    {row['Other Waste'] ? `${row['Other Waste']} kg` : '—'}
                  </td>
                  <td className="py-2.5 px-3 text-right font-black text-emerald-600 dark:text-emerald-400">
                    {row.total} kg
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

    </div>
  );
}
